#
# phpBB Backup Script
# Dump of tables for sasguild_sasForum
#
# DATE : 31-05-2007 01:42:45 GMT
#
#
# TABLE: phpbb_auth_access
#
DROP TABLE IF EXISTS phpbb_auth_access;
CREATE TABLE phpbb_auth_access(
	group_id mediumint(8) NOT NULL,
	forum_id smallint(5) unsigned NOT NULL,
	auth_view tinyint(1) NOT NULL,
	auth_read tinyint(1) NOT NULL,
	auth_post tinyint(1) NOT NULL,
	auth_reply tinyint(1) NOT NULL,
	auth_edit tinyint(1) NOT NULL,
	auth_delete tinyint(1) NOT NULL,
	auth_sticky tinyint(1) NOT NULL,
	auth_announce tinyint(1) NOT NULL,
	auth_vote tinyint(1) NOT NULL,
	auth_pollcreate tinyint(1) NOT NULL,
	auth_attachments tinyint(1) NOT NULL,
	auth_mod tinyint(1) NOT NULL, 
	KEY group_id (group_id), 
	KEY forum_id (forum_id)
);

#
# Table Data for phpbb_auth_access
#

INSERT INTO phpbb_auth_access (group_id, forum_id, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments, auth_mod) VALUES('5', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1');
INSERT INTO phpbb_auth_access (group_id, forum_id, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments, auth_mod) VALUES('8', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1');
#
# TABLE: phpbb_banlist
#
DROP TABLE IF EXISTS phpbb_banlist;
CREATE TABLE phpbb_banlist(
	ban_id mediumint(8) unsigned NOT NULL auto_increment,
	ban_userid mediumint(8) NOT NULL,
	ban_ip varchar(8) NOT NULL,
	ban_email varchar(255), 
	PRIMARY KEY (ban_id), 
	KEY ban_ip_user_id (ban_ip, ban_userid)
);

#
# Table Data for phpbb_banlist
#

INSERT INTO phpbb_banlist (ban_id, ban_userid, ban_ip, ban_email) VALUES('10', '0', '40142258', NULL);
INSERT INTO phpbb_banlist (ban_id, ban_userid, ban_ip, ban_email) VALUES('4', '0', 'ca650655', NULL);
INSERT INTO phpbb_banlist (ban_id, ban_userid, ban_ip, ban_email) VALUES('8', '0', 'cb710dff', NULL);
INSERT INTO phpbb_banlist (ban_id, ban_userid, ban_ip, ban_email) VALUES('6', '0', '403269e3', NULL);
INSERT INTO phpbb_banlist (ban_id, ban_userid, ban_ip, ban_email) VALUES('9', '0', '4833260d', NULL);
INSERT INTO phpbb_banlist (ban_id, ban_userid, ban_ip, ban_email) VALUES('11', '0', '4350b135', NULL);
INSERT INTO phpbb_banlist (ban_id, ban_userid, ban_ip, ban_email) VALUES('12', '0', 'd3a2bffb', NULL);
#
# TABLE: phpbb_categories
#
DROP TABLE IF EXISTS phpbb_categories;
CREATE TABLE phpbb_categories(
	cat_id mediumint(8) unsigned NOT NULL auto_increment,
	cat_title varchar(100),
	cat_order mediumint(8) unsigned NOT NULL, 
	PRIMARY KEY (cat_id), 
	KEY cat_order (cat_order)
);

#
# Table Data for phpbb_categories
#

INSERT INTO phpbb_categories (cat_id, cat_title, cat_order) VALUES('3', 'Sinners Among Saints', '10');
#
# TABLE: phpbb_config
#
DROP TABLE IF EXISTS phpbb_config;
CREATE TABLE phpbb_config(
	config_name varchar(255) NOT NULL,
	config_value varchar(255) NOT NULL, 
	PRIMARY KEY (config_name)
);

#
# Table Data for phpbb_config
#

INSERT INTO phpbb_config (config_name, config_value) VALUES('config_id', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('board_disable', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('sitename', 'The Sinners Among Saints');
INSERT INTO phpbb_config (config_name, config_value) VALUES('site_desc', 'SAS Forums');
INSERT INTO phpbb_config (config_name, config_value) VALUES('cookie_name', 'phpbb2mysql');
INSERT INTO phpbb_config (config_name, config_value) VALUES('cookie_path', '/');
INSERT INTO phpbb_config (config_name, config_value) VALUES('cookie_domain', '');
INSERT INTO phpbb_config (config_name, config_value) VALUES('cookie_secure', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('session_length', '3600');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_html', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_html_tags', 'b,i,u,pre');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_bbcode', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_smilies', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_sig', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_namechange', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_theme_create', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_avatar_local', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_avatar_remote', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_avatar_upload', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('enable_confirm', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_autologin', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('max_autologin_time', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('override_user_style', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('posts_per_page', '15');
INSERT INTO phpbb_config (config_name, config_value) VALUES('topics_per_page', '50');
INSERT INTO phpbb_config (config_name, config_value) VALUES('hot_threshold', '25');
INSERT INTO phpbb_config (config_name, config_value) VALUES('max_poll_options', '10');
INSERT INTO phpbb_config (config_name, config_value) VALUES('max_sig_chars', '255');
INSERT INTO phpbb_config (config_name, config_value) VALUES('max_inbox_privmsgs', '50');
INSERT INTO phpbb_config (config_name, config_value) VALUES('max_sentbox_privmsgs', '25');
INSERT INTO phpbb_config (config_name, config_value) VALUES('max_savebox_privmsgs', '50');
INSERT INTO phpbb_config (config_name, config_value) VALUES('board_email_sig', 'Thanks, The Management');
INSERT INTO phpbb_config (config_name, config_value) VALUES('board_email', 'tgzalonis@hotmail.com');
INSERT INTO phpbb_config (config_name, config_value) VALUES('smtp_delivery', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('smtp_host', '');
INSERT INTO phpbb_config (config_name, config_value) VALUES('smtp_username', '');
INSERT INTO phpbb_config (config_name, config_value) VALUES('smtp_password', '');
INSERT INTO phpbb_config (config_name, config_value) VALUES('sendmail_fix', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('require_activation', '2');
INSERT INTO phpbb_config (config_name, config_value) VALUES('flood_interval', '15');
INSERT INTO phpbb_config (config_name, config_value) VALUES('search_flood_interval', '15');
INSERT INTO phpbb_config (config_name, config_value) VALUES('search_min_chars', '3');
INSERT INTO phpbb_config (config_name, config_value) VALUES('max_login_attempts', '3');
INSERT INTO phpbb_config (config_name, config_value) VALUES('login_reset_time', '30');
INSERT INTO phpbb_config (config_name, config_value) VALUES('board_email_form', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('avatar_filesize', '60000');
INSERT INTO phpbb_config (config_name, config_value) VALUES('avatar_max_width', '125');
INSERT INTO phpbb_config (config_name, config_value) VALUES('avatar_max_height', '125');
INSERT INTO phpbb_config (config_name, config_value) VALUES('avatar_path', 'images/avatars');
INSERT INTO phpbb_config (config_name, config_value) VALUES('avatar_gallery_path', 'images/avatars/gallery');
INSERT INTO phpbb_config (config_name, config_value) VALUES('smilies_path', 'images/smiles');
INSERT INTO phpbb_config (config_name, config_value) VALUES('default_style', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('default_dateformat', 'D M d, Y g:i a');
INSERT INTO phpbb_config (config_name, config_value) VALUES('board_timezone', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('prune_enable', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('privmsg_disable', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('gzip_compress', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('coppa_fax', '');
INSERT INTO phpbb_config (config_name, config_value) VALUES('coppa_mail', '');
INSERT INTO phpbb_config (config_name, config_value) VALUES('record_online_users', '6');
INSERT INTO phpbb_config (config_name, config_value) VALUES('record_online_date', '1177867022');
INSERT INTO phpbb_config (config_name, config_value) VALUES('server_name', 'www.sasguild.org');
INSERT INTO phpbb_config (config_name, config_value) VALUES('server_port', '80');
INSERT INTO phpbb_config (config_name, config_value) VALUES('script_path', '/forum/');
INSERT INTO phpbb_config (config_name, config_value) VALUES('version', '.0.21');
INSERT INTO phpbb_config (config_name, config_value) VALUES('rand_seed', '46c133bc697b90bb99a1bfc5fe9aa2a8');
INSERT INTO phpbb_config (config_name, config_value) VALUES('board_startdate', '1150289148');
INSERT INTO phpbb_config (config_name, config_value) VALUES('default_lang', 'english');
#
# TABLE: phpbb_disallow
#
DROP TABLE IF EXISTS phpbb_disallow;
CREATE TABLE phpbb_disallow(
	disallow_id mediumint(8) unsigned NOT NULL auto_increment,
	disallow_username varchar(25) NOT NULL, 
	PRIMARY KEY (disallow_id)
);
#
# TABLE: phpbb_forums
#
DROP TABLE IF EXISTS phpbb_forums;
CREATE TABLE phpbb_forums(
	forum_id smallint(5) unsigned NOT NULL,
	cat_id mediumint(8) unsigned NOT NULL,
	forum_name varchar(150),
	forum_desc text,
	forum_status tinyint(4) NOT NULL,
	forum_order mediumint(8) unsigned DEFAULT '1' NOT NULL,
	forum_posts mediumint(8) unsigned NOT NULL,
	forum_topics mediumint(8) unsigned NOT NULL,
	forum_last_post_id mediumint(8) unsigned NOT NULL,
	prune_next int(11),
	prune_enable tinyint(1) NOT NULL,
	auth_view tinyint(2) NOT NULL,
	auth_read tinyint(2) NOT NULL,
	auth_post tinyint(2) NOT NULL,
	auth_reply tinyint(2) NOT NULL,
	auth_edit tinyint(2) NOT NULL,
	auth_delete tinyint(2) NOT NULL,
	auth_sticky tinyint(2) NOT NULL,
	auth_announce tinyint(2) NOT NULL,
	auth_vote tinyint(2) NOT NULL,
	auth_pollcreate tinyint(2) NOT NULL,
	auth_attachments tinyint(2) NOT NULL, 
	PRIMARY KEY (forum_id), 
	KEY forums_order (forum_order), 
	KEY cat_id (cat_id), 
	KEY forum_last_post_id (forum_last_post_id)
);

#
# Table Data for phpbb_forums
#

INSERT INTO phpbb_forums (forum_id, cat_id, forum_name, forum_desc, forum_status, forum_order, forum_posts, forum_topics, forum_last_post_id, prune_next, prune_enable, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments) VALUES('1', '3', 'General Discussion', 'Public Chit-Chat', '0', '10', '269', '33', '323', NULL, '0', '0', '0', '1', '1', '1', '1', '3', '3', '1', '1', '0');
#
# TABLE: phpbb_forum_prune
#
DROP TABLE IF EXISTS phpbb_forum_prune;
CREATE TABLE phpbb_forum_prune(
	prune_id mediumint(8) unsigned NOT NULL auto_increment,
	forum_id smallint(5) unsigned NOT NULL,
	prune_days smallint(5) unsigned NOT NULL,
	prune_freq smallint(5) unsigned NOT NULL, 
	PRIMARY KEY (prune_id), 
	KEY forum_id (forum_id)
);
#
# TABLE: phpbb_groups
#
DROP TABLE IF EXISTS phpbb_groups;
CREATE TABLE phpbb_groups(
	group_id mediumint(8) NOT NULL auto_increment,
	group_type tinyint(4) DEFAULT '1' NOT NULL,
	group_name varchar(40) NOT NULL,
	group_description varchar(255) NOT NULL,
	group_moderator mediumint(8) NOT NULL,
	group_single_user tinyint(1) DEFAULT '1' NOT NULL, 
	PRIMARY KEY (group_id), 
	KEY group_single_user (group_single_user)
);

#
# Table Data for phpbb_groups
#

INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('1', '1', 'Anonymous', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('2', '1', 'Admin', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('3', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('4', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('5', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('6', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('7', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('8', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('9', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('10', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('11', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('12', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('14', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('42', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('18', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('35', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('59', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('30', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('28', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('37', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('44', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('99', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('58', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('54', '1', 'SAS', 'The Sinners', '2', '0');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('72', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('103', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('96', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('71', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('102', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('101', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('100', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('95', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('97', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('98', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('92', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('93', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('94', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('104', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('105', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('106', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('107', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('108', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('109', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('110', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('111', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('112', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('113', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('114', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('115', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('116', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('117', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('118', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('119', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('120', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('121', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('122', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('123', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('124', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('125', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('126', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('127', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('128', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('129', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('130', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('131', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('132', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('133', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('134', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('135', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('136', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('137', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('138', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('139', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('140', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('141', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('142', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('143', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('144', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('145', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('146', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('147', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('148', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('149', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('220', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('151', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('152', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('153', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('154', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('155', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('156', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('157', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('158', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('159', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('160', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('161', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('162', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('163', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('164', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('165', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('166', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('167', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('168', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('169', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('170', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('171', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('172', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('173', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('174', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('175', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('176', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('177', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('178', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('179', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('180', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('181', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('182', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('183', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('184', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('185', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('186', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('187', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('188', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('189', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('190', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('191', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('192', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('193', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('194', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('195', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('196', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('197', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('198', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('199', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('200', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('201', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('202', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('203', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('204', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('205', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('206', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('207', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('208', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('209', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('210', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('211', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('219', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('213', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('214', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('215', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('216', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('217', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('218', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('221', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('222', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('223', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('224', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('225', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('226', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('227', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('228', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('229', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('230', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('231', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('232', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('233', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('234', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('235', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('236', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('237', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('238', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('239', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('240', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('241', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('242', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('243', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('244', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('245', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('246', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('247', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('248', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('249', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('250', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('251', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('252', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('253', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('254', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('255', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('256', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('257', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('258', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('259', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('260', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('261', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('262', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('263', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('264', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('265', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('266', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('267', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('268', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('269', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('270', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('271', '1', '', 'Personal User', '0', '1');
#
# TABLE: phpbb_posts
#
DROP TABLE IF EXISTS phpbb_posts;
CREATE TABLE phpbb_posts(
	post_id mediumint(8) unsigned NOT NULL auto_increment,
	topic_id mediumint(8) unsigned NOT NULL,
	forum_id smallint(5) unsigned NOT NULL,
	poster_id mediumint(8) NOT NULL,
	post_time int(11) NOT NULL,
	poster_ip varchar(8) NOT NULL,
	post_username varchar(25),
	enable_bbcode tinyint(1) DEFAULT '1' NOT NULL,
	enable_html tinyint(1) NOT NULL,
	enable_smilies tinyint(1) DEFAULT '1' NOT NULL,
	enable_sig tinyint(1) DEFAULT '1' NOT NULL,
	post_edit_time int(11),
	post_edit_count smallint(5) unsigned NOT NULL, 
	PRIMARY KEY (post_id), 
	KEY forum_id (forum_id), 
	KEY topic_id (topic_id), 
	KEY poster_id (poster_id), 
	KEY post_time (post_time)
);

#
# Table Data for phpbb_posts
#

INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('2', '2', '1', '3', '1150301613', '43828187', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('3', '2', '1', '4', '1150401161', '8ea5ab5a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('4', '2', '1', '2', '1150406623', '47e2a70c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('5', '2', '1', '3', '1150408438', '43828187', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('267', '60', '1', '6', '1172917933', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('7', '4', '1', '6', '1150476862', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('8', '4', '1', '2', '1150477589', '47e2a70c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('9', '4', '1', '4', '1150494119', '8ea5ab5a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('10', '4', '1', '5', '1150494617', '1805c69a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('11', '5', '1', '5', '1151172279', '1805c69a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('46', '13', '1', '6', '1157066213', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('13', '5', '1', '7', '1151275517', '1896838f', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('14', '7', '1', '7', '1151275550', '1896838f', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('15', '7', '1', '2', '1151285348', '47e2a70c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('16', '5', '1', '2', '1151293798', '47e2a70c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('17', '5', '1', '6', '1151340514', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('270', '61', '1', '4', '1174687062', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('268', '60', '1', '4', '1172990169', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('20', '5', '1', '5', '1151781036', '1805c69a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('21', '7', '1', '5', '1151781068', '1805c69a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('22', '7', '1', '6', '1151788854', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('23', '7', '1', '2', '1151817851', '47e2a70c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('24', '5', '1', '2', '1151851958', '47e2a70c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('25', '7', '1', '6', '1151881638', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('26', '7', '1', '4', '1152493660', '8ea5ab5a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('27', '5', '1', '5', '1152552936', '1805c69a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('28', '9', '1', '6', '1152577884', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('29', '9', '1', '2', '1152760394', '47e2a70c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('30', '9', '1', '6', '1153313985', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('31', '9', '1', '6', '1153314030', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('32', '10', '1', '5', '1153784519', '1805c69a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('33', '11', '1', '10', '1154580826', '18b43164', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('34', '12', '1', '11', '1154906773', '467d1013', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('35', '12', '1', '9', '1154939861', '18b0d8f7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('36', '12', '1', '4', '1154986519', '8ea5ab5a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('37', '13', '1', '6', '1154999729', '4160fbd7', '', '1', '0', '1', '0', '1156128243', '1');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('38', '12', '1', '6', '1154999836', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('39', '13', '1', '12', '1155777694', '52b64596', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('40', '13', '1', '6', '1155859426', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('41', '13', '1', '4', '1155946870', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('42', '13', '1', '12', '1155954418', '52b64596', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('43', '13', '1', '6', '1156128204', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('44', '13', '1', '4', '1156477520', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('47', '13', '1', '13', '1157159381', '467058cc', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('48', '13', '1', '6', '1157382371', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('50', '16', '1', '17', '1157834949', '45e1f397', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('51', '16', '1', '3', '1157878016', '43828187', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('52', '16', '1', '17', '1157933513', '45e1f397', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('53', '16', '1', '4', '1158017739', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('57', '16', '1', '17', '1158611443', '447fe574', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('58', '16', '1', '4', '1158619901', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('64', '13', '1', '23', '1158784707', '476d7c91', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('60', '16', '1', '9', '1158730162', '18b0d8f7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('61', '13', '1', '9', '1158730211', '18b0d8f7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('65', '13', '1', '5', '1158797803', '1805c589', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('63', '13', '1', '6', '1158764420', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('66', '13', '1', '9', '1158820847', '18b0d8f7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('67', '13', '1', '6', '1158858585', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('68', '13', '1', '4', '1158968035', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('69', '10', '1', '5', '1158976675', '1805c589', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('70', '22', '1', '24', '1158978116', '42d7a5b2', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('71', '16', '1', '17', '1158979182', '447fe574', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('78', '16', '1', '17', '1159138043', '447fe574', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('73', '13', '1', '13', '1158999789', '181b117a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('74', '16', '1', '13', '1159000193', '181b117a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('75', '16', '1', '4', '1159031758', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('79', '16', '1', '5', '1159223257', '1805c589', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('77', '22', '1', '23', '1159129379', '476d7c91', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('80', '16', '1', '17', '1159224174', '447fe574', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('81', '13', '1', '9', '1159312111', '18b0d8f7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('82', '22', '1', '9', '1159312140', '18b0d8f7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('83', '16', '1', '9', '1159312217', '18b0d8f7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('84', '22', '1', '5', '1159319354', '1805c589', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('85', '22', '1', '13', '1159366990', '181b1711', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('86', '16', '1', '17', '1159391911', '447fe574', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('87', '16', '1', '5', '1159402616', '1805c589', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('88', '16', '1', '17', '1159408909', '447fe574', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('89', '22', '1', '23', '1159415667', '476d7c91', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('90', '22', '1', '4', '1159416572', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('91', '25', '1', '24', '1159483287', '42d7a5b2', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('92', '22', '1', '24', '1159483606', '42d7a5b2', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('93', '16', '1', '24', '1159483720', '42d7a5b2', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('94', '22', '1', '23', '1159514133', '476d7c91', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('95', '13', '1', '6', '1159516383', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('96', '26', '1', '2', '1159517331', '47e2a72c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('97', '22', '1', '10', '1159589375', '42d7a5b2', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('98', '27', '1', '24', '1159653108', '42d7a5b2', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('99', '27', '1', '2', '1159755481', '47e2a72c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('100', '27', '1', '5', '1159914986', '1805c589', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('101', '27', '1', '10', '1159935227', '42d7a5b2', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('102', '25', '1', '4', '1159939496', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('103', '25', '1', '6', '1159973812', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('104', '26', '1', '6', '1159973960', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('105', '16', '1', '4', '1160070276', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('106', '16', '1', '17', '1160088808', '45e2784b', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('107', '16', '1', '4', '1160163066', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('108', '16', '1', '17', '1160288797', '45e2784b', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('109', '28', '1', '27', '1160924799', '44e1cbad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('110', '28', '1', '27', '1160924911', '44e1cbad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('111', '4', '1', '27', '1160925100', '44e1cbad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('112', '28', '1', '4', '1160932484', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('113', '16', '1', '4', '1160932541', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('114', '13', '1', '9', '1160969555', '18b0d8f7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('115', '16', '1', '9', '1160969924', '18b0d8f7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('116', '16', '1', '17', '1161010975', '456cad59', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('117', '28', '1', '2', '1161128220', '443ad565', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('118', '28', '1', '4', '1161217982', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('119', '28', '1', '2', '1161220447', '443ad565', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('120', '28', '1', '9', '1161236071', '18b0d8f7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('121', '16', '1', '9', '1161236207', '18b0d8f7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('122', '16', '1', '4', '1161296792', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('123', '16', '1', '17', '1161304992', '456cad49', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('124', '16', '1', '28', '1161434676', '46f25b34', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('125', '28', '1', '23', '1161455426', '476d7c91', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('126', '28', '1', '5', '1161536966', '45b57ce3', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('127', '28', '1', '2', '1161539625', '443ad565', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('128', '28', '1', '27', '1161544013', '44e1cbad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('129', '22', '1', '26', '1161553508', '47c71a70', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('130', '29', '1', '30', '1161554213', '44c58d78', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('131', '29', '1', '30', '1161554952', '44c58d78', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('132', '28', '1', '4', '1161560154', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('133', '16', '1', '4', '1161560210', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('134', '28', '1', '2', '1161562091', '443ad565', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('135', '28', '1', '4', '1161636852', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('136', '28', '1', '27', '1161643273', '44e1cbad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('137', '16', '1', '28', '1161653337', '40fad596', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('138', '28', '1', '4', '1161756359', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('139', '16', '1', '4', '1161756479', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('140', '16', '1', '5', '1161842303', '43b41cbe', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('141', '30', '1', '27', '1161954676', '44e1cbad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('142', '30', '1', '2', '1161961399', '443ad565', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('143', '31', '1', '6', '1162114378', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('144', '31', '1', '27', '1162133398', '44e1cbad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('145', '29', '1', '28', '1162144077', '40fadac9', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('146', '31', '1', '6', '1162174668', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('147', '4', '1', '6', '1162174752', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('148', '30', '1', '4', '1162331730', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('149', '30', '1', '9', '1162362867', '18b0d8f7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('150', '32', '1', '5', '1162421818', '43b41cbe', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('151', '30', '1', '27', '1162433090', '44e1cbad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('152', '30', '1', '27', '1162941759', '44e1cbad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('153', '30', '1', '4', '1163014333', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('154', '32', '1', '26', '1163023603', '47c71a70', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('155', '32', '1', '23', '1163569947', '476d7c91', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('156', '32', '1', '5', '1163728247', '43b41cbe', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('317', '42', '1', '2', '1180009603', '47e266dc', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('316', '45', '1', '9', '1179987139', '42d6084c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('159', '32', '1', '8', '1163780769', '41bd1bfc', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('160', '22', '1', '8', '1163780793', '41bd1bfc', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('315', '45', '1', '4', '1179966898', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('162', '22', '1', '23', '1163902089', '476d7c91', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('163', '22', '1', '4', '1163967496', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('164', '32', '1', '4', '1163967525', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('172', '32', '1', '27', '1165894947', '44e1cbad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('171', '32', '1', '3', '1165818751', '42d71208', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('314', '45', '1', '27', '1179930282', '4468f7a5', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('168', '22', '1', '26', '1164735261', '41bd1bfc', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('169', '22', '1', '4', '1164751850', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('170', '22', '1', '9', '1164768580', '18b0d8f7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('173', '32', '1', '4', '1165986305', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('174', '32', '1', '17', '1166130870', '45e1e60a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('175', '35', '1', '8', '1166159248', '41bd1bfc', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('176', '35', '1', '4', '1166161136', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('178', '35', '1', '2', '1166226723', '443ad565', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('179', '35', '1', '6', '1166328976', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('180', '35', '1', '4', '1166336654', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('313', '45', '1', '9', '1179901260', '42d6084c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('312', '45', '1', '4', '1179884488', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('311', '42', '1', '6', '1179846710', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('184', '35', '1', '6', '1166491550', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('185', '35', '1', '9', '1166497432', '18b0d8f7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('310', '64', '1', '5', '1179790617', '45ec4f07', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('187', '35', '1', '4', '1166573158', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('188', '37', '1', '4', '1167434714', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('189', '37', '1', '39', '1168411288', '415ddf7a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('190', '38', '1', '39', '1168411414', '415ddf7a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('191', '38', '1', '4', '1168448530', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('192', '38', '1', '3', '1168494325', '42d71208', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('193', '39', '1', '40', '1168541389', '1813fcba', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('194', '39', '1', '27', '1168614139', '44e1cbad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('195', '29', '1', '40', '1168624716', '836b0065', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('196', '29', '1', '30', '1168625030', 'ced21b21', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('269', '61', '1', '27', '1174684935', '44e1cbad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('198', '29', '1', '17', '1168655830', '45ee8f28', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('199', '29', '1', '13', '1168668126', '181b1056', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('200', '41', '1', '13', '1168668538', '181b1056', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('201', '41', '1', '2', '1168752371', '443ad565', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('202', '41', '1', '5', '1168797409', '43b41cbe', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('203', '41', '1', '9', '1168871571', '18b0d8f7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('204', '41', '1', '6', '1168893982', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('205', '41', '1', '13', '1168899160', '181b1056', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('206', '41', '1', '4', '1168899714', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('207', '38', '1', '7', '1169018686', '189688bc', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('208', '38', '1', '39', '1169187156', '459e8db7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('209', '41', '1', '8', '1169302312', '41bd1bfc', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('210', '42', '1', '8', '1169302528', '41bd1bfc', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('211', '42', '1', '27', '1169325405', '44e1cbad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('212', '42', '1', '9', '1169363899', '18b0d8f7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('213', '42', '1', '4', '1169368891', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('214', '42', '1', '8', '1169388583', '41bd1bfc', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('215', '39', '1', '8', '1169388677', '41bd1bfc', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('309', '65', '1', '5', '1179790500', '45ec4f07', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('218', '42', '1', '8', '1169494668', '41bd1bfc', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('219', '42', '1', '39', '1169581631', '42cbcd83', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('220', '42', '1', '27', '1169591296', '44e1cbad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('222', '42', '1', '39', '1169756149', '42cbcd83', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('223', '42', '1', '4', '1169758003', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('224', '44', '1', '13', '1169885820', '181b1056', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('225', '42', '1', '9', '1169952028', '18b0ddad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('226', '42', '1', '26', '1169961661', '180a9229', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('227', '41', '1', '26', '1169969976', '180a9229', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('228', '38', '1', '26', '1169970198', '180a9229', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('229', '42', '1', '8', '1169995945', '41bd1bfc', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('230', '44', '1', '4', '1170002684', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('231', '44', '1', '27', '1170024838', '44e1cbad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('232', '44', '1', '26', '1170118415', '180a9229', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('233', '42', '1', '9', '1170656897', '18b0ddad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('234', '41', '1', '9', '1170656974', '18b0ddad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('235', '42', '1', '26', '1170951068', '180a9229', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('236', '42', '1', '9', '1171031149', '18b0ddad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('237', '42', '1', '4', '1171068855', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('238', '42', '1', '39', '1171353073', '459e8997', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('239', '42', '1', '9', '1171463697', '18b0ddad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('240', '45', '1', '9', '1172290645', '18b0ddad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('241', '45', '1', '4', '1172389475', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('242', '45', '1', '9', '1172443308', '18b0ddad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('274', '62', '1', '27', '1175300218', '44e1cbad', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('272', '60', '1', '6', '1174778550', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('273', '62', '1', '6', '1175263724', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('271', '61', '1', '6', '1174778520', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('275', '62', '1', '4', '1175733790', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('276', '62', '1', '9', '1175928983', '42d6084c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('277', '62', '1', '17', '1176863613', '45e9d074', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('278', '63', '1', '5', '1177114537', '18076c2c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('279', '63', '1', '3', '1177199940', '42d68ab1', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('280', '45', '1', '9', '1177816521', '42d6084c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('281', '45', '1', '3', '1177830623', '42d68ab1', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('282', '45', '1', '9', '1177866891', '42d6084c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('283', '64', '1', '4', '1178065015', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('284', '63', '1', '4', '1178065080', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('285', '62', '1', '4', '1178065153', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('286', '64', '1', '9', '1178114162', '42d6084c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('308', '65', '1', '6', '1179580796', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('288', '64', '1', '27', '1178157274', '4468f7a5', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('289', '45', '1', '39', '1178734217', '42cbcd83', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('290', '45', '1', '3', '1178780082', '42d68ab1', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('291', '45', '1', '2', '1178850508', '443acb4b', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('292', '64', '1', '2', '1178851224', '443acb4b', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('293', '65', '1', '6', '1178915469', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('294', '65', '1', '2', '1178919524', '443acb4b', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('295', '65', '1', '6', '1178931808', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('296', '65', '1', '5', '1179005125', '45ec5283', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('297', '65', '1', '3', '1179085589', '42d68ab1', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('298', '65', '1', '6', '1179265021', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('299', '65', '1', '2', '1179288234', '47e266dc', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('300', '65', '1', '26', '1179353408', '180a9229', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('301', '64', '1', '26', '1179353962', '180a9229', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('302', '64', '1', '4', '1179409565', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('303', '45', '1', '9', '1179499999', '42d6084c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('304', '65', '1', '6', '1179500123', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('305', '42', '1', '6', '1179500277', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('306', '42', '1', '2', '1179557937', '47e266dc', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('307', '65', '1', '2', '1179558284', '47e266dc', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('318', '65', '1', '40', '1180036013', '1813fcba', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('319', '62', '1', '40', '1180036090', '1813fcba', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('320', '65', '1', '6', '1180301993', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('321', '65', '1', '5', '1180337186', '43b41cbe', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('322', '65', '1', '2', '1180349623', '443ac980', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('323', '65', '1', '39', '1180567110', 'cef8bac7', '', '1', '0', '1', '0', NULL, '0');
#
# TABLE: phpbb_posts_text
#
DROP TABLE IF EXISTS phpbb_posts_text;
CREATE TABLE phpbb_posts_text(
	post_id mediumint(8) unsigned NOT NULL,
	bbcode_uid varchar(10) NOT NULL,
	post_subject varchar(60),
	post_text text, 
	PRIMARY KEY (post_id)
);

#
# Table Data for phpbb_posts_text
#

INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('2', 'c0e80b3005', 'Moo', 'First.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('3', 'b2823c3877', '', 'Ahoy hoy.

You still play UO?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('4', 'f63e68fa23', '', 'UO? Oh, god.. Please say you don\'t Garen... it better not be an OSI server.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('5', '5eb2a8d6ae', '', 'I still have the Arion III account. Everyone is gone, I stopped playing just before the ML expansion. I have recently started to log on and look around at things.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('268', '8c512ab8f5', '', 'Mostly crying, and a little bit of school.

Can\'t wait for the summer.. -30 weather has been the shits.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('7', '7afceb4c43', 'asdasf', 'asfasf');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('8', 'a197058a71', '', 'I agree fully. nod.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('9', 'd62bed8331', '', 'fds fdsa sa dsaf?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('10', '863d1ed171', '', 'WHAT ARE YOU? SOME FUCKING KIDS?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('11', '4c2a920829', 'activity', 'Forum master!
-can we get a private forum where anyone of us whom registers a new account is within a 24hour period addmitted to the privvy place?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('46', '8e4cd5bf01', '', 'the best poart is the next few days i was completely embarassed that i even fooled around with her im glad that all that happend was  i touched her tits n she rubbed my dick thru the pants!

but then she goes n does somethin like this son the fuck');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('13', '5a862bf754', '', 'i agree.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('14', '026620e571', 'WoW', 'I\'m buying WoW time in the next couple of days since my exam\'s have finished. What server are you guys in?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('15', '25f6c64bbc', '', 'I didn\'t know Jews were allowed to play WoW. Hrm, learn something everyday! =]');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('16', '6d109390ae', '', 'You want what?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('17', '15aa6c9642', '', 'naked pics of rostrax');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('267', 'e680584d38', 'oh yeah my  case got thrown out', 'w00t

im playin metro whats everyone else doing?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('20', 'b069582afe', '', 'a fookin private forum.  you know people read our thoughts... our ideas about.. globalization and religious domination.

NIGGA!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('21', 'b5ea9ac6bf', '', ':arrow:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('22', 'b14779e262', '', 'bloodscalp alliance

msg treca or lakkin or mojen in game

treca = rostrax with 2 pigtails and a cute butt');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('23', 'fd38d37a4d', '', 'Cute butt?

It\'s a Gnome!  Do you think all 10 year olds have cute butts');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('24', '19599f9927', '', 'Why have a private forum? ..I mean, who the hell is going to read this? heh..');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('25', 'ff93f7d489', '', 'some i saw this 14 year old on myspace that made me cream myself omg her fucking tits were so voluptoous');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('26', 'ee8d83c31c', '', 'Link?

One time we were talking about how hot this one chick is we used to party with, and one of my buddies goes &quot;Ya ... she has an ass like a 10 year old boy.&quot;


Not really sure wtf he meant by that ... but we laughed.

So yes, some people do think 10 year old boys have nice bums.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('27', '65518edc3c', '', 'mother should i trust the government?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('28', '2df297d69f', 'WOW: Burning Crusade. Archimonde?', 'So whats up guys I was told to play wow on archimonde and that everyone will be reactivating! fuck yeah! letes play. why archimonde and not a new server like altar of storms? lets discuss!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('29', '33723f3a95', '', 'I think it would be a good idea to keep everyone on the same server. 

It would have been like us switching servers everytime we quit UO. How willing do you think people would have been to come back if they had to start over everytime? =) My point however is that if everyone sticks to one server then I think people will be more likely to not only play there too, but stay there as well.

This is why I never came to play with you guys. I didn\'t want to play for a
month or two and have you guys quit and change servers. (as was done several times heh)

-Aries');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('30', '6e867fa37a', '', 'Yeah me ros corn pops and 2 rl friends of mine already have 60s on bloodscalp and i actually play daily and have for a long time.


I dont know where everyone else is

send lakkin a tell ingame');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('31', 'c0de3a6159', '', 'the only other server id consider is altar of storms with everyone that server is hoppin me and endo got horde chars there');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('32', 'cef229d29d', 'Donovan', 'if you come across this post brian,sean, john smith whatever.  Drop me an email dev.null@cox.net i live up in the bay now.
-philip');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('33', '014aea9fee', 'DarkFall', 'www.Darkfallonline.com uo and beyond check it');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('34', '0d41b52f40', 'Memories....', '[img:0d41b52f40]http://deniedproject.net/images/wowmem.JPG[/img:0d41b52f40]

[url]http://deniedproject.net/images/wowmem.JPG[/url]');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('35', 'f25e099d04', 'wow...', 'And I thought WoW was gay before I saw what it looked like...');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('36', '3409806853', '', 'If we didnt switch shards every 10 days we\'d all probaby still be playing WoW.

IF you all sign a contract to stay on the same WoW server for over a year I will come play there :P');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('37', '1742718593', 'Wow this is completely fucked read guys.', 'Umm yeah me and laura broke up for like 2 weeks and i fooled around with this girl we didnt have sex nothing i touched her tits and she rubbed my dick i didnt even ejaculate cuz i freaked out and was like i still love laura blehblehbleh long story short

2 weeks later i get picked up by the cops on 2nd degree rape charges with a statement saying that i &quot;forced her to give me oral sex&quot;


THE FUCK NIGGA


got me damn good lawyer and hopefully ill be acquitted
theres 0 evidence in the case and its just this stupid bitch making an allegation.

After I win I\'m suing the shit out of her.

If not my home phone # is 508-771-6097 and ask my madukes where they got me at if u wanna get in touch with me fucking christ guys and me and laura got back together and i fucking proposed to her and then this shit happens.


Preliminary hearing is set for Aug 28th 8:30am

hopefully they dont Indict me and realize that this is abullshit case by some fucking psychotic bitch.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('38', '0854fbf224', '', 'if i wasn\'t facing 6-10 years for a crime i didn\'t commit i\'d still be on bloodscalp

instead im spendin time with my friends n family who are payin for my defense attorney');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('39', '5b14d631ae', '', 'Man, thats just so wrong Lakk.
Wish you luck!

Geno (Genosis)...');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('40', '34e441523a', '', 'SUP GENO hell yeah long time no see. Yeah the whole situation is fucked im lookin to serve a couple years in jail for somethin that neverh append but i got a fucking awesome defense attorney one of bostons top lawyers. My family shelled otu a hella amount of cash plus he gave us a discount cuz hes defended other familiy members of mine thruout the years. my grandmother on a suit after a scandal in the massachusetts dss and some shit tied into whitey bulgers shit i dont even know all the details i just kno someone tried framin my gma with soem shit and fired her and when my uncle got popped for flyin a plane from panama to kentucky with 410 keys of coke,, my uncle got 3 years instead of life cuz he managed to like surpress a buncha evidence and not link him to shit or something again im not even sure of the details..

worst comes to worst and the case looks bad im lookin to do like maybe a year in county and in even a worse situation im look at a max of like 3-5 maybe less. whatever life goeson kid this bitchis fucking crazy... worst part of all of this is im fucking engaged.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('41', '0dc4bfaf19', '', 'You are a hard ass thug.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('42', '2b44973f21', '', 'Been kinda hooked on WoW thanks to my brother, played a regular server for quite awhile..
Getting kinda semi bored with that right now thou');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('43', 'c2251375e3', '', 'not at all im fuckin pussy');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('44', '9d22c92bf0', '', 'I was just fucking with you bro, I hope all that shit clears up for you, woman can be quite the headache I think every guy will attest to that.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('47', 'a54b6e86f3', '', 'whats the moral of this story?

More games. less tits.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('48', '209c1c7014', '', '3 years atleast before eligilbilty for parole atleast from what i\'ve read and in that case id have to admit to something i never did... fuck it


i want a lie detector test but i read a buncha shitabout how evenppl tellin the truth fail em if they are anxious n shit');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('50', '451b0fad22', 'SAS, WoW what server?', 'So I am playing on WSG battlegrounds on WoW and this guy from frostmourne server has &lt;Sinners Among Saints&gt; tag I flip fucking out and whisper him like a 17 year old girl and a brand new cell phone.  I ask him some questions to see if he is old school or just wanna be.  He didn\'t know what UO Sonoma was so I assume he is just from WoW or ignorant of SAS History or just coincedence.

Oh yeah and hey.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('51', 'ad2185b01b', '', 'Dav shut up and come back to Sonoma.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('52', '7d58c43771', '', 'dude the new graphics of UO look acctually alright man

too bad no one plays anymore

except you Garen. lol');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('53', 'ded0081f57', '', 'I think that a few of them are playing WoW still ... as for server, well that changes every week.

Good to see you locke, good to know the only other member of FP is still alive :D');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('57', 'e0bf16e082', '', 'Dyn Mega is dead?

Dun of Rhuarc plays WoW on Blackrock with me.

Wasnt he one of your boys?

-Davin');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('58', '40ff28a7f6', '', 'Actually I think Dun was also an honorary FP member, Dyn really liked him.

No Dyn is still alive I just meant besides us :p  Blackrock eh? You guys still playing there?  It seems a lot of people from UO are playing WOW, I know a lot of the old M guys are, along with some of the OGD clownzors and BLD.

All on seperate servers though, way to many servers in that game.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('64', '6f5c19d9de', '', 'haha what....? oh wow... crrrazzyy bitch.

Lakkin you\'re a trip bro.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('65', '2256e95b1c', 'Hey', 'Jason!  What up!
miss you much,
Philip!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('66', '38b2d70696', '', 'Lakkin, get a good lawyer.

At the very least you shouldn\'t really get charged with rape, you should be able to get off fairly easily but eh  good luck and don\'t stress too much');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('67', '3919876663', '', 'its an obvious fucking lie

who the hell in their right mind says

&quot;no i dont care about you saying no&quot;

or &quot;i dont care&quot;
he said he didn\'t care

what the fuck?!@!?!?@!?@!? yo who the fuck would put themselvse in a position like that she makes me sound like the fuckin boston strangler');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('60', '081cc955f5', '', 'Hi Davin!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('61', 'fdd5f55c28', '', '[quote:fdd5f55c28=\"Dakkon\"]whats the moral of this story?

More games. less tits.[/quote:fdd5f55c28]

Well said... kind of... i mean... tits are nice too...

PS fuck you dakk =)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('68', 'aa53521776', '', 'If I was you i\'d just start having sex with men because you don\'t seem to have good luck with women.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('69', '4c09440802', '', 'fukin bitch, call me.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('70', '3d20a03e4f', 'Rad is a little bitch.', 'what?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('71', '63282a390f', '', 'Hey DC

Yeah the core of the guild on blackrock is UO sonoma guys.  Pretty much we have hit a brick wall and are waiting for the expansion.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('86', 'c774b923a8', '', 'I told you not to tell anyone about those dreams James.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('87', 'd598119f95', '', 'davin, check out metropolis uo shard
i just started!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('88', 'd3b8acfc8d', '', 'dude no way you are serious its like playing diablo man.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('89', '91c5571a49', '', 'UO Eh?....  Most of my free gaming time is with WoW.

I\'m suprised people still play UO... Really that much fun still?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('90', 'a5e2bf688d', '', 'DC and I play on Pac, well I don\'t really play atm because i\'ve got a full term of classes ... but I have a lot of fun.  You die really fast now a days, and people run a lot more, and a lot faster, but it\'s still the same UO when you break it down to dueling and grp fights, just new tricks.

It\'s still the most fun MMO out there IMO .. except maybe WOW, but WOW is 100x the time sink UO is.  UO is an afk char builder with a mild item farming depending on how good of a template you want.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('91', '4824cf5643', 'Props to the new Site Design', 'Looks 400% better than it used to, good job.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('92', 'eea0bf40e8', '', 'www.Darkfallonline.com
Anyone still using vent?
Rad: I forgive you from before but not for playing wow.
My Balls--&gt;(_)_)/__|&lt;-rad\'s chin');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('63', 'f862325f8f', 'dude read this bullshit', 'Entire Statement Written on 12-18-06
	I WAS GOING OVER MY FRIEND PAT\'S HOUSE SOMETIME AFTER 1AM ON THURSDAY GOING INTO FRIDAY. WE WERE UPSTAIRS HANGING OUT WITH HIS TWO BROTHRES HIS TWO BROTHERS WERE FALLING ASLEEP ON THECOUCH IN HIS LIVING ROOM. SO WE DECIDED TO GO DOWNSTAIRS TO HIS ROOM IN THE BASEMENT. WE WERE SITTING NEXT TO EACH OTHER ON THE COUCHI N HIS ROOM. I WAS NOT MAKING ANY PHYSICAL CONTACT WITH HIM WHATSOEVER HE STARTED TO PULL DOWN THE TOP PART OF MY TANK TOP.I WAS JUST SITTING THERE. THEN HE STARTS TO TALKA BOUT HOWBIG HIS PENIS IS. HE TAKE MY HAND AND PUTS IT ON HIS CROTCH. MY HANDWERE AT MY SIDE WHEN HE UNZIPPED HIS PANTS. THEN HE STARTS TO FEEL ME UP AGAIN. THATS WHEN I SAID NO I DONT WANT TO DO ANYTHING HE SAID THAT HE DIDNT CARE. HE GRABBED THE TOP OF MY HAIR AND PULLEDM E REALLY HARD TO HIS PENIS AND FORCED MY MOUTH ON IT. WHEN I PULLED MYSELF AWAY I SAID NO I DONT WANT TO DO THIS I KNOW I SAID NO MORE THAN TWICE AFTER TAHT HAPPEND HE GRABBED ME BY MY HAIR EVEN HARDER AND FORCED MY MOUTH ON HIS PEINS AGAIN THEN H E SAID I DONT CARE ABOUT ME SAYING NO. I WAS PUSHING AWAY FROM HIM AND TRYING TOG ET HIM TO STOP. THATS WHENI THOUGHT HE WAS GOING TO KEEP RAPING ME SO ISTARTED TO CRY. HE STOPPED WHEN I STARTED TO CRY HE SAID SORRY AND HE THOUGHT I WAS SENDING THE WRONG SIGNALS TO HIM. THEN I SAID I DONT LIKE HIM LIKE THAT AFTER WE TALKED HE WAS STILL MAKING PHYSICAL CONTACT. I THINK HE WAS RUBBING MY BACK OR MY ARM THEN I LEFT HIS HOUSE A LITTLE BIT AFTER 2AM THE NEXT DAY MY CAR RAN OUT OF GAS ON THE TO WORK I COULDNT WALK TO WORK BECAUSE I WAS SO ACHY FROM PAT WHEN I FINALLY GOT THERE THE MANAGER OPF THE STORE SUSPENDED ME. THIS WHOLE EXPERIENCE AS EFFECTED MY JOB AND MY LIFE. NOW IM TRY TO PUT MY LIFE BACK TOGETHER AGAIN



what the fuck? does this make sense to anyone thats what this cihc wrote.

who the hells ays &quot;i dont care about you saying no&quot; lol??? i hope someone with half a brain is prosecuting this case and can just see thru the bullshit');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('93', 'a642959e1b', '', '[quote:a642959e1b=\"Locke of SAS\"]dude pretty much mmorpgs are bland


I want to kill people loot them dry and rob their house. 

Instanced bgs and twink gear is kinda bland you are right.[/quote:a642959e1b]
[url]www.darkfallonline.com[/url] &lt;-Play this when it comes out.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('94', 'a3e4f82b5b', '', 'When are you going to stop blaming me for Zeeks failures to pleasure your tiny peen?

 :shock:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('95', '8b0ef45c65', '', 'ya you can read all my court documents at


http://pyardsvsrapecharge.blogspot.com


it evolved from me trying to force her to give me head, to me touching her and then forcing her to give me head to me visciously face raping her while saying NO I DONT CARE ABOUT YOU SAYING NO


dude who says that? jesus christ');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('73', '6100856ed6', '', 'NO F-U MAN!!@!@!~~

Anywho Lakkin rape is hard to prove, for you and her.  Get a damn good lawyer and make her fuck up IN COURT, dont fucking say a word to her dumb ass unless it is in front of 12 honest men :P');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('74', 'e076c34548', '', 'hey mother fuckers

Me and Mut were FP too, ask Dyn bitches');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('75', '43f7f2ebce', '', 'Thats true, and so was Palou.

Damn ... ok I guess there was a few more than I thought, we whored that guild out like Dyns asshole at a star trek convention ...

I\'ve been considering giveing wow try # 1232423112321323123121121231.

Jus wish it didn\'t take so much damn time to level is all ...  you guys horde or alliance?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('78', 'd966ab56c7', '', 'of course we are horde man, alliance are bitches that cant win in pug BGs');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('79', '21d15c54a6', '', 'wow is bland.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('80', 'd34116f487', '', 'dude pretty much mmorpgs are bland


I want to kill people loot them dry and rob their house. 

Instanced bgs and twink gear is kinda bland you are right.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('81', '5c4091a0b9', '', 'You\'ll prolly end up getting some sort of aggrivated sexual misconduct or something charge if you have a good lawyer, but then again depending on what state it is you could have some tough times ahead, like i know some states you can\'t use mental illness on her part as a defense etc =/

and dakk, fuck you =)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('82', 'f525c3721f', '', 'but comical none the less');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('83', 'd82976ccc3', '', 'WOW is a gay fantasia');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('84', '216eb08666', '', 'Jason, I\'m playing UO metropolis a pre uo:R shard.  Come join me.

-philip');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('85', 'ca3db90c72', '', 'or play UOGamers
the biggest pre uor shard...
nightly GM run pvp events, football, tourny\'s, etc etc');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('77', 'ec7be0f42f', '', 'Now that\'s just mean.

 :D');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('96', 'be8efc4e2b', 'Pictures wanted!', 'Hey guys,

If anyone has old screenshots laying around, maybe on an old 
hardrive, I would love to put them up on the site. I would like 
to get some non-UO screens up too if possible.

You can post a link to them here or get in touch with:
me at aries@sasguild.org or access or dev.null@cox.net

-Aries');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('97', '9db28198fb', '', 'I don\'t let the Brittish anywhere near my penis.

zeek\'s a pothead now.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('98', '4a7df62594', 'southpark', 'http://media.southparkstudios.com/downloads/download.php?file=/media/SPinWoW.avi');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('99', '98c4f22469', '', 'I wonder how much bliz is paying them for that.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('100', 'c9b044211a', '', 'nothing.  they are rich enough.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('101', '556476e818', '', '[url=http://www.powerpuffgirls.com]They arn\'t promoting wow they\'re making fun of it, didnt you see the preview on tv where they\'re all obeese and zit faced[/url]');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('114', '8c923f02d8', '', 'wow, yea dude get a good lawyer and hope for the best');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('102', '94b5ba766a', '', 'Ya the site looks very cool, also glad you have those SS I thought I lost them with my last wipe.

I have an old CD with picks but it is scratched, every time I put it in my CD Rom it works for 2 seconds then freezes up :/

Has all my old pictures, but nothing older than probably SP ... lost those with an older wipe.

Dyn might though i\'ll ask him.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('103', '5ce2e9480d', '', 'ya good job aries or phil or whoever did it');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('104', '7b899b5304', '', 'i used to have tons of pics of massive battles on ipy');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('105', '4508272cd8', '', 'Hey locke who you all playing with from UO on Blackrock?

I have some RL friends on Tanaris ... I might play again .. watching south park made me miss wow and how it controls my life :P');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('106', 'bad044cdbd', '', 'hahaha BC

we are on Blackrock

Wardens of Asylum is the guild

Myrkul, Shylock of Yew, Dun of Rhuarc, clan locke

[url]www.wardensofasylum.org[/url]');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('107', '1bb93faf70', '', 'Myrkul?? He was my boy ...

It\'s team RP there eh?

If I rolled on that server would I be cool enough to play with you guys? :D

I will probably give up by about lvl 40 so I don\'t want hand outs, but as long as I have someone to talk to while I level I am happy :P');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('108', '9c0b22e172', '', 'yeah plenty of people to talk to my man apply on the boards I will get you invited, by me.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('109', 'bf41972bd2', 'Oldies But Goodies', '[img:bf41972bd2]http://members.cox.net/jtomasek3/Uo/Daboat.jpg[/img:bf41972bd2]

[img:bf41972bd2]http://members.cox.net/jtomasek3/Uo/Horse.jpg[/img:bf41972bd2]

[img:bf41972bd2]http://members.cox.net/jtomasek3/Uo/HouseLoot.jpg[/img:bf41972bd2]

[img:bf41972bd2]http://members.cox.net/jtomasek3/Uo/Pagan1.jpg[/img:bf41972bd2]

[img:bf41972bd2]http://members.cox.net/jtomasek3/Uo/Pagan2.jpg[/img:bf41972bd2]

[img:bf41972bd2]http://members.cox.net/jtomasek3/Uo/Pagan4.jpg[/img:bf41972bd2]

[img:bf41972bd2]http://members.cox.net/jtomasek3/Uo/Pagan5.jpg[/img:bf41972bd2]');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('110', '64ad6b2a4d', '', '[img:64ad6b2a4d]http://members.cox.net/jtomasek3/Uo/Pagan6.jpg[/img:64ad6b2a4d]

[img:64ad6b2a4d]http://members.cox.net/jtomasek3/Uo/Pagan7.jpg[/img:64ad6b2a4d]

[img:64ad6b2a4d]http://members.cox.net/jtomasek3/Uo/Pagan8.jpg[/img:64ad6b2a4d]

[img:64ad6b2a4d]http://members.cox.net/jtomasek3/Uo/Pagan9.jpg[/img:64ad6b2a4d]

[img:64ad6b2a4d]http://members.cox.net/jtomasek3/Uo/Pagan10.jpg[/img:64ad6b2a4d]');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('111', 'f75ffc6b14', '', '[quote:f75ffc6b14=\"Access\"]WHAT ARE YOU? SOME FUCKING KIDS?[/quote:f75ffc6b14]

Go back to playing your video games, kid.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('112', '770944482a', '', 'Damn looks like I missed a good time there.

God damn university getting in the way of my gaming ... that wasn\'t the first time either!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('113', '85dbdd492d', '', 'I made it to level 10 on a priest, re rolled to a shaman made it to level 10 and gave up.  I don\'t have the time to commit to leveling in that game, 5 classes this term :(

One day I will return to the glorious WoW, once they nerf time invested.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('115', '0273946b43', '', 'WOW = for little Homo boys.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('116', 'b0c1473850', '', 'UO = for sentimental cockmonglers

DC, You make the call.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('117', 'cf9c737ec0', '', '[img:cf9c737ec0]http://www.sasguild.org/images/arrkitten.jpg[/img:cf9c737ec0]
Arrrrr!!

[img:cf9c737ec0]http://www.sasguild.org/images/kittysd1.jpg[/img:cf9c737ec0]
This picture is sooo cute!

[img:cf9c737ec0]http://www.sasguild.org/images/funny.jpg[/img:cf9c737ec0]
hehe

[img:cf9c737ec0]http://www.sasguild.org/images/hate1.jpg[/img:cf9c737ec0]
I\'m the rogue in the back of R\'tal

[img:cf9c737ec0]http://www.sasguild.org/images/besthubble1.jpg[/img:cf9c737ec0]
There\'s more than just space out there..

[img:cf9c737ec0]http://www.sasguild.org/images/cristy.jpg[/img:cf9c737ec0]
...something for everyone ^^

-Aries');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('118', '39bb9e2032', '', 'Wow I forgot how shitty EQ graphics were.

Whats that space picture of Aries?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('119', '3c5a49adde', '', 'I\'m not sure what the name of that galaxy is... STScl/AURA maybe? hehe,  I dunno.

It\'s amazing how many other galaxies are out there...  Each one has a countless
 number of stars of their own, and each star has  a chance to have planets... it\'s
 fun thinking about what could be out there  :shock: 

-Aries');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('120', 'b923b725d1', '', 'T we could have soooo many awesome talks about that, I took a class when I was doing my undergrad on &quot;Search for ET Life&quot; was awesome! There\'s ALOT more variables then that for a planet to have life on it, but yea considering how many planets there are there are alot of possabilities. And also remember it doesn\'t necessarily have to just be Planets. Planets orbit the star, but moons of planets at the right distance from teh star, with the right elements etc could also have life =)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('121', '13f59389e0', '', 'Nah Locke, there\'s nothing nostalgic about UO for me. The past is the past and the old UO is honestly a completely different game in alot of ways then the UO now. I mean I still mainly just kill and grief people and have big guild fights, but it\'s no where near the same =&lt; when I wanna be nostalgic about the old UO then I think about the days of SAS in UO, but other then that it\'s mostly about the new UO being alot more fun for me then WOW.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('122', 'c3267b3d37', '', 'I can attest to that, the new UO is in a lot of ways 100% different from 2001ish UO.  Basically ... its item based now, but what game isn\'t?

It\'s still a lot of fun to play, but I can\'t help but think of the glory days while I do play, so it kind of kills it for me :/');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('123', '4f1c9b66e9', '', 'yeah think of how many people would still be playing if they didnt do a few things to the gamestyle.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('124', '524ca9ab1c', '', 'Locke what is your char name on blackrock, me and skeletor and a few friends started 3 tauren druids a tauren shaman and a tauren hunter for a fun bg group and maybe we\'ll actually stick with them, who knows......oh and hi bitches......');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('125', '9b85e99a9d', '', 'I enjoy watching the skies as well. That picture is of the commonly known as Sombrero galaxy....

[url]http://www.space.com/php/video/player.php?video_id=when_stars_collid[/url]

I was on space.com earlier and came across that link... pretty insaine the chaos thats present in the universe... but at the same time it\'s amazing how complex of an \'eco-system\' it really is. Comets and astroids \'seeding\' fertile planets... galaxies consuming one another to only disperse the elemental compounds across millions of light years on jet streams that are now found to beam out of the center of black holes.... and thats only the tip of the iceberg...it\'s truly mind boggling....');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('126', '0d942ad49f', 'hey', 'fucking stoners.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('127', 'aefe263f59', '', 'Yep, you\'re right Rad. The name of the galaxy was in the original file name and
I didn\'t even notice :oops: 

Space is great, I hope I get the chance to go there some day... even if it\'s only suborbital.

Hey guys, post some of your favorite pictures!

P.S.   Hi Rad. it\'s been awhile =] Remember when we used to two-man mistmoore
         castle with Herlumphamatootsi? that was fun!

-Aries');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('128', '758b1ea7a6', '', 'NERDS!!!!!!!!!!!!!!!!!!!!!!!!!!!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('129', 'e026f63bbf', '', 'Rad is a bitch....');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('130', 'a15e2b61cd', 'Just moved my WOW char to Blackrock...', 'give me some of your guys names on that server -- i\'ll message you when I am around. I\'m transferring a 49 undead rogue :)

Ciao for now :)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('131', 'ec50edebd8', '', 'BTW, the character name is &quot;Herculeez&quot;

Invite me! :)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('132', 'ab25ffc680', '', '&lt;----- Oh god where did you find this pic?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('133', '59a0c07114', '', 'Wow wow, Grinch is still alive?  Holy poop sticks batman.

Grinch you still DAoCing it at all?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('134', 'cf64826a76', '', '[quote:cf64826a76]Bc  PostPosted: 22 Oct 2006 11:35 pm    Post subject:
&lt;----- Oh god where did you find this pic?[/quote:cf64826a76]

When I saw that picture I thought of you. Do you like it? =]
You can goto &quot;profile&quot; and upload a new one if you dont, hehe.

-Aries');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('135', 'f20e504f7e', '', 'Whatever I don\'t care :p Pokes some fun at my old tittle.

The OGD guys I think origially posted this pic a few years ago, I think it was Gonzo who found it.  I laughed my ass off when I first saw it :p');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('136', 'c79133653e', '', 'I think I re-found it on PKP, and you got pretty pissed off at me. :P  :D');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('137', '93235986ab', '', 'Yessah still alive in Oklahoma, just doing some flowhand work in the oilfield saving up some moneys atm...nothing much new here skeletor is on like his 19th year of college at OU....as for a major that changes every 10 mins.  Really just the same old boring brothers standing on trinsic bank trying to act like we\'re important.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('138', '166deab409', '', 'Because it is racist.

But Aries is allowed to be racist because he has a small penis, do you have a small penis Pagan?

My asshole would say no.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('139', '1d630ca630', '', 'Good to hear from you guys, thanks for saying Hi only once in about 10 years.

Fucker.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('140', '05edaaa55a', '', 'Larry the low dog is a lurk.... good to see you and Skele are alive.  We play old UO style on free shard... come play.. 

-elstow.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('141', 'f824253cc3', 'Vent', 'Those who are playing UO and do not have Vent, nor a mic, better grab it.  No way in hell are we playing Uo these days without Vent.  That being said, do not let me think it was a waste of my time to log onto &quot;ANOTHER&quot; shard to play.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('142', 'a9a0a4f583', '', 'Nerd!!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('143', '0f393f4229', 'Rape charge dropped.... well reduced they reduced it', 'im not longer being charged with rape!!!!


now im being charged with &quot;indecent assault&quot;
the charge as if i slapped a chic on the ass without her consent...

hopefully next court date they just toss this shit out once and for all');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('144', 'f6f324ea57', '', 'Congrats');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('145', '99e5a7d1f0', '', 'hey man me, skelly, and a few friends started last week here, so far level 24, 3 druids and a shaman, my name\'s Mbison...still haven\'t been able to get ahold of Locke though dirty bastard has us move here and now won\'t log in');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('146', 'ea2eb05927', '', 'chea

i found out i cant sue the bitch tho afterwards ;[

fuckn christ');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('147', '60b512ba6d', '', 'asd afasj asdha asdhaha');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('148', '3a32233b18', '', 'Pagan got recruited into this new runUO shard?

I feel the vortex sweeping my way ..');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('149', 'd7a9128a86', '', 'OMG BC

... they finaly nerfed talon bite/bushido mages/parry/evaison etc.
=) and =(

yaay cause it means the evaison mages are gone, but bad cause my talon bite is nerfed and now the parry on DC does nothing =/');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('150', 'beb6038b77', 'Ultime On-Line', 'So.. i\'ve been here for a moment.. we have a lot of people on board for a second...
lookets like we are playing uo as a unit and we can use this thread to discuss issues..

Right now.  I have a Villa and a small house.  Everyone is welcome inside.. just pm me in irc and i will help you.  Herc/Corn are nearly finished and have money and such.  I\'d like you all to not be such IRC warriors in #metropolis... no talking till you guys start doing things...  uh.  I expect to see everyone fighting .. often.  if you suck we will be disappointed. :shock: 

uhg.. anyone wana make a carp? tamer? shit like that? post it here.. what type of char yer going for.. 

WE HAVE COMMUNIAL:

Poisoner/Alchy/Smithy/Tinker/Carp.

and plenty of murderers right?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('151', '8b3b59eacb', '', '[quote:8b3b59eacb=\"Bc\"]Pagan got recruited into this new runUO shard?

I feel the vortex sweeping my way ..[/quote:8b3b59eacb]

So far, it looks like its going to be easy picking for the Pag');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('152', '01b9bdcfb6', '', '*BUMP* GET A MIC!!!!!!!!!!!!!!!!!!!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('153', '663e79cbf5', '', 'Shut up twizzler dick.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('154', '52e13dbc82', '', 'Get a mic...');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('155', 'e9476942f5', '', 'Post me infos... I\'ll macro some shit no problem.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('156', 'd51e65d320', '', 'hell yeah.\'

metropolisshard.com

irc.gamesurge.net #sas.. faggot.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('312', 'b50cfe479b', '', 'My account isn\'t even active anyway, and I don\'t have any good gear.  All of my guys were in shitty templates and I am poor.

Tell OSI or EA or whoever runs UO now a days to make a classic UO server.  Thanks.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('159', '15ed8fce88', '', 'Almost 7x, 2 more resist to go!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('160', '53a83c686a', '', 'Rad! Whats up man? You still messing around in WoW?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('162', '2adf48d9be', '', 'Sup homes... =)... I played for a bit; maxed out a 60 druid.. pvp\'d a little... did the whole top guild server drama and realized it wasn\'t worth it for a second time... haven\'t played since...');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('163', '50d5f8792f', '', 'I heard in WoW that the top \'uber\' guilds raid like 6 days a week for 4 hours a day?  Is that true?

And they rate their members according to how active they are on raids?

Like people play all MMO\'s that much, but to have schedules just makes it seem so much worse for some reason :p

In other news my Pally is almost ML 10 and ready to pwn in the new dungeon in daoc!!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('164', '54383cf45e', '', 'Shut up nex.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('176', 'b63634cec8', '', 'Christmas was canceled by my Dad, he told me that Santa is dead because he slit his throat and fucked his dead corpse.

As I was crying, my Dad rained blows down upon me, laughing and calling me a &quot;little pussy&quot;.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('171', '3ff58be1c7', '', 'metropolisshard.com looks cool, I tried to play but UO Gateway didn\'t work so I said screw it.

I\'m sure by you\'ve all pulled the famous SAS split to another game anyway.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('172', '1db679cd02', '', '[quote:1db679cd02=\"Garen\"]metropolisshard.com looks cool, I tried to play but UO Gateway didn\'t work so I said screw it.

I\'m sure by you\'ve all pulled the famous SAS split to another game anyway.[/quote:1db679cd02]

Naa, we are still here.  We brought you up in IRC the other day.  Rumor has it you still play Sonoma.?!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('173', '87ab3a66a3', '', 'Now that EA bought Mythic I hope they are looking at how popular the Classic server setting has been in DAoC.  It is the most populated server, the single server of Gareth hosts more players nightly than any other 3 or 4 server cluster combined.

EA should be saying by about now Hmmm... that ain\'t a bad idea.  Classic UO with Tram for the PvErs but pre cast or at least pre AOS style figthing.

A classic server wouldn\'t work without tram, people need a safe place to run and hide, and besides there is already SP for the tram haters.  If you want the server to be populated you have to put up with the law lovers and in turn you get a good community and people to fight.  Similar to what Sonoma was.

One day it will happen, one day.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('174', '3025523b00', '', 'why would they do that? it would be what you wanted, OSI was never good at that.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('175', 'b0c2a1479f', 'What\'s everyone doing for Christmas?', 'Just curious what you all are planning for the holidays.  I\'ve been saving up so I can try to get my friends/family/girl some cool presents.  Other than that it\'s just the normal family dinner kind of deal.  

I am meeting my girlfriends extended family for the first time, so it should be pretty interesting.

Hope everyone has a good one!  Would be awesome if we could all get together again sometimes, Vegas perhaps?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('311', 'cd256c2a69', '', 'hheh no ros would feed me mdma and put the drag on and take advantage of me i bet when ur rollin ros with make up is a hot brunette');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('168', 'fba0cb9534', '', 'I bought a priest w/ t3 gear and played in the suicide kings for like a month.  It was horrible. Promptly resold the account, hehe.
  
If I had no life, job, or school I would have probally loved it though! (I remember the days of falling asleep/waking up to wow, hehe)

-Nexus  (Posting on Jason\'s account because I locked mine with the wrong password)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('169', '9922670ca7', '', 'You guys should come play DAoC, its a lot of fun :)

Its OmG uber PvP compared to WOW, its the best pvp I have seen in any game since pre cast UO.  OSI PRE CAST UO, not player run timer is wrong pre cast UO :P');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('170', 'c73207c49e', '', 'I like Vagina. 

BC FL went and invaded Origin... you\'re missing it =(');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('178', '2fc7711f3c', '', 'whoa..  Canadians are hardcore!

Personally, I hate the holidays...');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('179', '2a67374ca4', '', 'gettin a telly and banging ros\'s gf');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('180', '4c03231143', '', '[quote:4c03231143=\"Aries\"]whoa..  Canadians are hardcore!

Personally, I hate the holidays...[/quote:4c03231143]

How can you say that?  Christmas is my favourite time of the year, hockey, gifts, drinks, hockey.

Whats not to love?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('309', 'ace0bf1fc8', 'meh..', ':shock:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('310', 'd4a7c975df', '', 'did that rape case really even happen? :|');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('184', 'f34bf86485', '', 'since when do black people play hockey
theres like 5 black people that play hockey in the world');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('185', '7106202e4f', '', 'Killing the jews.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('187', 'b5965419c9', '', '[quote:b5965419c9=\"Lakkin\"]since when do black people play hockey
theres like 5 black people that play hockey in the world[/quote:b5965419c9]

Actually we did a count at the last race meeting and we have 7.5.  Iginla is only half.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('188', 'b3092146d4', 'Good times ...', '[img:b3092146d4]http://www.sasguild.org/images/sasuo/MickDeadk.jpg[/img:b3092146d4]

Looking forward to a new game for us to all play again :P');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('189', 'ef2892cf16', '', 'Hey look theres me on Harle! Dont i look every so sexy?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('190', '5a481207e3', 'Googled!', 'Got to love search engines.... Yes I\'m still alive bitches

Plenty of stories to tell! I\'ll make it a habit to jump on irc more then twice in 2007, I promise!

If any of you really need to / want to reach me, dan.albu@nekstlevel.com


adios!!!!!!!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('191', '6900d3b4b5', '', 'What have you been doing these past few years Mr. Arkaine?

P.S. Leafs suck trade Sundin to the Flames for a pick.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('192', '0c7e51d3a8', '', 'Hi buddy.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('193', '5dd04188cc', 'hey fuckers', 'whats everyone up too, i need to find manson/ferg...  Im playing wow still 


peace.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('194', '5307a95e54', '', 'Have not talked to him since IPY.  Didnt you guys go to Vegas together? And you lost his number? Wow what a friend..............fucker!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('195', '204b3aa384', '', 'im on burning blade , if anyone wants to come over or we have a central server everyones going to I may move.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('196', 'e0d63f683c', '', 'I quit WOW.... bored of grinding :(');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('269', '74cf19e882', 'i like men', 'haha...    


&lt;haties from pagans house&gt;');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('198', '1bb4e65e29', '', 'xpac in 4 days!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('199', 'bb88b6ff4e', '', 'word, ill be there.  too bad im on a different server and faction  :P

oh well maybe ill multi shot u fags to hell one day in a BG :P');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('200', 'b575b80c28', 'Hey guys check this out', '[url=http://www.guildcafe.com/member/Blitz]CLICKY CLICKY[/url]

Its like a gamers Myspace, this way we can always find one another, i know for a fact theres alot of SAS we will never talk to again, this will prevent this in the future.  My handle now is Blitz.  So add me to your friends list when you sign up.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('201', '1a4301bcfb', '', '[quote:1a4301bcfb]i know for a fact theres alot of SAS we will never talk to again,[/quote:1a4301bcfb]

That is one reason why we have had an IRC channel up since 1996. ...however, some people just don\'t [i:1a4301bcfb]want[/i:1a4301bcfb] to be talked to again.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('202', '5ba277db5d', 'fuck that webshit', 'fuck that webshit dak.  That is some highschool shit right there.   Get your Bull raging texan ass back in irc or you and all the other \'sas\' guys out there are quite not!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('203', '0cb23c9f8b', '', 'Ok yea, that\'s gay.

I perfer the message board and occasional IRC drop ins =) 

BC and I talk all the time in the UOzorz');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('204', '6d17121fbc', '', 'yeah irc is best mode of communication a few of us are myspacebuds
me nex cory ivan a few others');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('205', '3f6a61ac9b', '', 'meh, i just wanted a way to keep in contact, not lame ass irc that is as idle as this guild.  whatever though, some ppl adapt some ppl fade away.  Have fun in UO guys...');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('206', 'e61bf08042', '', 'LoL so we aren\'t adapting because we won\'t use your shitty guild myspace that like 5 other people use?

I am not a fan of myspace so I refuse to sign up for it.  And if adapting to video games is investing 4-10 hours a day killing mobs then I am quite happy where I am :)  Have fun in WOW.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('207', '3c8e81021f', '', 'arkaine, i heard your in toronto for film. i was hoping i could talk to you about some stuff. come in IRC and message me');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('208', '947b78cfa5', '', 'Film!?

What the hell you frajoules been telling people about me?


I\'m born and bred Toronto, yes! Film... not so much.

Odds are you may catch me on irc sometime in the newa future, but if not... just shoot me an email!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('209', '9d71bf4727', '', 'This thread reminds me of the South Park WoW episode, hehehe.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('210', '4f2f99dbcc', 'Anyone interested in planning a RL meeting somewhere fun?', 'Was thinking we could redo a SAS meeting, or whatever its called, in a fun place like Vegas or some shit.  Haties, Fergazi, and myself went last year and had a total blast.  I met up with Jason on the layover towards Cincinnati and met him and his bride to be, which was pretty cool.

Just tossing the idea out there, location/date is obviously totally open to opinions.  I\'m just trying to gauge the actual interest in such an event, and to see who is willing to spend some money on a plane ticket/lodging to get this thing moving!

We are all getting older, schedules more packed, etc.  Would be cool to meet up with everyone before we are to busy to do anything like this in the future.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('211', '835fd0039c', '', 'I am in Vegas every other week for buisness.  Other then you, I think everyone is at least a state over from the city of sin..');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('212', 'd3ae800aa2', '', 'I\'m gonna be in vegas in May i believe...');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('213', '1a4353b2ad', '', 'I am more than a state over from Vegas :P

Pretty much count BC out of any meeting, unless it is in a state touching the Canada border I wouldn\'t be able to make it.  Law school next year I have to mentally prepare!  And get my average up :P');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('214', 'c095129391', '', 'Meh, I got a year left of undergrad still till law!

GPA is currently at 3.877, w00t');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('215', '88570c87f3', '', 'Ferg always vanished on us... hows wow going cory? I had to unload that priest I had on our server, to much money for the account!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('218', 'b6e33271a8', '', 'May eh? J, would you still be going there for business in May?
I\'d fly in for a weekend if you guys were down.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('219', 'cd70717e60', '', 'www.coachella.com

I\'ll be down in LA this comign April... Who\'s joining me? arkaine00@gmail.com');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('220', '4c612ccb3c', '', 'Yep, always in Vegas!

Rage back together?!!?! Thats awesome news!!!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('222', '5df1b5e018', '', 'one time gig

You fkers should come down!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('223', 'cd93a9253c', '', 'OR come to Saskatoon and check out all the Indians.

Ya... its awesome.  Comeon.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('224', '52c423e2f2', 'SAS vent', 'hey anybody know the dude with the handle boomhaur?

hes wicked gay');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('225', '5dfcf2923d', '', 'Ark I live in LA, so hit me up when your down.

Vegas May, yes? no? yes?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('226', '816a4477e0', 'down', 'I\'m down for Vegas in May. I turn 21 in April.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('227', '85057698dc', '', 'Eh, pedospace is lame... 
IRC 4 life... People that don\'t join are just lazy... 
IRC takes 0 resources because it\'s like 20 years old...
You can constantly stay connected to it...
Computers power consumtion is not much to keep on.
If you don\'t use IRC at all, shame on you... 

GET IN IRC =)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('228', '4177fc4650', '', 'Yeah, who the fuck told you Ark did film? ROFL

Sup Arkman? Did you enjoy that beta that I gave you and you disappeared on? (BTW, You didn\'t meet our agreement! I said to come on IRC more for it and you said OK... Bitchface) Anyways, What you up to now? I work techie for a residential Fiber company. Thinking about getting back into school.  I know you were into sys admin shit, you doing linux/unix or doing AD shit?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('229', '2c4e6fc0be', '', 'Lets get some dates worked out so we can buy tickets early.  I\'d like to save some money here!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('230', '26e0a35db0', '', 'Hrmm, pretty sure it is your sister.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('231', '703f56ec4f', 'Re: SAS vent', '[quote:703f56ec4f=\"Dakkon\"]hey anybody know the dude with the handle boomhaur?

hes wicked gay[/quote:703f56ec4f]

Yea, I do...ahah is he pissing you off?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('232', '591f9de181', '', 'Vent is gunna die soon. Moving out and need to cut expenses...');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('233', 'dec33f48cd', '', 'memorial day weekend? or the weekend after?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('234', '77c1a57230', '', 'BC come back to UO =( yea it\'s different, but the group stuffs still fun =(');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('235', '2cc822dc7c', '', 'I want to go to Coachella for Tiesto, Paul Van Dyk, and Benny Bennassi... Fucking awesome DJ\'s...');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('236', 'cdbd953a29', '', '[quote:cdbd953a29=\"RoSTraX\"]I want to go to Coachella for Tiesto, Paul Van Dyk, and Benny Bennassi... Fucking awesome DJ\'s...[/quote:cdbd953a29]

Yea I like drugs too');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('237', '51722f5671', '', 'Hippies.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('238', '3c8971e30b', '', 'so come fkers!!

J -

Its in Indio, close to Palm springs.. what is taht like hr drive?

Get a festival pass, they are still on sale!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('239', '55b7adbfcf', '', 'more like a 2.5 hour drive, maybe we\'ll see... I\'m pretty busy and relatively poor');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('240', '118e916efc', 'hey bc', 'I\'m an SA now... you should come play uo again =D');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('241', '4c61424840', '', 'Whats a SA?

I already told you man I can\'t play it anymore.. grp fights are alright, but just the game itself is so different.

I appreciate everything you did for me man, you made my time there fun while it lasted, until I just couldn\'t take the state of the game anymore.

I also can\'t stand half of the members in FL.  I will never claim to be good at this game in its current state, but 80% of FL sucks.  They win by numbers, then talk shit.  Take Lady Kiss for example, huge bitch, fat fucking texan loser IRL, talks mad shit on the boards when she plays a blue archer and watches 10 of us kill 5 enemies.  That isn\'t how I roll, never has been, never will.  Guys like Digi, Arycke and you make that guild fun, but to many fucking retards ruin it.  It was all I could do to not vent this on the guild as well, so I will vent it here on you :p

Thanks again for all your help and shit man, who knows one day I might play again, but for this spring/summer I am definately done with MMO\'s.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('242', '9f8514e434', '', 'ghey =P');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('270', 'e2212c1990', '', 'I knew it.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('271', 'f830629d68', '', 'me too ask ros he knows im legit fag');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('272', 'e31654e6c5', '', 'me and mojo been on blackhand alliance on wow .... kinda boring but oh well better than nothing.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('273', '76f02df543', 'WOW anyone?', 'Pops plays Smolderthorn Horde, Me and Mojo got newbs there. We got Draenei mages on Blackhand alliance too. IDK.. Wow isn\'t that bad its fun when you play with friends.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('274', 'e0e21f0a7b', 'Re: WOW anyone?', '[quote:e0e21f0a7b=\"Lakkin\"]Pops plays Smolderthorn Horde, Me and Mojo got newbs there. We got Draenei mages on Blackhand alliance too. IDK.. Wow isn\'t that bad its fun when you play with friends.[/quote:e0e21f0a7b]


Yea we did when the game 1st came out, and it became boring like all MMO\'s.  
Honeslty Pops is a fucking weirdo, fuck that goth ass.  I guess thats what happens when you become fat, find a girl that is willing to fuck you, and then marry her.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('275', 'a6b677e464', '', 'Who the fuck is Pops?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('276', 'd6b170003e', '', 'I think they are refering to &quot;corn pops&quot; the fag that tried to fake his own death like 8 years ago...');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('277', '6abf8012be', '', 'Yeah the expansion didnt deliver on WoW, it really turned it into EQ');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('278', '1313eed07d', 'Donovan is approaching Leo status.', 'that\'s right you silly fuck; fuck you!

-Phil');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('279', '321f73cdf0', '', 'Leo was my hero.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('280', 'd80c4ebb61', '', 'hey can i have your stuff? =D');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('281', 'fd2a0bc8fe', '', 'I don\'t know how DC can stand to play UO. Then again he did spend the first 3 years roleplaying so PvP is new and still fun to him.

:]');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('282', '08a7ce27c2', '', 'haha, nah I RP\'d and pvpd =P

then I quit for like 3 years, then came back.

But when I came back I did realize it\'s a completely different game, some times its worth it, and sometimes I weeks without playing. I think 1v1 pvp is dead, but i enjoy large 20v20 - 50v50 battles, those are fun haha

Now I just play super gimps that are annoying when there\'s nothing decent going on');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('283', 'c36355bf22', 'We\'ve been entered in Age of Conan and Warhammer Online..', '..guild betas.  To anyone who visits this Mboard I know it may look a little dead but trust me this is a guild posed to strike at the next available game, there just isn\'t anything out there right now to keep us together.

Be that game, unite us :D

If we are lucky enough to get selected i\'ll get a hold of everyone in IRC for info on beta accounts.

So if you are either game reading this pick us because we would love to beta your games!!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('284', '8cf7443923', '', 'Explain Access.

Garen you were my hero, until you quit DAoC.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('285', 'c628c46886', '', 'WoW is like raid feast 2007 now.  I watch a lvl 70 pally buddy of mine.. it looks brutal.  Scheduled raids against MONSTERS every night for a CHANCE at one piece of your gear?  Wow.  I\'d rather play DAoC or UO and just PvP all night.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('286', '1e2e2e806d', '', 'im in');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('308', 'bb0e8a0833', '', 'lol obviously the title caught everyones attention UO gamers is a mix of uo:r and t2a. Insta hits and precast yea but with some more combat dynamics.

Its not bad. Lets try it out.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('288', '2cdae7b130', '', 'Computer Games?! You are so 1997.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('289', '7c53977d5c', '', 'hey garen, how many times did you grandmaster blacksmithy in the last 10 years? :P

Hell, is there a single merch skill you never worked up that high.. or any skill for that matter?

heheh');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('290', 'cd3351223b', '', 'Three times, at 120 now.

Never touched taming or barding skills :]');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('291', 'e4c7837d76', '', 'heh, ole Capone is just an ingot smasher...

I have/had a GM Provoke bard on metropolis =)

She\'s fun =]  In fact, the third screen shot on the flash page off the main site is me and Access. FIRE!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('292', 'd696c51b1e', '', '[quote:d696c51b1e]So if you are either game reading this pick us because we would love to beta your games!![/quote:d696c51b1e]

wait..  they\'re going to visit our website first before choosing which guilds are accepted? ...We can kiss our chances good bye then! 

Perhaps I should delete the thread about lakkins rape case.. hrm.. hehehe');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('293', '8c9eb05ad4', 'SAS Reunion on Ultima Online... a freeshard we can dominate.', 'Inquire here. I\'m interested anyone else?

UOgamers divinity
metropolis few others lets scope out the territory.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('294', '7add93b0ed', '', 'Metro?! It only has 50 people on it =[');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('295', '44e9c42e6e', '', 'what about Uogamers?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('296', '8edfd46e88', '...', 'no time; i keep my houses refreshed on Metrop.

So far Pagan and I survive on SAS corner.  ohh and hercs forge.. 

Tyr is dead from the Mexican Mob and ...
ros is dead because he is getting married.

I\'m not going to build another char for a very long time.  

-Philip');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('297', '5eb81314a1', '', 'I\'d play if its a classic UO based and char development it somehow speed up.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('298', '9b5b630564', '', 'I\'ll scope out servers  I believe you can 7x on UO gamers in 2 days.... and there is 890 people logged in as I\'m typing this.... Looks promising. Garen get in IRC sometime? Same as its always been. I got a vent server also.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('299', '70ef815938', '', 'The day I see Garen in IRC again is the day Ros stops smoking pot!

Yeah, UOGamers has some pretty rapid skill gain. Plus it has a large pop... but, it\'s not classic UO from what I saw. Everyone was running around on beetles and stuff...');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('300', 'a411616bea', '', 'Phil\'s smoked pot alot longer than I... What\'s up with me having to stop smoking?


... jerk...');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('301', '9c338dbce2', '', 'LoL, yeah BC I\'ve been looking into both games, applied also, but I dunno... I\'m sure we could gather 30+ people to own one up though. Would be good times');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('302', '552269db72', '', 'No word yet.. 

Both of these games are something I would look at playing full time once they release, so I hope we can get a few people together.  I\'ve got a lot of DAoC buddies who plan to play as well.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('303', '3b41b6fbe9', '', 'but seriously BC, gimmie your UO stuff =)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('304', 'b1fa39713b', '', 'heh i smoke like 15 blunts a day... I blaze more than ros. But noone talks about it. Hell got a honey dutch reconstructed in my hand right now.

1million



lets play uo on uogamers and just gank');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('305', 'e06406bb57', '', 'That does sound cool ros.



But I have a feeling if there was a SAS meeting I\'d either get really drunk with pag and we\'d meet some bitches in vegas or get really fucked up with ros and wake up with no pants on in utah. :*(');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('306', '7c8de3e74e', '', '[quote:7c8de3e74e]But I have a feeling if there was a SAS meeting I\'d either get really drunk with pag and we\'d meet some bitches in vegas or get really fucked up with ros and wake up with no pants on in utah. :*([/quote:7c8de3e74e]

wait..  you\'re saying you wanna get drunk with ros without your pants on? Got the hots for Ros eh?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('307', '794f7e8c6c', '', 'Oh, don\'t get your panties all twisted Ros!

You see, phil or lakkin quitting wouldn\'t be a big deal because they both do harder stuff.

I could have easily rephrased what I said to the following:

&quot;The day Phil stops smoking crack...&quot;
or &quot;The day lakkin stops rape\'in bitches..&quot;

you were just the first one I thought of =]');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('313', '516568b306', '', 'they probably won\'t be doing that, but that still doesn\'t change the fact that you should give me your ish =) especially once they do thier next &quot;come back to UO&quot; bullshit promotion =)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('314', '3c8a59567b', '', '[quote:3c8a59567b=\"DC\"]they probably won\'t be doing that, but that still doesn\'t change the fact that you should give me your ish =) especially once they do thier next &quot;come back to UO&quot; bullshit promotion =)[/quote:3c8a59567b]

Yea like 07, when they release the new snazzy graphics.  :roll:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('315', 'e24655da65', '', 'OmG those new graphics are reason enough for me to stay away.  UO is cool because it is unique in its viewpoint/graphics.  Some people think they look like nintendo, I think they look awesome.

Damn OSI and their evolving game.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('316', 'a6c1e2c4b8', '', 'eh, all things change and yet stay the same =/');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('317', 'cf7e84943c', '', '[quote:cf7e84943c]ros with make up is a hot brunette[/quote:cf7e84943c]

You mean you haven\'t seen the pictures yet??');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('318', '3d9f1f432d', '', 'fuckers');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('319', 'd60b90f6c9', '', 'lvl 70 firemage in tier 4 gear 4 sale');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('320', '0074490767', '', 'myst and I made chars on divinity we got about a mil and a mid sized plot  also me and endo been playin blackhand alliance... its ok... i kind of like the no open pvp except in outlands but sometimes i really wanna kill people leveling in azeroth......');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('321', '5d09f5fed8', '', 'I dont even know what azeroth is...

Metrop is dead. server wipe and move to some other gay-shard is happening..  :twisted:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('322', '5679353d36', '', '[quote:5679353d36]I dont even know what azeroth is...[/quote:5679353d36]

How on earth did you get to level 60 in WoW and not learn what the game world was called?   :shock:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('323', '16e8c94162', '', '[quote:16e8c94162=\"Aries\"][quote:16e8c94162]I dont even know what azeroth is...[/quote:16e8c94162]

How on earth did you get to level 60 in WoW and not learn what the game world was called?   :shock:[/quote:16e8c94162]

hahahahaha

fking philbert!');
#
# TABLE: phpbb_privmsgs
#
DROP TABLE IF EXISTS phpbb_privmsgs;
CREATE TABLE phpbb_privmsgs(
	privmsgs_id mediumint(8) unsigned NOT NULL auto_increment,
	privmsgs_type tinyint(4) NOT NULL,
	privmsgs_subject varchar(255) NOT NULL,
	privmsgs_from_userid mediumint(8) NOT NULL,
	privmsgs_to_userid mediumint(8) NOT NULL,
	privmsgs_date int(11) NOT NULL,
	privmsgs_ip varchar(8) NOT NULL,
	privmsgs_enable_bbcode tinyint(1) DEFAULT '1' NOT NULL,
	privmsgs_enable_html tinyint(1) NOT NULL,
	privmsgs_enable_smilies tinyint(1) DEFAULT '1' NOT NULL,
	privmsgs_attach_sig tinyint(1) DEFAULT '1' NOT NULL, 
	PRIMARY KEY (privmsgs_id), 
	KEY privmsgs_from_userid (privmsgs_from_userid), 
	KEY privmsgs_to_userid (privmsgs_to_userid)
);

#
# Table Data for phpbb_privmsgs
#

INSERT INTO phpbb_privmsgs (privmsgs_id, privmsgs_type, privmsgs_subject, privmsgs_from_userid, privmsgs_to_userid, privmsgs_date, privmsgs_ip, privmsgs_enable_bbcode, privmsgs_enable_html, privmsgs_enable_smilies, privmsgs_attach_sig) VALUES('2', '2', 'sup', '24', '2', '1159483388', '42d7a5b2', '1', '0', '1', '0');
INSERT INTO phpbb_privmsgs (privmsgs_id, privmsgs_type, privmsgs_subject, privmsgs_from_userid, privmsgs_to_userid, privmsgs_date, privmsgs_ip, privmsgs_enable_bbcode, privmsgs_enable_html, privmsgs_enable_smilies, privmsgs_attach_sig) VALUES('3', '0', 'Re: sup', '2', '24', '1159515698', '47e2a72c', '1', '0', '1', '0');
INSERT INTO phpbb_privmsgs (privmsgs_id, privmsgs_type, privmsgs_subject, privmsgs_from_userid, privmsgs_to_userid, privmsgs_date, privmsgs_ip, privmsgs_enable_bbcode, privmsgs_enable_html, privmsgs_enable_smilies, privmsgs_attach_sig) VALUES('4', '2', 'Re: sup', '2', '24', '1159515698', '47e2a72c', '1', '0', '1', '0');
INSERT INTO phpbb_privmsgs (privmsgs_id, privmsgs_type, privmsgs_subject, privmsgs_from_userid, privmsgs_to_userid, privmsgs_date, privmsgs_ip, privmsgs_enable_bbcode, privmsgs_enable_html, privmsgs_enable_smilies, privmsgs_attach_sig) VALUES('5', '0', 'login bitch', '28', '17', '1162092317', '40fadac9', '1', '0', '1', '0');
INSERT INTO phpbb_privmsgs (privmsgs_id, privmsgs_type, privmsgs_subject, privmsgs_from_userid, privmsgs_to_userid, privmsgs_date, privmsgs_ip, privmsgs_enable_bbcode, privmsgs_enable_html, privmsgs_enable_smilies, privmsgs_attach_sig) VALUES('6', '2', 'login bitch', '28', '17', '1162092317', '40fadac9', '1', '0', '1', '0');
INSERT INTO phpbb_privmsgs (privmsgs_id, privmsgs_type, privmsgs_subject, privmsgs_from_userid, privmsgs_to_userid, privmsgs_date, privmsgs_ip, privmsgs_enable_bbcode, privmsgs_enable_html, privmsgs_enable_smilies, privmsgs_attach_sig) VALUES('7', '1', 'Re: login bitch', '17', '28', '1164812236', '447fe5a4', '1', '0', '1', '0');
#
# TABLE: phpbb_privmsgs_text
#
DROP TABLE IF EXISTS phpbb_privmsgs_text;
CREATE TABLE phpbb_privmsgs_text(
	privmsgs_text_id mediumint(8) unsigned NOT NULL,
	privmsgs_bbcode_uid varchar(10) NOT NULL,
	privmsgs_text text, 
	PRIMARY KEY (privmsgs_text_id)
);

#
# Table Data for phpbb_privmsgs_text
#

INSERT INTO phpbb_privmsgs_text (privmsgs_text_id, privmsgs_bbcode_uid, privmsgs_text) VALUES('2', 'abede6c8df', 'is there a private member\'s forum?');
INSERT INTO phpbb_privmsgs_text (privmsgs_text_id, privmsgs_bbcode_uid, privmsgs_text) VALUES('3', 'a9cab705ba', 'Not at the moment.

When enough people are using the board i\'ll make one, but until then I
dont want to spread the posts out between different boards.');
INSERT INTO phpbb_privmsgs_text (privmsgs_text_id, privmsgs_bbcode_uid, privmsgs_text) VALUES('4', 'a9cab705ba', 'Not at the moment.

When enough people are using the board i\'ll make one, but until then I
dont want to spread the posts out between different boards.');
INSERT INTO phpbb_privmsgs_text (privmsgs_text_id, privmsgs_bbcode_uid, privmsgs_text) VALUES('5', '95d19b2611', 'hey man is there any way i can get you to log in and just run me through an instance and get some gear for the bgs, am getting hosed by twinks');
INSERT INTO phpbb_privmsgs_text (privmsgs_text_id, privmsgs_bbcode_uid, privmsgs_text) VALUES('6', '95d19b2611', 'hey man is there any way i can get you to log in and just run me through an instance and get some gear for the bgs, am getting hosed by twinks');
INSERT INTO phpbb_privmsgs_text (privmsgs_text_id, privmsgs_bbcode_uid, privmsgs_text) VALUES('7', '0f59b72e2e', 'dude lol I would need to be up i have been on graveyard for 6 weeks');
#
# TABLE: phpbb_ranks
#
DROP TABLE IF EXISTS phpbb_ranks;
CREATE TABLE phpbb_ranks(
	rank_id smallint(5) unsigned NOT NULL auto_increment,
	rank_title varchar(50) NOT NULL,
	rank_min mediumint(8) NOT NULL,
	rank_special tinyint(1),
	rank_image varchar(255), 
	PRIMARY KEY (rank_id)
);

#
# Table Data for phpbb_ranks
#

INSERT INTO phpbb_ranks (rank_id, rank_title, rank_min, rank_special, rank_image) VALUES('1', 'Site Admin', '-1', '1', NULL);
#
# TABLE: phpbb_search_results
#
DROP TABLE IF EXISTS phpbb_search_results;
CREATE TABLE phpbb_search_results(
	search_id int(11) unsigned NOT NULL,
	session_id varchar(32) NOT NULL,
	search_time int(11) NOT NULL,
	search_array text NOT NULL, 
	PRIMARY KEY (search_id), 
	KEY session_id (session_id)
);

#
# Table Data for phpbb_search_results
#

INSERT INTO phpbb_search_results (search_id, session_id, search_time, search_array) VALUES('1895962685', 'df18d73f4fed6c414cc6fafc42e5972c', '1180223550', 'a:7:{s:14:\"search_results\";s:2:\"11\";s:17:\"total_match_count\";i:1;s:12:\"split_search\";N;s:7:\"sort_by\";i:0;s:8:\"sort_dir\";s:4:\"DESC\";s:12:\"show_results\";s:6:\"topics\";s:12:\"return_chars\";i:200;}');
#
# TABLE: phpbb_search_wordlist
#
DROP TABLE IF EXISTS phpbb_search_wordlist;
CREATE TABLE phpbb_search_wordlist(
	word_text varchar(50) NOT NULL,
	word_id mediumint(8) unsigned NOT NULL auto_increment,
	word_common tinyint(1) unsigned NOT NULL, 
	PRIMARY KEY (word_text), 
	KEY word_id (word_id)
);

#
# Table Data for phpbb_search_wordlist
#

INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('account', '23', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('server', '22', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('phpbb', '3', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('osi', '21', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('god', '20', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('garen', '19', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('still', '18', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('play', '17', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hoy', '16', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ahoy', '15', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('moo', '14', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('first', '13', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('arion', '24', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('expansion', '25', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('iii', '26', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('log', '27', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('playing', '28', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('recently', '29', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('started', '30', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stopped', '31', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('things', '32', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('playin', '2424', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('portal', '2420', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thrown', '2425', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('right', '37', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shoot', '38', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('asdasf', '39', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('asfasf', '40', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('agree', '41', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fully', '42', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nod', '43', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dsaf', '44', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fds', '45', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fdsa', '46', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fucking', '47', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kids', '48', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('24hour', '49', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('activity', '50', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('addmitted', '51', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('anyone', '52', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('forum', '53', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('master', '54', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('period', '55', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('place', '56', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('private', '57', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('privvy', '58', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('registers', '59', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('us', '60', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('few', '484', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('embarassed', '483', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('buying', '63', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('couple', '64', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('exams', '65', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('finished', '66', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('guys', '67', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('next', '68', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('since', '69', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wow', '70', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('allowed', '71', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('everyday', '72', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hrm', '73', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jews', '74', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('learn', '75', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('naked', '76', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pics', '77', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rostrax', '78', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wait', '2427', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shits', '2426', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('make', '81', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('metro', '2423', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('while', '83', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('domination', '84', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fookin', '85', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('globalization', '86', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ideas', '87', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nigga', '88', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('people', '89', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('read', '90', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('religious', '91', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thoughts', '92', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('arrow', '93', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('alliance', '94', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bloodscalp', '95', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('butt', '96', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cute', '97', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('game', '98', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lakkin', '99', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mojen', '100', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('msg', '101', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pigtails', '102', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('treca', '103', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('butts', '104', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gnome', '105', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('olds', '106', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('think', '107', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('year', '108', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('heh', '109', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hell', '110', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mean', '111', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cream', '112', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('made', '113', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('myself', '114', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('myspace', '115', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('omg', '116', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tits', '117', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('voluptoous', '118', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('10', '119', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ass', '120', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('boy', '121', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('boys', '122', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('buddies', '123', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bums', '124', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('chick', '125', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('goes', '126', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hot', '127', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('laughed', '128', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('link', '129', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('meant', '130', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nice', '131', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('one', '132', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('party', '133', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('quot', '134', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sure', '135', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('talking', '136', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('used', '137', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wtf', '138', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('government', '139', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mother', '140', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('trust', '141', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('altar', '142', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('archimonde', '143', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('burning', '144', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('crusade', '145', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('discuss', '146', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fuck', '147', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('letes', '148', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lets', '149', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('reactivating', '150', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('storms', '151', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('told', '152', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whats', '153', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('yeah', '154', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('aries', '155', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('back', '156', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('came', '157', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('change', '158', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('done', '159', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('everytime', '160', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('however', '161', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('idea', '162', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('keep', '163', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('likely', '164', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('month', '165', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('point', '166', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('quit', '167', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('same', '168', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('servers', '169', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('several', '170', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('start', '171', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stay', '172', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sticks', '173', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('switching', '174', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('two', '175', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('willing', '176', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('60s', '177', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('actually', '178', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('already', '179', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('corn', '180', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('daily', '181', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('friends', '182', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ingame', '183', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('long', '184', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mine', '185', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pops', '186', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rl', '187', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ros', '188', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('send', '189', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tell', '190', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('chars', '191', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('consider', '192', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('endo', '193', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hoppin', '194', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('horde', '195', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('across', '196', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bay', '197', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brian', '198', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cox', '199', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dev', '200', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('donovan', '201', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('drop', '202', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('email', '203', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('john', '204', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('live', '205', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('net', '206', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('null', '207', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('philip', '208', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('post', '209', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sean', '210', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('smith', '211', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whatever', '212', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('beyond', '213', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('check', '214', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('com', '215', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('darkfall', '216', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('darkfallonline', '217', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('memories', '219', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gay', '220', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thought', '221', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('contract', '222', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('probaby', '223', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shards', '224', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sign', '225', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('switch', '226', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wed', '227', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('win', '457', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('weeks', '456', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wanna', '455', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('umm', '454', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('u', '453', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('touched', '452', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('touch', '451', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('together', '450', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('suing', '449', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stupid', '448', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('story', '447', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('statement', '446', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('case', '240', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('short', '445', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sex', '444', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('set', '443', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('saying', '442', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cuz', '245', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rubbed', '441', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('realize', '440', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rape', '439', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('psychotic', '438', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('evidence', '250', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('proposed', '437', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('preliminary', '436', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('picked', '435', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fucked', '254', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('phone', '434', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('oral', '433', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('making', '432', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('madukes', '431', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('love', '430', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lawyer', '429', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('laura', '428', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('later', '427', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('indict', '426', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ill', '425', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hopefully', '424', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hearing', '423', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('happens', '422', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('give', '421', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('girl', '420', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('freaked', '419', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('forced', '418', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fooled', '417', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ejaculate', '416', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dick', '415', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('degree', '414', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('damn', '413', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cops', '412', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('completely', '411', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('christ', '410', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shit', '280', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('charges', '409', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('broke', '408', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('blehblehbleh', '407', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bitch', '406', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('aug', '405', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('and', '404', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('allegation', '403', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('acquitted', '402', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('abullshit', '401', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('5087716097', '400', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('30am', '399', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2nd', '398', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('28th', '397', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('610', '294', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('attorney', '295', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('commit', '296', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('crime', '297', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('defense', '298', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('facing', '299', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('family', '300', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('i', '301', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('instead', '302', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('payin', '303', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('spendin', '304', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wasnt', '305', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('years', '306', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('geno', '307', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('genosis', '308', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lakk', '309', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('luck', '310', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('man', '311', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wish', '312', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wrong', '313', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('410', '314', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('again', '315', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('amount', '316', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('append', '317', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('awesome', '318', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bitchis', '319', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bostons', '320', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bulgers', '321', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('buncha', '322', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cash', '323', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('coke', '324', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('comes', '325', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('county', '326', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('crazy', '327', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('defended', '328', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('details', '329', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('discount', '330', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dss', '331', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('engaged', '332', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('familiy', '333', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fired', '334', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('flyin', '335', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('framin', '336', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gave', '337', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gma', '338', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('goeson', '339', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('grandmother', '340', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hella', '341', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hes', '342', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('im', '343', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jail', '344', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kentucky', '345', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('keys', '346', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kid', '347', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kno', '348', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lawyers', '349', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('life', '350', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lookin', '351', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('looks', '352', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('managed', '353', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('massachusetts', '354', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('max', '355', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('members', '356', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('neverh', '357', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('otu', '358', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('panama', '359', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('part', '360', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('plane', '361', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('plus', '362', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('popped', '363', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('scandal', '364', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('serve', '365', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shelled', '366', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('situation', '367', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('soem', '368', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('someone', '369', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('somethin', '370', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('suit', '371', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sup', '372', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('surpress', '373', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thruout', '374', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tied', '375', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('top', '376', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tried', '377', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('uncle', '378', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whitey', '379', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whole', '380', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hard', '381', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thug', '382', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('awhile', '383', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bored', '384', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brother', '385', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('getting', '386', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hooked', '387', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kinda', '388', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('played', '389', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('quite', '390', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('regular', '391', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('semi', '392', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thanks', '393', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thou', '394', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fuckin', '395', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pussy', '396', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('attest', '458', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bro', '459', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('clears', '460', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('guy', '461', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('headache', '462', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hope', '463', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('woman', '464', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ive', '514', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lie', '515', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cocks', '468', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('parole', '516', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cumshots', '471', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shitabout', '517', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('moral', '493', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('giant', '474', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('games', '492', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thru', '491', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('that', '490', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('son', '489', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('poart', '488', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pants', '487', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('happend', '486', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('glad', '485', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fail', '513', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('evenppl', '512', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('eligilbilty', '511', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('detector', '510', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('atleast', '509', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('anxious', '508', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('admit', '507', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tellin', '518', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('test', '519', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('truth', '520', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('saints', '549', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ignorant', '548', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('history', '547', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hey', '546', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('he', '545', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('frostmourne', '544', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('flip', '543', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('coincedence', '542', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cell', '541', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brand', '540', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('battlegrounds', '539', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('assume', '538', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('among', '537', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('17', '536', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sas', '550', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('school', '551', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sinners', '552', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sonoma', '553', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tag', '554', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whisper', '555', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wsg', '556', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dav', '557', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shut', '558', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('acctually', '559', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('allright', '560', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('anymore', '561', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dude', '562', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('except', '563', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('graphics', '564', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lol', '565', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('plays', '566', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('uo', '567', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('alive', '568', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('changes', '569', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fp', '570', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('locke', '571', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('member', '572', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('week', '573', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('guild', '819', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('blackrock', '649', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('davin', '650', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dead', '651', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dun', '652', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dyn', '653', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mega', '654', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rhuarc', '655', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('besides', '656', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bld', '657', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('clownzors', '658', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('honorary', '659', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ogd', '660', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('seems', '661', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('seperate', '662', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mind', '805', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('makes', '804', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('boston', '803', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stress', '802', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shouldnt', '801', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('least', '800', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fairly', '799', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('easily', '798', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('charged', '797', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('able', '796', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('miss', '795', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jason', '794', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('trip', '793', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('haha', '792', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('crrrazzyy', '791', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dakk', '678', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kind', '679', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('core', '818', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('auto', '681', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brick', '817', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('car', '683', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rad', '816', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fukin', '815', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('call', '814', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('women', '813', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('seem', '812', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('men', '811', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('insurance', '691', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('themselvse', '810', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('strangler', '809', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sound', '808', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('position', '807', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('obvious', '806', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('121806', '697', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('1am', '698', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2am', '699', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('achy', '700', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('anything', '701', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('arm', '702', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('asleep', '703', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('away', '704', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ays', '705', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('basement', '706', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bit', '707', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bout', '708', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brain', '709', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brothers', '710', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brothres', '711', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bullshit', '712', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('care', '713', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cihc', '714', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('contact', '715', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('couchi', '716', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('crotch', '717', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cry', '718', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('decided', '719', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('downstairs', '720', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('e', '721', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('effected', '722', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('entire', '723', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('experience', '724', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('falling', '725', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('feel', '726', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('finally', '727', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('friday', '728', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('friend', '729', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gas', '730', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('grabbed', '731', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hair', '732', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('half', '733', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hand', '734', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('handwere', '735', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hanging', '736', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('harder', '737', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hells', '738', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('house', '739', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('howbig', '740', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('istarted', '741', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('job', '742', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('left', '743', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('like', '744', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('living', '745', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('manager', '746', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mouth', '747', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('opf', '748', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pat', '749', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pats', '750', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('peins', '751', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('penis', '752', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('physical', '753', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('prosecuting', '754', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pull', '755', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pulled', '756', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pulledm', '757', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pushing', '758', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('puts', '759', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ran', '760', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('raping', '761', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('room', '762', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rubbing', '763', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sending', '764', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sense', '765', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('side', '766', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('signals', '767', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sitting', '768', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sorry', '769', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('starts', '770', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stop', '771', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('store', '772', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('suspended', '773', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('taht', '774', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('talka', '775', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('talked', '776', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tank', '777', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thecouch', '778', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thursday', '779', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tog', '780', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('try', '781', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('trying', '782', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('twice', '783', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('unzipped', '784', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('upstairs', '785', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('walk', '786', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whatsoever', '787', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wheni', '788', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('work', '789', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('written', '790', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hit', '820', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pretty', '821', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('waiting', '822', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wall', '823', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('links', '878', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rob', '899', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('twink', '900', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('enter', '873', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('aggrivated', '901', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ahead', '902', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('charge', '903', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('depending', '904', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('end', '905', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('adult', '864', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('12', '839', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('anywho', '840', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('court', '841', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dumb', '842', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('front', '843', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fu', '844', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('honest', '845', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('prove', '846', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('unless', '847', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('word', '848', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bitches', '849', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fuckers', '850', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mut', '851', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('asshole', '852', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('considering', '853', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('convention', '854', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dyns', '855', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('giveing', '856', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('guess', '857', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jus', '858', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('level', '859', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('palou', '860', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('star', '861', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('trek', '862', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whored', '863', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mmorpgs', '898', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('loot', '897', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kill', '896', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('instanced', '895', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gear', '894', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dry', '893', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bland', '892', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pug', '891', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('course', '890', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bgs', '889', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('illness', '906', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mental', '907', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('misconduct', '908', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('prolly', '909', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sexual', '910', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sort', '911', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('state', '912', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('states', '913', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tough', '914', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('comical', '915', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fantasia', '916', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('join', '917', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('metropolis', '918', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pre', '919', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('r', '920', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shard', '921', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('biggest', '922', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('etc', '923', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('events', '924', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('football', '925', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nightly', '926', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pvp', '927', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('run', '928', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tournys', '929', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('uogamers', '930', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('uor', '931', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dreams', '932', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('james', '933', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('diablo', '934', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('serious', '935', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('eh', '936', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('free', '937', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fun', '938', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gaming', '939', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('suprised', '940', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('100x', '941', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('afk', '942', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('atm', '943', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('break', '944', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('builder', '945', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('char', '946', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('classes', '947', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('die', '948', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dueling', '949', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('farming', '950', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fast', '951', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('faster', '952', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fights', '953', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('full', '954', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('grp', '955', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('imo', '956', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('item', '957', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mild', '958', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mmo', '959', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pac', '960', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sink', '961', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('template', '962', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('term', '963', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tricks', '964', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('400', '965', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('design', '966', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('props', '967', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('site', '968', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('balls', '969', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('chin', '970', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('forgive', '971', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rads', '972', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('using', '973', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('vent', '974', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('blaming', '975', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('failures', '976', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('peen', '977', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pleasure', '978', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shock', '979', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tiny', '980', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('zeeks', '981', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('documents', '982', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('evolved', '983', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('face', '984', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('force', '985', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('forcing', '986', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('head', '987', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jesus', '988', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('touching', '989', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('visciously', '990', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('access', '991', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hardrive', '992', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('laying', '993', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nonuo', '994', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('org', '995', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pictures', '996', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('possible', '997', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sasguild', '998', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('screens', '999', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('screenshots', '1000', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wanted', '1001', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brittish', '1002', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('let', '1003', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pothead', '1004', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('southpark', '1006', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bliz', '1007', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('paying', '1008', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wonder', '1009', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('enough', '1010', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rich', '1011', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('zit', '1098', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tv', '1097', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('promoting', '1096', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('preview', '1095', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('obeese', '1094', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('faced', '1093', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('arnt', '1092', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cd', '1033', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cool', '1034', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('freezes', '1035', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('last', '1036', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lost', '1037', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('might', '1038', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('older', '1039', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('picks', '1040', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('probably', '1041', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rom', '1042', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('scratched', '1043', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('seconds', '1044', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wipe', '1045', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('works', '1046', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('phil', '1047', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whoever', '1048', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('battles', '1049', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ipy', '1050', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('massive', '1051', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tons', '1052', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('controls', '1053', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('park', '1054', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('south', '1055', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tanaris', '1056', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('watching', '1057', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('asylum', '1058', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('clan', '1059', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hahaha', '1060', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('myrkul', '1061', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shylock', '1062', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wardens', '1063', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wardensofasylum', '1064', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('yew', '1065', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rolled', '1073', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('outs', '1072', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lvl', '1071', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('happy', '1070', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('talk', '1074', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('team', '1075', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('apply', '1076', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('boards', '1077', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('invited', '1078', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('plenty', '1079', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('goodies', '1080', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('oldies', '1081', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('video', '1082', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('missed', '1083', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('university', '1084', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('glorious', '1085', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('invested', '1086', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('leveling', '1087', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nerf', '1088', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('priest', '1089', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('return', '1090', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shaman', '1091', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('yea', '1099', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('homo', '1100', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cockmonglers', '1101', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sentimental', '1102', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('arrrrr', '1103', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hehe', '1104', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('picture', '1105', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rogue', '1106', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rtal', '1107', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sooo', '1108', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('space', '1109', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('forgot', '1110', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shitty', '1111', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('amazing', '1112', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('aura', '1113', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('chance', '1114', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('countless', '1115', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dunno', '1116', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('galaxies', '1117', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('galaxy', '1118', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('name', '1119', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('number', '1120', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('own', '1121', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('planets', '1122', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stars', '1123', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stscl', '1124', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thinking', '1125', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('class', '1126', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('distance', '1127', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('doing', '1128', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('elements', '1129', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('moons', '1130', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('necessarily', '1131', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('orbit', '1132', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('planet', '1133', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('possabilities', '1134', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('remember', '1135', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('search', '1136', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('soooo', '1137', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('talks', '1138', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('teh', '1139', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('there', '1140', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('took', '1141', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('undergrad', '1142', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('variables', '1143', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('different', '1144', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('grief', '1145', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('honestly', '1146', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mainly', '1147', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mostly', '1148', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nah', '1149', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nostalgic', '1150', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('past', '1151', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ways', '1152', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('100', '1153', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2001ish', '1154', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('based', '1155', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('basically', '1156', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('glory', '1157', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('help', '1158', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kills', '1159', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gamestyle', '1160', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('druids', '1161', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('group', '1162', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hunter', '1163', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('knows', '1164', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('skeletor', '1165', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stick', '1166', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tauren', '1167', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('another', '1168', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('astroids', '1169', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('beam', '1170', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('black', '1171', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('boggling', '1172', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('center', '1173', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('chaos', '1174', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('comets', '1175', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('commonly', '1176', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('complex', '1177', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('compounds', '1178', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('consuming', '1179', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('disperse', '1180', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('earlier', '1181', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ecosystem', '1182', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('elemental', '1183', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('enjoy', '1184', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fertile', '1185', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('holes', '1186', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('iceberg', '1187', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('insaine', '1188', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jet', '1189', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('known', '1190', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('light', '1191', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('millions', '1192', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('present', '1193', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('seeding', '1194', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('skies', '1195', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sombrero', '1196', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('streams', '1197', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tip', '1198', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('truely', '1199', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('universe', '1200', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stoners', '1201', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('castle', '1202', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('favorite', '1203', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('file', '1204', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('great', '1205', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('herlumphamatootsi', '1206', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mistmoore', '1207', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('notice', '1208', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('original', '1209', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('s', '1210', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('suborbital', '1211', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('twoman', '1212', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('yep', '1213', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nerds', '1214', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('49', '1215', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ciao', '1216', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('message', '1217', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('moved', '1218', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('names', '1219', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('transferring', '1220', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('undead', '1221', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('character', '1222', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('herculeez', '1223', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('invite', '1224', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pic', '1225', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('batman', '1226', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('daocing', '1227', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('grinch', '1228', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('holy', '1229', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('poop', '1230', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('35', '1231', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2006', '1232', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('goto', '1233', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('oct', '1234', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('postposted', '1235', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('profile', '1236', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('subject', '1237', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('upload', '1238', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gonzo', '1239', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('origially', '1240', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pokes', '1241', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('posted', '1242', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tittle', '1243', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pissed', '1244', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pkp', '1245', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('refound', '1246', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('19th', '1247', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('act', '1248', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bank', '1249', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('boring', '1250', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('college', '1251', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('flowhand', '1252', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('important', '1253', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('major', '1254', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mins', '1255', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('moneys', '1256', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('oilfield', '1257', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('oklahoma', '1258', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ou', '1259', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('saving', '1260', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('standing', '1261', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('trinsic', '1262', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('yessah', '1263', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pagan', '1264', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('racist', '1265', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fucker', '1266', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hear', '1267', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dog', '1268', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('elstow', '1269', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('larry', '1270', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('low', '1271', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lurk', '1272', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('skele', '1273', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('style', '1274', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('grab', '1275', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mic', '1276', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nor', '1277', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('onto', '1278', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('waste', '1279', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nerd', '1280', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('assault', '1281', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('chic', '1282', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('consent', '1283', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('date', '1284', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dropped', '1285', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('indecent', '1286', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('longer', '1287', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('reduced', '1288', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('slapped', '1289', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('toss', '1290', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('congrats', '1291', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ahold', '1292', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bastard', '1293', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dirty', '1294', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mbison', '1295', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('move', '1296', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('skelly', '1297', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('afterwards', '1298', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('chea', '1299', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fuckn', '1300', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sue', '1301', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tho', '1302', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('afasj', '1303', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('asd', '1304', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('asdha', '1305', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('asdhaha', '1306', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('recruited', '1307', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('runuo', '1308', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sweeping', '1309', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('vortex', '1310', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bite', '1311', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bushido', '1312', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cause', '1313', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dc', '1314', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('evaison', '1315', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('finaly', '1316', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mages', '1317', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('means', '1318', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nerfed', '1319', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('parry', '1320', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('talon', '1321', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('yaay', '1322', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tamer', '1368', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('suck', '1367', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('such', '1366', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('smithy', '1365', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('second', '1364', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('poisoner', '1363', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('online', '1362', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nearly', '1361', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('murderers', '1360', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('money', '1359', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('moment', '1358', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lookets', '1357', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('issues', '1356', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('irc', '1355', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('inside', '1354', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('herc', '1353', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fighting', '1352', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('expect', '1351', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('disappointed', '1350', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('communial', '1349', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('carp', '1348', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('board', '1347', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('alchy', '1346', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thread', '1369', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('till', '1370', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tinker', '1371', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('type', '1372', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('uhg', '1373', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ultime', '1374', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('unit', '1375', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('villa', '1376', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wana', '1377', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('warriors', '1378', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('welcome', '1379', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('yer', '1380', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('easy', '1381', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pag', '1382', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('picking', '1383', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bump', '1384', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('twizzler', '1385', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('infos', '1386', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('macro', '1387', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('problem', '1388', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('faggot', '1389', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gamesurge', '1390', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('metropolisshard', '1391', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hheh', '2617', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('feed', '2616', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('drag', '2615', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brunette', '2614', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bet', '2613', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('resist', '1397', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('messing', '1398', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('advantage', '2612', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('title', '2611', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('60', '1401', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('drama', '1402', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('druid', '1403', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('homes', '1404', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('maxed', '1405', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pvpd', '1406', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('realized', '1407', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('worth', '1408', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('according', '1409', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('active', '1410', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('daoc', '1411', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dungeon', '1412', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('guilds', '1413', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('heard', '1414', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hours', '1415', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mmos', '1416', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pally', '1417', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pwn', '1418', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('raid', '1419', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('raids', '1420', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rate', '1421', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ready', '1422', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('reason', '1423', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('schedules', '1424', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('uber', '1425', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nex', '1426', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('curious', '1634', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('christmas', '1633', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ghey', '2322', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('watches', '2321', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('summer', '2320', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stand', '2319', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('spring', '2318', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sa', '2317', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wouldnt', '1632', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ruin', '2316', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('roll', '2315', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('retards', '2314', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('numbers', '2313', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mad', '2312', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('loser', '2311', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('appreciate', '2293', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('archer', '2294', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('arycke', '2295', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('blue', '2296', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('claim', '2297', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('current', '2298', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('definately', '2299', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('digi', '2300', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('enemies', '2301', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('everything', '2302', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('turn', '1631', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('example', '2303', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fat', '2304', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('huge', '2305', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('irl', '2306', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('itself', '2307', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kiss', '2308', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lady', '2309', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lasted', '2310', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('relatively', '2266', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('poor', '2265', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hour', '2264', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2', '2263', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('springs', '2262', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sale', '2261', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pass', '2260', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('throat', '1658', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tram', '1630', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('slit', '1657', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('santa', '1656', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rained', '1655', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('laughing', '1654', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dad', '1653', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('crying', '1652', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('corpse', '1651', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('canceled', '1650', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('calling', '1649', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('blows', '1648', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('vegas', '1647', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sometimes', '1646', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('presents', '1645', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('planning', '1644', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('perhaps', '1643', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('normal', '1642', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('meeting', '1641', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('interesting', '1640', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('holidays', '1639', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('girlfriends', '1638', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('extended', '1637', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dinner', '1636', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('deal', '1635', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('single', '1629', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('similar', '1628', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('setting', '1627', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('safe', '1626', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pvers', '1625', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('populated', '1624', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('popular', '1623', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('players', '1622', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mythic', '1621', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lovers', '1620', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('law', '1619', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hosts', '1618', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hmmm', '1617', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hide', '1616', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('haters', '1615', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('happen', '1614', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gareth', '1613', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('figthing', '1612', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fight', '1611', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('community', '1610', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('combined', '1609', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cluster', '1608', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('classic', '1607', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('aos', '1606', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('aint', '1605', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rumor', '1604', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('naa', '1603', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brought', '1602', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('youve', '1601', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('split', '1600', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('screw', '1599', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gateway', '1598', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('famous', '1597', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('anyway', '1596', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('t2a', '2610', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('posting', '1580', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('password', '1579', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nexus', '1578', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('loved', '1577', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('locked', '1576', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kings', '1575', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jasons', '1574', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('horrible', '1573', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bought', '1572', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('probally', '1581', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('promptly', '1582', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('resold', '1583', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('suicide', '1584', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('waking', '1585', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cast', '1586', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('compared', '1587', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('player', '1588', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('seen', '1589', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('timer', '1590', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fl', '1591', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('invaded', '1592', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('missing', '1593', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('origin', '1594', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('vagina', '1595', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('palm', '2259', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('indio', '2258', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('festival', '2257', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('drive', '2256', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('close', '2255', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hippies', '2254', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('drugs', '2253', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('van', '2252', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tiesto', '2251', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('paul', '2250', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dyk', '2249', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('commercial', '1735', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('djs', '2248', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('benny', '2247', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bennassi', '2246', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stuffs', '2245', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('memorial', '2244', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gunna', '2243', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('expenses', '2242', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cut', '2241', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pissing', '2240', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ahah', '2239', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sister', '2238', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hrmm', '2237', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('worked', '2236', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tickets', '2235', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('save', '2234', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('early', '2233', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dates', '2232', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('buy', '2231', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('you', '2230', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('unix', '2229', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('techie', '2228', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sys', '2227', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rofl', '2226', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('residential', '2225', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('linux', '2224', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fiber', '2223', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('disappeared', '2222', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('company', '2221', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bitchface', '2220', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('beta', '2219', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('arkman', '2218', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fkers', '2197', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gig', '2198', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('comeon', '2199', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('indians', '2200', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('saskatoon', '2201', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('boomhaur', '2202', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wicked', '2203', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pain', '2185', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ark', '2204', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('computers', '2205', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('connected', '2206', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('constantly', '2207', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('consumtion', '2208', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lazy', '2209', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pedospace', '2210', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('power', '2211', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('resources', '2212', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shame', '2213', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('takes', '2214', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('admin', '2215', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('agreement', '2216', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('anyways', '2217', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rage', '2165', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whos', '2164', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('la', '2163', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('joining', '2162', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gmail', '2161', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('comign', '2160', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('coachella', '2159', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('arkaine00', '2158', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('april', '2157', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('weekend', '2156', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fly', '2155', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('business', '2154', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('caught', '2603', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('vanished', '2151', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('unload', '2150', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('w00t', '2149', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gpa', '2148', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('currently', '2147', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('877', '2146', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('3', '2145', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('prepare', '2144', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mentally', '2143', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('canada', '2142', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('border', '2141', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('average', '2140', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gonna', '2139', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('believe', '2138', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sin', '2137', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('city', '2136', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('buisness', '2135', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('towards', '2134', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('totally', '2133', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('total', '2132', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tossing', '2131', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ticket', '2130', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thing', '2129', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('spend', '2128', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('redo', '2127', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('packed', '2126', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('opinions', '2125', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('open', '2124', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('obviously', '2123', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('moving', '2122', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('met', '2121', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('meet', '2120', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lodging', '2119', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('location', '2118', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('layover', '2117', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('interested', '2116', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('interest', '2115', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('haties', '2114', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gauge', '2113', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fergazi', '2112', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('event', '2111', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cincinnati', '2110', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('called', '2109', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('busy', '2108', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bride', '2107', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('blast', '2106', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('actual', '2105', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('reminds', '2104', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hehehe', '2103', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('episode', '2102', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('telling', '2101', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('odds', '2100', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('newa', '2099', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('frajoules', '2098', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('catch', '2097', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bred', '2096', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('born', '2095', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('toronto', '2094', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stuff', '2093', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hoping', '2092', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('film', '2091', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('refuse', '2090', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mobs', '2089', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('investing', '2088', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fan', '2087', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('adapting', '2086', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ppl', '2085', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('meh', '2084', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lame', '2083', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('idle', '2082', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fade', '2081', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('adapt', '2080', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('others', '2079', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('myspacebuds', '2078', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mode', '2077', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ivan', '2076', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cory', '2075', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('communication', '2074', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('uozorz', '2073', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('perfer', '2072', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('occasional', '2071', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ins', '2070', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('webshit', '2069', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('texan', '2068', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('raging', '2067', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('highschool', '2066', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dak', '2065', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bull', '2064', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('channel', '2063', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('1996', '2062', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('prevent', '2061', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('list', '2060', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('handle', '2059', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gamers', '2058', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('future', '2057', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fact', '2056', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('clicky', '2055', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('blitz', '2054', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('always', '2053', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shot', '2052', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('multi', '2051', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fags', '2050', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('faction', '2049', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('xpac', '2048', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('4', '2047', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pagans', '2430', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('add', '2044', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('grinding', '2043', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wants', '2042', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('may', '2041', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('everyones', '2040', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('central', '2039', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('blade', '2038', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('peace', '2037', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('manson', '2036', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ferg', '2035', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('buddy', '2034', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('trade', '2033', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sundin', '2032', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pick', '2031', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('leafs', '2030', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('flames', '2029', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('arkaine', '2028', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stories', '2027', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('reach', '2026', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('promise', '2025', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nekstlevel', '2024', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jump', '2023', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('habit', '2022', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('googled', '2021', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('engines', '2020', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dan', '2019', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('albu', '2018', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('adios', '2017', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2007', '2016', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sexy', '2015', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('harle', '2014', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('forward', '2013', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('race', '2012', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('iginla', '2011', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('5', '2010', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('killing', '2009', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('combat', '2604', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('count', '2006', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dynamics', '2605', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('super', '2003', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sucks', '2002', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hits', '2606', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('insta', '2607', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mix', '2608', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('precast', '2609', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hockey', '1994', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gifts', '1993', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('drinks', '1992', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('telly', '1991', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ross', '1990', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gettin', '1989', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('banging', '1988', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whoa', '1987', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('personally', '1986', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hate', '1985', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hardcore', '1984', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('canadians', '1983', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('goth', '2450', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('become', '2449', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('became', '2448', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('1st', '2447', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('weather', '2428', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('purses', '2369', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('knew', '2431', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fag', '2432', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('legit', '2433', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('blackhand', '2434', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mojo', '2435', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('draenei', '2436', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('idk', '2437', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('newbs', '2438', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('smolderthorn', '2439', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('weirdo', '2453', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('marry', '2452', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('honeslty', '2451', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('death', '2454', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fake', '2455', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('refering', '2456', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('deliver', '2457', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('turned', '2458', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('approaching', '2459', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('leo', '2460', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('silly', '2461', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('status', '2462', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hero', '2463', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('roleplaying', '2464', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('1v1', '2465', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('20v20', '2466', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('50v50', '2467', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('annoying', '2468', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('decent', '2469', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gimps', '2470', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rpd', '2471', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('accounts', '2472', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('age', '2473', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('available', '2474', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('betas', '2475', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('conan', '2476', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('entered', '2477', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hold', '2478', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('info', '2479', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lucky', '2480', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mboard', '2481', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('posed', '2482', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('reading', '2483', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('selected', '2484', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('strike', '2485', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('unite', '2486', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('visits', '2487', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('warhammer', '2488', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('weve', '2489', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('explain', '2490', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('against', '2491', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brutal', '2492', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('feast', '2493', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('monsters', '2494', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('night', '2495', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('piece', '2496', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('scheduled', '2497', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('watch', '2498', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('attention', '2602', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('1997', '2500', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('computer', '2501', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('blacksmithy', '2502', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('grandmaster', '2503', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('heheh', '2504', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('high', '2505', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('matter', '2506', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('merch', '2507', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('skill', '2508', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('120', '2509', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('barding', '2510', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('skills', '2511', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('taming', '2512', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('three', '2513', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bard', '2514', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('capone', '2515', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fire', '2516', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('flash', '2517', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gm', '2518', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ingot', '2519', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('main', '2520', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ole', '2521', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('provoke', '2522', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('screen', '2523', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shes', '2524', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('smasher', '2525', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('third', '2526', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('accepted', '2527', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bye', '2528', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('chances', '2529', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('choosing', '2530', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('delete', '2531', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lakkins', '2532', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('visit', '2533', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('website', '2534', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('divinity', '2535', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dominate', '2536', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('freeshard', '2537', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('inquire', '2538', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('reunion', '2539', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('scope', '2540', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('territory', '2541', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ultima', '2542', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('build', '2543', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('corner', '2544', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('forge', '2545', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hercs', '2546', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('houses', '2547', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('married', '2548', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('metrop', '2549', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mexican', '2550', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mob', '2551', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ohh', '2552', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('refreshed', '2553', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('survive', '2554', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tyr', '2555', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('development', '2556', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('somehow', '2557', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('speed', '2558', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('890', '2559', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('logged', '2560', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('promising', '2561', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('typing', '2562', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('beetles', '2563', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gain', '2564', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pop', '2565', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pot', '2566', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rapid', '2567', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('running', '2568', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('smoking', '2569', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stops', '2570', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jerk', '2571', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('phils', '2572', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('smoked', '2573', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('applied', '2574', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('both', '2575', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gather', '2576', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('plan', '2577', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('release', '2578', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gimmie', '2579', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('seriously', '2580', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('1million', '2581', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('blaze', '2582', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('blunts', '2583', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dutch', '2584', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gank', '2585', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('honey', '2586', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('noone', '2587', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('reconstructed', '2588', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('smoke', '2589', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('drunk', '2590', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('feeling', '2591', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('utah', '2592', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wake', '2593', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hots', '2594', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('crack', '2595', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('following', '2596', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('panties', '2597', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('quitting', '2598', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rapein', '2599', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rephrased', '2600', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('twisted', '2601', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mdma', '2618', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rollin', '2619', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ea', '2620', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('runs', '2621', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('templates', '2622', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('especially', '2623', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ish', '2624', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('promotion', '2625', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thier', '2626', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('snazzy', '2627', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('evolving', '2628', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nintendo', '2629', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('unique', '2630', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('viewpoint', '2631', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('firemage', '2632', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tier', '2633', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('azeroth', '2634', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mid', '2635', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mil', '2636', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('myst', '2637', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('outlands', '2638', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('plot', '2639', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sized', '2640', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gayshard', '2641', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('happening', '2642', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('earth', '2643', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fking', '2644', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hahahahaha', '2645', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('philbert', '2646', '0');
#
# TABLE: phpbb_search_wordmatch
#
DROP TABLE IF EXISTS phpbb_search_wordmatch;
CREATE TABLE phpbb_search_wordmatch(
	post_id mediumint(8) unsigned NOT NULL,
	word_id mediumint(8) unsigned NOT NULL,
	title_match tinyint(1) NOT NULL, 
	KEY post_id (post_id), 
	KEY word_id (word_id)
);

#
# Table Data for phpbb_search_wordmatch
#

INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '24', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('4', '19', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('4', '20', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('4', '21', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('4', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('3', '15', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('3', '16', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('3', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('3', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('2', '14', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('2', '13', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '25', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '26', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '27', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '29', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '30', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '31', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '32', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('268', '707', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('267', '154', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('267', '2425', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('267', '240', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('267', '153', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('267', '2149', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('7', '40', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('7', '39', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('8', '41', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('8', '42', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('8', '43', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('9', '44', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('9', '45', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('9', '46', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('10', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('10', '48', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '49', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '51', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '52', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '53', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '54', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '55', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '56', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '57', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '58', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '59', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '60', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '50', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '483', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '415', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '411', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('13', '41', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '63', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '64', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '65', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '66', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '69', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '70', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('15', '71', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('15', '72', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('15', '73', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('15', '74', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('15', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('15', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('15', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('17', '76', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('17', '77', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('17', '78', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('268', '1148', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('268', '1652', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('267', '2424', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('267', '2423', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('267', '1128', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '53', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '57', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '84', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '85', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '86', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '87', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '88', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '91', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '92', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('21', '93', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '78', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '94', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '95', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '96', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '97', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '99', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '100', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '101', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '102', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '103', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '96', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '104', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '97', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '105', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '106', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('24', '53', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('24', '109', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('24', '110', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('24', '111', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('24', '57', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('24', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '112', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '113', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '114', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '115', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '116', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '118', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '119', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '121', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '122', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '123', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '124', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '125', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '126', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '127', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '128', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '129', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '130', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '131', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '133', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '135', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '136', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '137', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '138', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('27', '139', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('27', '140', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('27', '141', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '142', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '143', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '146', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '148', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '149', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '150', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '151', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '152', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '153', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '143', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '144', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '145', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '70', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '109', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '155', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '157', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '158', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '160', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '161', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '162', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '163', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '164', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '165', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '166', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '167', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '169', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '170', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '171', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '172', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '173', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '174', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '175', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '176', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '178', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '179', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '95', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '180', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '181', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '183', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '99', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '184', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '185', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '186', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '187', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '188', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '189', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '190', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '142', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '191', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '192', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '193', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '194', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '195', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '151', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '196', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '197', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '198', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '199', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '200', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '202', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '203', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '204', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '205', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '206', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '207', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '208', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '209', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '210', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '211', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '212', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '201', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('33', '213', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('33', '214', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('33', '215', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('33', '217', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('33', '216', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('34', '219', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('35', '220', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('35', '221', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('35', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('35', '70', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '222', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '223', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '224', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '225', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '172', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '226', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '227', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '70', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '90', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '67', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '254', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '411', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '397', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '398', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '399', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '400', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '401', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '402', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '403', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '404', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '405', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '406', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '407', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '408', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '409', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '280', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '410', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '412', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '413', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '414', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '415', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '416', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '417', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '418', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '419', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '420', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '421', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '422', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '423', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '424', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '425', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '426', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '427', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '428', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '429', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '430', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '431', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '432', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '433', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '434', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '435', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '436', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '437', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '250', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '438', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '439', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '440', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '441', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '245', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '442', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '443', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '444', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '445', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '240', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '446', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '447', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '448', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '449', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '450', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '451', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '452', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '453', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '454', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '455', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '456', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '457', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '184', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '88', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '294', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '295', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '95', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '296', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '297', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '298', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '299', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '300', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '302', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '303', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '304', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '305', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '306', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '307', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '308', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '309', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '310', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '311', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '312', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '313', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '64', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '110', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '129', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '135', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '184', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '185', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '212', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '240', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '245', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '250', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '254', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '280', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '295', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '298', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '300', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '302', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '306', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '307', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '314', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '315', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '316', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '317', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '318', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '319', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '320', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '321', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '322', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '323', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '324', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '325', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '326', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '327', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '328', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '329', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '330', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '331', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '332', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '333', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '334', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '335', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '336', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '337', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '338', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '339', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '340', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '341', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '342', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '343', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '344', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '345', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '346', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '347', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '348', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '349', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '350', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '351', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '352', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '353', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '354', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '355', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '356', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '357', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '358', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '359', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '360', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '361', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '362', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '363', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '364', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '365', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '366', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '367', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '368', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '369', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '370', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '371', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '372', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '373', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '374', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '375', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '376', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '377', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '378', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '379', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '380', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('41', '120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('41', '381', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('41', '382', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '383', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '384', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '385', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '386', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '387', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '388', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '389', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '390', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '391', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '37', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '392', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '393', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '394', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '395', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '396', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '458', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '459', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '460', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '461', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '462', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '463', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '390', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '280', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '464', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '520', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '519', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('47', '153', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('47', '117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('47', '447', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('47', '493', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('47', '492', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '452', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '491', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '490', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '489', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '370', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '441', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '488', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '487', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '486', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '126', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '485', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '417', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '484', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '518', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '517', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '280', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '516', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '515', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '514', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '513', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '512', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '511', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '510', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '240', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '322', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '509', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '508', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '507', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '306', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '551', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '550', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '549', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '434', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '548', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '547', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '546', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '545', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '461', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '420', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '544', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '543', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '542', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '541', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '540', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '539', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '538', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '537', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '536', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '552', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '553', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '554', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '455', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '555', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '556', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '550', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '22', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '70', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('51', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('51', '557', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('51', '558', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('51', '553', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '559', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '560', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '561', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '562', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '563', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '19', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '564', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '565', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '311', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '566', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '567', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '568', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '569', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '484', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '570', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '571', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '572', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '573', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '649', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '122', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '650', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '651', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '652', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '653', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '654', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '566', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '655', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '305', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '178', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '568', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '656', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '649', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '657', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '658', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '652', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '653', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '659', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '130', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '572', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '660', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '661', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '662', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '169', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '803', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '802', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '801', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '439', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '310', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '800', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '429', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '99', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '799', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '798', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '797', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '796', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '546', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '208', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '795', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '794', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '793', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '99', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '792', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '791', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '459', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '406', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('60', '650', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '678', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '492', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '679', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '111', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '493', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '131', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '447', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '153', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('68', '444', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('68', '812', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('68', '811', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('68', '310', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('68', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '810', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '809', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '808', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '442', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '37', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '807', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '806', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '805', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '804', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '515', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '110', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '395', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '713', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '30', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '31', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '52', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '81', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '114', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '163', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '175', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '221', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '450', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '446', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '240', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '442', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '432', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '418', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '313', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '315', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '350', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '360', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '369', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '376', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '380', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '381', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '463', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '491', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '487', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '486', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '565', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '683', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '697', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '698', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '699', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '700', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '701', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '702', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '703', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '704', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '705', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '706', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '707', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '708', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '709', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '710', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '711', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '712', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '713', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '714', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '715', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '716', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '717', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '718', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '719', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '720', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '721', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '722', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '723', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '724', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '725', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '726', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '727', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '728', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '729', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '730', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '731', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '732', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '733', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '734', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '735', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '736', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '737', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '738', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '739', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '740', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '741', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '742', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '743', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '744', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '745', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '746', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '747', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '748', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '749', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '750', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '751', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '752', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '753', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '754', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '755', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '756', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '757', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '758', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '759', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '760', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '761', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '762', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '763', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '764', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '765', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '766', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '767', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '768', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '769', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '770', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '771', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '772', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '773', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '774', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '775', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '776', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '777', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '778', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '779', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '780', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '781', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '782', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '783', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '784', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '785', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '786', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '787', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '788', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '789', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '790', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '712', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '562', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '90', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('68', '171', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('68', '813', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '406', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '814', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '815', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '406', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '816', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '649', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '817', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '818', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '25', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '819', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '546', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '820', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '821', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '553', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '567', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '822', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '823', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '905', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '904', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '298', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '678', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '903', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '902', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '901', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '315', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '900', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '899', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '37', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '821', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '898', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '897', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '388', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '896', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '895', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '739', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '894', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '562', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '839', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '840', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '841', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '413', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '842', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '843', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '844', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '381', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '845', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '99', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '429', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '81', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '311', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '811', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '846', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '439', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '847', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '848', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '849', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '653', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '850', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '546', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '140', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '851', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '94', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '852', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '853', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '854', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '413', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '855', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '484', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '856', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '857', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '819', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '195', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '514', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '858', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '859', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '860', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '861', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '221', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '862', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '781', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '863', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '312', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '893', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '892', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('80', '889', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('79', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('79', '892', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '457', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '891', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '311', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '195', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '890', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '849', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '889', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('78', '94', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '111', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '386', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '906', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '429', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '907', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '908', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '360', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '909', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '910', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '911', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '912', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '913', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('81', '914', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('82', '915', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('83', '916', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('83', '220', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('83', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('84', '794', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('84', '917', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('84', '918', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('84', '208', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('84', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('84', '919', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('84', '920', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('84', '921', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '922', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '923', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '924', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '925', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '926', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '919', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '927', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '928', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '921', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '929', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '930', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('85', '931', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '52', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '932', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '933', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '190', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('86', '152', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '214', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '650', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '918', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '921', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('87', '30', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '934', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '562', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '311', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('88', '935', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '936', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '937', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '939', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '940', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('89', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '941', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '942', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '943', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '944', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '945', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '946', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '947', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '904', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '948', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '949', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '563', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '950', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '951', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '952', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '953', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '954', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '955', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '956', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '957', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '514', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '958', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '959', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '960', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '928', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '961', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '962', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '963', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '964', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('90', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '965', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '742', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '352', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '137', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '966', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '967', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('91', '968', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('92', '52', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('92', '969', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('92', '970', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('92', '215', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('92', '217', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('92', '971', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('92', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('92', '816', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('92', '972', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('92', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('92', '973', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('92', '974', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('92', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '889', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '892', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '215', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '325', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '217', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '893', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '562', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '894', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '739', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '895', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '896', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '388', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '897', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '898', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '821', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '37', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '899', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('93', '900', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('94', '975', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('94', '976', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('94', '977', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('94', '978', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('94', '979', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('94', '771', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('94', '980', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('94', '981', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '713', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '410', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '841', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '982', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '562', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '983', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '984', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '985', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '986', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '421', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '987', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '988', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '761', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '442', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '989', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '782', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '990', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('95', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '991', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '52', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '155', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '199', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '200', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '992', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '546', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '993', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '129', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '430', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '206', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '994', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '207', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '995', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '997', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '209', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '998', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '999', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '1000', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '968', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '451', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '996', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('96', '1001', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('97', '1002', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('97', '1003', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('97', '752', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('97', '1004', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('97', '981', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('98', '1006', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1007', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1008', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('99', '1009', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('100', '1010', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('100', '1011', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '1098', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '1097', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '1096', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '1095', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '1094', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '432', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '1093', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('101', '1092', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '1033', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '1034', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '653', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '1035', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '485', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '425', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '1036', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '352', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '1037', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '1038', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '1039', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '1040', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '996', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '1041', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '1042', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '1043', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '1044', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '968', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '221', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '1045', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('102', '1046', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '155', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '742', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '1047', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('103', '1048', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1049', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1050', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1051', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '77', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '1052', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('104', '137', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '315', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '649', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1053', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '546', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '350', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '571', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '113', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1038', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '795', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1054', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1055', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1056', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '1057', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('105', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '1058', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '649', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '1059', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '652', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '819', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '1060', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '571', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '1061', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '995', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '655', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '1062', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '1063', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '1064', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('106', '1065', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1070', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '734', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '421', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1010', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1034', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '121', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '859', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '184', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1071', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1061', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1072', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1041', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1073', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '369', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1074', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '1075', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('107', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1076', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1077', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1078', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '311', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1079', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '1074', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('108', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '1080', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('109', '1081', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('111', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('111', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('111', '492', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('111', '347', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('111', '48', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('111', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('111', '1082', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '413', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '13', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '939', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '386', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '20', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '352', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1083', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '1084', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('112', '305', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '947', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '296', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '337', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1085', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1086', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '859', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1087', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '113', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1088', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1089', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1090', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1073', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '1091', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '963', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('113', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '562', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '463', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '429', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('114', '1099', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '122', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '1100', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('115', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '814', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '1101', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '81', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('116', '1102', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('117', '155', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('117', '1103', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('117', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('117', '97', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('117', '1104', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('117', '1105', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('117', '1106', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('117', '1107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('117', '1108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('117', '1109', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '155', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '1110', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '564', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '1105', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '1111', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '1109', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '153', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('118', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1112', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '155', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1113', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1114', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1115', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1116', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1118', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1104', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1119', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1121', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1122', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '979', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '861', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1123', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1124', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '135', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('119', '1125', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '318', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1126', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '853', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1127', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1128', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1129', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '350', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1130', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1131', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1133', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1122', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1135', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '37', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1136', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1137', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '861', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1138', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1139', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1140', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1141', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1142', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1143', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('120', '1099', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '411', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '1144', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '953', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '1145', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '819', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '1146', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '896', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '571', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '1147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '111', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '1148', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '1149', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '1150', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '1151', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '550', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '567', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '455', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '1152', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('121', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '1153', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '1154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '458', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '1155', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '1156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '1144', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '1157', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '1158', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '957', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '1159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '679', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '1152', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('122', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '484', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '1160', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '32', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('123', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '178', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '849', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '649', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '946', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '1161', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '484', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '1162', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '1163', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '1164', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '571', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '1119', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '1091', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '1165', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '30', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '1166', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('124', '1167', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '196', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1112', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1169', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1170', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1171', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1172', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '157', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1173', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1174', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '215', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1175', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1176', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1178', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1179', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1180', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1181', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1183', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1184', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1185', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1118', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1186', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1187', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1188', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1189', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1190', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1191', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '129', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1192', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '805', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1105', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1122', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1193', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '821', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1194', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1195', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1196', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1109', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1197', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1198', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1199', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1200', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '1057', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('125', '306', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('126', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('126', '1201', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('126', '546', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '155', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '383', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1202', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1114', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1203', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1204', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1118', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1205', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1206', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '546', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '463', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1207', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1119', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1208', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1209', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '996', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '209', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '816', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1135', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '37', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1210', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1109', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1211', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1212', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '137', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('127', '1213', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('128', '1214', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('129', '406', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('129', '816', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '1215', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '1216', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '421', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '425', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '1217', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '1219', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '1106', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '1220', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '1221', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '649', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '946', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '1218', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('130', '70', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('131', '1222', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('131', '1223', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('131', '1224', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('131', '1119', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('131', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '20', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('132', '1225', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('133', '568', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('133', '1226', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('133', '1227', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('133', '1228', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('133', '1229', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('133', '1230', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('133', '173', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('133', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('133', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '1232', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '1231', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '155', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '20', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '1233', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '1104', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '1234', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '1225', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '1105', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '209', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '1235', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '1236', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '1237', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '221', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('134', '1238', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '713', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '484', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '13', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1239', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '128', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '660', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1240', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1225', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1241', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1242', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '1243', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '212', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('135', '306', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('136', '1244', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('136', '1245', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('136', '821', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('136', '1246', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('136', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1247', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1248', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '568', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '943', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1249', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1250', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '710', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '569', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1251', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1128', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1252', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1253', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1254', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1255', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1256', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1257', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1258', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1259', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1260', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1165', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1261', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1262', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '782', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '789', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('137', '1263', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('138', '71', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('138', '155', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('138', '852', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('138', '1264', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('138', '752', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('138', '1265', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('139', '1266', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('139', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('139', '1267', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('139', '442', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('139', '393', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('139', '306', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('140', '568', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('140', '1268', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('140', '1269', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('140', '937', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('140', '1270', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('140', '1271', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('140', '1272', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('140', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('140', '921', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('140', '1273', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('140', '1274', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('141', '1168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('141', '1275', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('141', '110', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('141', '1003', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('141', '27', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('141', '1276', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('141', '1277', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('141', '1278', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('141', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('141', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('141', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('141', '921', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('141', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('141', '974', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('141', '1279', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('141', '974', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('142', '1280', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '1281', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '903', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '797', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '1282', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '1283', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '841', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '1284', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '424', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '1286', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '1287', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '439', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '280', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '1289', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '1290', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '903', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '1285', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '439', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('143', '1288', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('144', '1291', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '796', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '1292', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '1293', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '1294', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '1161', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '484', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '546', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '1036', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '859', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '571', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '27', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '311', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '1295', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '1296', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '1219', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '1091', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '1297', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '30', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('145', '573', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('146', '1298', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('146', '406', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('146', '1299', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('146', '410', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('146', '1300', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('146', '1301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('146', '1302', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('147', '1303', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('147', '1304', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('147', '1305', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('147', '1306', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('148', '726', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('148', '1264', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('148', '1307', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('148', '1308', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('148', '921', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('148', '1309', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('148', '1310', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('149', '1311', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('149', '1312', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('149', '1313', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('149', '1314', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('149', '1315', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('149', '1316', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('149', '1317', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('149', '1318', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('149', '1319', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('149', '116', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('149', '1320', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('149', '1321', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('149', '1322', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '171', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1365', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '979', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '280', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1364', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '37', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '209', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1363', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1079', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1361', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1360', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1359', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1358', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '918', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '81', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1357', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '514', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1356', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1355', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1354', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '739', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1353', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1158', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '66', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1352', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1351', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1128', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '146', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1350', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '180', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1349', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '946', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1348', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1347', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '52', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1346', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1366', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1367', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '136', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1368', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '32', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1369', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1370', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1371', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1372', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1373', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1375', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1376', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1377', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1378', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1379', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1380', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1362', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('150', '1374', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('151', '1381', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('151', '726', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('151', '352', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('151', '1382', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('151', '1264', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('151', '1383', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('151', '1307', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('151', '1308', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('151', '921', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('151', '1309', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('151', '1310', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('152', '1384', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('152', '1276', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('153', '415', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('153', '558', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('153', '1385', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('154', '1276', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('155', '425', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('155', '1386', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('155', '1387', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('155', '209', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('155', '1388', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('155', '280', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('156', '215', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('156', '1389', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('156', '1390', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('156', '110', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('156', '1355', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('156', '1391', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('156', '206', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('156', '550', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('156', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('312', '2620', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('312', '1607', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('312', '1596', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('312', '1410', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('312', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('311', '188', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('311', '2619', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('311', '2618', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('311', '81', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('311', '127', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('311', '2617', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('311', '2616', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('159', '1397', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('160', '311', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('160', '1398', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('160', '816', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('160', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('160', '153', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('160', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('311', '2615', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('311', '2614', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('162', '1401', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('162', '707', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('162', '1402', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('162', '1403', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('162', '819', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('162', '1404', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('162', '1405', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('162', '389', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('162', '1406', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('162', '1407', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('162', '1364', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('162', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('162', '69', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('162', '372', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('162', '376', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('162', '305', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('162', '380', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('162', '1408', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '119', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '1409', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '1410', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '1411', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '1412', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '1413', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '1414', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '1415', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '804', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '356', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '1416', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '1417', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '1418', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '1419', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '1420', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '1421', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '1422', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '1423', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '1424', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '812', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '376', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '1425', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '573', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('163', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('164', '1426', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('164', '558', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('213', '2144', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('213', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('213', '2143', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('213', '1641', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('213', '81', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('213', '1619', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('213', '2006', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('213', '2142', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('213', '2141', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('213', '2140', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('213', '796', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('212', '1647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('212', '2041', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('212', '2139', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('212', '2138', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('211', '573', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('211', '1647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('211', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('211', '912', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('211', '2137', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('211', '800', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('211', '2136', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('211', '2135', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '187', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '1644', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '1641', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2116', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '938', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '52', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '176', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '212', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '1647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '782', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2133', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2131', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2130', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '1125', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2129', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '1366', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2128', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '280', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '1424', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '550', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2127', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '821', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '361', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '56', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2126', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2125', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2124', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '1039', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2123', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '114', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2122', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '1359', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2121', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '1641', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2119', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2118', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '1036', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '794', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2115', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '162', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2114', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '386', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2113', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2057', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2112', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2111', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '1284', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '1034', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2110', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2109', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2106', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '701', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('210', '2105', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('209', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('209', '1369', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('209', '1055', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('209', '2104', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('209', '1054', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('209', '2103', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('209', '2102', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('208', '2094', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('208', '2101', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('208', '38', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('208', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('208', '2100', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('208', '2099', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('208', '2041', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('208', '1355', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('208', '110', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('208', '2057', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('208', '2098', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('208', '2091', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('208', '203', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('208', '2097', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('208', '2096', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('208', '2095', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('207', '2094', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('207', '1074', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('207', '2093', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('207', '1217', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('207', '1355', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('207', '2092', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('207', '1414', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('207', '2091', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('207', '2028', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '1082', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '225', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('176', '152', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('176', '1658', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('176', '1657', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('176', '1656', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('176', '1655', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('176', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('176', '396', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('176', '1654', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('176', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('176', '254', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('176', '651', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('176', '1653', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('176', '1652', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('176', '1651', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('176', '1633', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('176', '1650', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('176', '1649', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('176', '1648', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '153', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '1128', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '1633', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '1647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '781', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '450', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '1646', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '1260', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '821', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '1645', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '1644', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '1643', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '1642', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '1641', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '679', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '514', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '1640', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '463', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '1639', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '1638', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '420', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '13', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '300', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '1637', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '1636', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '1635', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '1634', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '1034', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '318', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('175', '315', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('174', '1001', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('174', '21', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1632', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '789', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1631', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1630', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1274', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '553', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1629', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1628', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1627', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '442', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1626', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '928', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1625', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '919', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1624', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1623', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1622', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '56', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '926', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1621', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1620', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '800', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1619', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '162', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1618', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '463', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1617', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1616', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1615', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1614', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1613', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1612', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1611', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1411', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1610', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1609', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1608', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1607', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1586', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1572', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '656', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1606', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '179', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('173', '1605', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '1601', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '789', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '377', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '135', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '1600', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '553', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '1599', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '550', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '1604', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '756', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '1603', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '1391', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '352', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '1355', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '1598', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '1597', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '1034', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '215', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '1602', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '1596', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('172', '1168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('171', '1601', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('171', '789', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('171', '377', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('171', '135', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('171', '1600', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('171', '1599', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('171', '550', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('171', '756', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('171', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('171', '1391', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('171', '352', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('171', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('171', '1598', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('171', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('171', '1597', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('171', '1034', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('171', '215', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('171', '1596', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('171', '1168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('311', '2613', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '1582', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '1581', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '1089', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '1580', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '389', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '1579', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '1578', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '165', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '185', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '1577', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '1576', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '350', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '1575', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '742', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '1574', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '1573', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '1104', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '894', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '725', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '1572', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '703', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '1135', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '1583', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '551', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '1584', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '1585', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('168', '313', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('169', '1586', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('169', '1587', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('169', '1411', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('169', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('169', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('169', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('169', '116', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('169', '21', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('169', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('169', '1588', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('169', '919', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('169', '927', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('169', '928', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('169', '1589', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('169', '69', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('169', '1590', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('169', '1425', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('169', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('169', '313', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('170', '1591', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('170', '1592', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('170', '1593', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('170', '1594', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('170', '1595', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '1111', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '2090', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '390', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '115', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '2089', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '565', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '2009', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '2088', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '1415', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '1070', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '819', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '492', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '2087', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '2086', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('206', '314', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('205', '212', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('205', '1001', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('205', '567', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('205', '2085', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('205', '2084', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('205', '2083', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('205', '163', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('205', '1355', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('205', '2082', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('205', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('205', '819', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('205', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('205', '2081', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('205', '715', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('205', '704', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('205', '120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('205', '2080', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('204', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('204', '60', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('204', '2079', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('204', '1426', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('204', '2078', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('204', '2077', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('204', '2076', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('204', '1355', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('204', '484', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('204', '2075', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('204', '2074', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('203', '1099', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('203', '2073', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('203', '1074', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('203', '2072', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('203', '2071', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('203', '1217', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('203', '1355', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('203', '2070', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('203', '220', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('203', '202', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('203', '1347', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('202', '2069', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('202', '147', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('202', '2069', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('202', '2068', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('202', '280', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('202', '550', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('202', '37', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('202', '2067', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('202', '390', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('202', '1355', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('202', '2066', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('202', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('202', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('202', '2065', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('202', '2064', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('202', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('202', '120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('201', '776', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('201', '1074', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('201', '69', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('201', '550', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('201', '1423', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('201', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('201', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('201', '1355', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('201', '161', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('201', '2056', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('201', '2063', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('201', '315', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('201', '2062', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '546', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '67', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '214', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '1074', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '225', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '550', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '2061', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '115', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '2060', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '2059', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '2058', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '2057', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '2056', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '2055', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '2054', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '1168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '2053', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '315', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('200', '2044', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('199', '848', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('199', '2052', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('199', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('199', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('199', '2051', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('199', '425', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('199', '110', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('199', '2050', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('199', '2049', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('199', '1144', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('198', '2048', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('198', '2047', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('271', '1164', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('271', '2432', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('270', '2431', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('196', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('196', '167', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('196', '2043', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('196', '384', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('195', '2042', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('195', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('195', '1296', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('195', '2041', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('195', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('195', '2040', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('195', '2039', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('195', '144', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('195', '2038', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('195', '52', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('194', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('194', '1647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('194', '450', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('194', '776', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('194', '69', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('194', '1120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('194', '1037', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('194', '1050', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('194', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('194', '1266', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('194', '729', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('193', '546', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('193', '850', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('193', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('193', '153', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('193', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('193', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('193', '2037', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('193', '2036', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('193', '2035', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('192', '2034', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('191', '306', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('191', '2033', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('191', '2032', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('191', '1367', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('191', '1210', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('191', '2031', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('191', '1151', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('191', '2030', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('191', '2029', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('191', '484', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('191', '1128', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('191', '2028', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '2021', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '783', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '190', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '2027', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '1136', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '2026', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '2025', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '1079', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '2024', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '81', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '430', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '2023', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '1355', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '425', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '2022', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '2020', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '2019', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '215', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '849', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '568', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '2018', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '2017', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('190', '2016', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('189', '2015', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('189', '546', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('189', '2014', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('188', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('188', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('188', '2013', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('188', '315', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('187', '69', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('187', '2012', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('187', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('187', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('187', '1641', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('187', '1036', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('187', '2011', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('187', '1994', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('187', '733', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('187', '2006', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('187', '1171', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('187', '178', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('187', '2010', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('308', '2605', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('185', '2009', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('185', '74', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('184', '69', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('184', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('184', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('184', '1994', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('184', '1171', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('308', '2607', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('308', '2606', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('308', '2058', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('308', '2040', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('308', '2123', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('308', '2608', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('308', '565', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('308', '149', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('311', '2612', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('310', '439', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('310', '1614', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('310', '240', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('309', '2084', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('309', '979', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('308', '1099', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('308', '567', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('308', '781', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('308', '2611', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('308', '2610', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('308', '2609', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('180', '108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('180', '1987', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('180', '153', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('180', '1986', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('180', '430', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('180', '1639', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('180', '1994', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('180', '1985', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('180', '1984', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('180', '1993', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('180', '1203', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('180', '1992', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('180', '1633', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('180', '1983', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('179', '1991', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('179', '1990', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('179', '1989', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('179', '1988', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('178', '1987', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('178', '1986', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('178', '1639', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('178', '1985', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('178', '1984', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('178', '1983', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('213', '821', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('213', '551', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('213', '912', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('213', '989', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('213', '847', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('213', '1647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('213', '1632', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('213', '108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('214', '2145', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('214', '2146', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('214', '2147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('214', '2148', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('214', '1619', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('214', '743', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('214', '2084', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('214', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('214', '1370', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('214', '1142', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('214', '2149', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('214', '108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('215', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('215', '2053', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('215', '2075', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('215', '2035', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('215', '1359', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('215', '1089', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('215', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('215', '2150', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('215', '60', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('215', '2151', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('215', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('308', '2604', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('308', '2603', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('219', '2157', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('218', '2156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('218', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('218', '2041', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('218', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('218', '2155', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('218', '2154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('219', '2158', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('219', '2159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('219', '215', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('219', '2160', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('219', '2161', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('219', '425', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('219', '2162', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('219', '2163', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('219', '2164', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('220', '2053', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('220', '318', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('220', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('220', '2165', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('220', '450', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('220', '1647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('220', '1213', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '2217', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '2216', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '2215', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('227', '306', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('227', '2214', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('227', '172', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('227', '2213', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('227', '2212', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('227', '2211', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('227', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('227', '2210', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('227', '350', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('227', '2209', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('227', '2083', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('227', '163', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('227', '917', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('227', '1355', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('227', '2208', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('227', '2207', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('227', '2206', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('227', '2205', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('226', '1647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('226', '1631', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('226', '2041', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('226', '2157', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('225', '1647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('225', '2041', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('225', '205', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('225', '2163', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('225', '820', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('225', '2204', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('224', '974', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('224', '550', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('224', '2203', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('224', '546', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('224', '342', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('224', '2059', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('224', '220', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('224', '562', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('224', '2202', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('223', '2201', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('223', '2200', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('223', '2199', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('223', '214', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('223', '318', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('222', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('222', '2198', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('222', '2197', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '2204', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '2218', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '2219', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '2220', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '2221', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '2222', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '1128', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '1184', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '2223', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '2091', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '337', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '386', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '1355', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '2224', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '2120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '2225', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '2226', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '551', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '280', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '372', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '2227', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '2228', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '1125', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '152', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '2229', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '789', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('228', '2230', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('229', '2231', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('229', '2232', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('229', '2233', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('229', '149', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('229', '1359', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('229', '2234', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('229', '2235', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('229', '2236', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('230', '2237', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('230', '821', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('230', '2238', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('230', '135', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('231', '2239', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('231', '2202', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('231', '562', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('231', '220', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('231', '2059', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('231', '545', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('231', '342', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('231', '546', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('231', '2240', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('231', '2203', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('231', '1099', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('231', '550', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('231', '974', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('232', '2241', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('232', '948', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('232', '2242', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('232', '2243', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('232', '2122', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('232', '974', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('233', '2244', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('233', '2156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('234', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('234', '1144', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('234', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('234', '1162', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('234', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('234', '2245', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('234', '567', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('234', '1099', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('235', '318', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('235', '2246', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('235', '2247', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('235', '2159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('235', '2248', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('235', '2249', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('235', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('235', '2250', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('235', '2251', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('235', '2252', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('236', '318', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('236', '2246', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('236', '2247', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('236', '2159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('236', '2248', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('236', '2253', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('236', '2249', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('236', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('236', '2250', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('236', '2251', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('236', '2252', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('236', '1099', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('237', '2254', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('238', '2255', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('238', '2256', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('238', '2257', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('238', '2197', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('238', '2258', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('238', '2259', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('238', '2260', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('238', '2261', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('238', '2262', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('238', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('238', '774', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('239', '2263', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('239', '2108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('239', '2256', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('239', '2264', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('239', '2265', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('239', '821', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('239', '2266', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('240', '315', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('240', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('240', '546', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2319', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2318', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '280', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2317', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2316', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2315', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2314', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '566', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2313', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '1416', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '1038', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '356', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '311', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '81', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '113', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2312', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2311', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2310', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2309', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '1164', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2308', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '896', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2307', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2306', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2305', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '1158', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '733', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '819', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '955', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '1591', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '953', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2304', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2303', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2302', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2300', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '1144', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2299', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2298', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2297', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '1077', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2296', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '406', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2295', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2294', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2293', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '561', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '179', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '560', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '315', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '912', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2002', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2320', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '1074', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '1138', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2068', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '393', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '152', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '974', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '2321', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '153', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('241', '457', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('242', '2322', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('275', '186', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('275', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '70', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '52', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '1099', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '176', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '2453', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '2439', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '186', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '566', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '2438', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '2435', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '1416', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '2452', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '1317', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '2437', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '195', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '2451', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '422', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '857', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '2450', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '420', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('273', '70', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('273', '52', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '2304', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '2436', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '157', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '1250', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '2434', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '2449', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '2448', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('273', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('273', '2439', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('273', '186', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '94', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('274', '2447', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('271', '188', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('271', '2433', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('269', '811', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('272', '1250', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('272', '2434', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('272', '94', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('268', '2427', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('268', '2320', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('268', '2426', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('268', '551', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('273', '566', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('273', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('273', '2438', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('273', '2435', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('273', '1317', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('269', '2430', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('269', '739', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('269', '2114', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('269', '792', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('268', '2428', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('273', '2437', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('273', '195', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('273', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('273', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('273', '2436', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('273', '2434', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('273', '94', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('272', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('272', '2435', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('272', '388', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('276', '180', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('276', '2454', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('276', '2432', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('276', '2455', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('276', '1121', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('276', '186', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('276', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('276', '2456', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('276', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('276', '377', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('276', '306', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('277', '2457', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('277', '25', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('277', '2458', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('277', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('277', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('278', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('278', '1047', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('278', '37', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('278', '2461', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('278', '2459', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('278', '201', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('278', '2460', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('278', '2462', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('279', '2463', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('279', '2460', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('280', '546', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('280', '2093', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('281', '315', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('281', '13', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('281', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('281', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('281', '927', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('281', '2464', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('281', '2128', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('281', '2319', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('281', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('281', '306', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '2465', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '2466', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '2467', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '2468', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '1049', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '157', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '411', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '651', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '2469', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '1144', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '1184', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '2470', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '792', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '1149', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '927', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '1406', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '167', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '440', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '2471', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '1646', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '2003', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '456', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '1408', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('282', '306', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2472', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '52', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '701', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2474', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2219', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2475', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '651', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '1010', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '492', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '819', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2478', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '425', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2479', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '1355', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '163', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '430', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2480', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2041', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2481', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2031', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2482', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2483', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '37', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2484', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2485', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '450', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '141', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2486', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2487', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2473', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2476', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2477', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '1362', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2488', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('283', '2489', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('284', '991', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('284', '1411', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('284', '2490', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('284', '19', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('284', '2463', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('284', '167', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '2016', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '2491', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '2492', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '2034', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '1114', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '1411', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '2493', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '894', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '352', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '1071', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '185', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '2494', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '2495', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '1417', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '2496', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '927', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '1419', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '1420', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '2497', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '567', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '2498', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('285', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('308', '2602', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('288', '2500', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('288', '2501', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('288', '492', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('289', '2502', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('289', '19', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('289', '2503', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('289', '2504', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('289', '110', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('289', '546', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('289', '2505', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('289', '1036', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('289', '2506', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('289', '2507', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('289', '1629', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('289', '2508', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('289', '2236', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('289', '306', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('290', '2509', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('290', '2510', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('290', '2511', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('290', '2512', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('290', '2513', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('290', '452', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('291', '991', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('291', '2514', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('291', '2515', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('291', '2056', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('291', '2516', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('291', '2517', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('291', '938', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('291', '2518', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('291', '109', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('291', '2519', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('291', '2520', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('291', '918', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('291', '2521', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('291', '2522', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('291', '2523', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('291', '2524', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('291', '2052', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('291', '968', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('291', '2525', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('291', '2526', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '2527', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '2219', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '2528', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '240', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '2529', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '2530', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '2531', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '13', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '492', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '1413', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '2103', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '73', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '2308', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '2532', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '430', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '1643', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '2031', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '439', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '2483', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '1369', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '2533', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '2427', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('292', '2534', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('293', '52', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('293', '2535', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('293', '484', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('293', '2538', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('293', '2116', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('293', '149', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('293', '918', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('293', '2079', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('293', '2540', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('293', '2541', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('293', '930', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('293', '2536', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('293', '2537', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('293', '1362', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('293', '2539', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('293', '550', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('293', '2542', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('294', '2423', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('294', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('295', '930', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '1168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '2543', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '946', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '2544', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '651', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '2545', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '386', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '2546', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '2547', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '163', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '184', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '2548', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '2549', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '2550', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '2551', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '2552', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '1264', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '208', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '2553', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '188', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '550', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '2554', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('296', '2555', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('297', '1155', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('297', '946', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('297', '1607', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('297', '2556', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('297', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('297', '2557', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('297', '2558', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('298', '2263', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('298', '2559', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('298', '2053', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('298', '2138', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('298', '2058', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('298', '19', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('298', '425', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('298', '1355', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('298', '2560', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('298', '352', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('298', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('298', '2561', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('298', '168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('298', '2540', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('298', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('298', '169', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('298', '2562', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('298', '974', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('299', '315', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('299', '2563', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('299', '1607', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('299', '2564', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('299', '19', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('299', '1355', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('299', '362', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('299', '2565', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('299', '2566', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('299', '821', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('299', '2567', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('299', '188', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('299', '2568', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('299', '2508', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('299', '2569', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('299', '2570', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('299', '2093', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('299', '930', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('299', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('300', '2571', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('300', '1287', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('300', '2572', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('300', '2566', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('300', '2573', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('300', '2569', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('300', '771', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('300', '153', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('301', '2574', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('301', '2575', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('301', '1116', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('301', '492', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('301', '2576', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('301', '514', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('301', '565', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('301', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('301', '1121', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('301', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('301', '135', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('301', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('302', '2575', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('302', '123', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('302', '1411', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('302', '484', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('302', '954', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('302', '492', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('302', '463', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('302', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('302', '514', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('302', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('302', '2577', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('302', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('302', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('302', '2578', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('302', '450', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('302', '848', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('303', '2579', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('303', '2580', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('303', '2093', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('304', '2581', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('304', '2582', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('304', '2583', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('304', '2584', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('304', '2585', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('304', '734', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('304', '109', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('304', '110', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('304', '2586', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('304', '149', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('304', '2587', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('304', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('304', '2588', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('304', '37', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('304', '188', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('304', '2589', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('304', '1138', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('304', '930', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('305', '849', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('305', '1034', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('305', '2590', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('305', '2591', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('305', '254', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('305', '2120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('305', '1641', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('305', '1382', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('305', '487', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('305', '188', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('305', '550', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('305', '808', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('305', '2592', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('305', '1647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('305', '2593', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('305', '227', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('306', '849', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('306', '2590', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('306', '2591', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('306', '254', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('306', '2594', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('306', '2120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('306', '1641', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('306', '1382', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('306', '487', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('306', '188', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('306', '550', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('306', '442', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('306', '2592', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('306', '1647', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('306', '2427', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('306', '2593', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('306', '455', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('306', '227', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '849', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '2575', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '2595', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '1635', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '798', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '13', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '2596', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '737', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '99', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '2597', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '1047', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '2598', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '2599', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '2600', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '188', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '2569', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '2570', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '2093', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '221', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '2601', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('307', '1632', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('312', '894', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('312', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('312', '81', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('312', '21', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('312', '2265', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('312', '2621', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('312', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('312', '1111', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('312', '190', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('312', '2622', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('312', '393', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('312', '1048', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('313', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('313', '712', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('313', '158', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('313', '1128', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('313', '2623', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('313', '2056', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('313', '421', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('313', '2624', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('313', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('313', '1041', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('313', '2625', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('313', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('313', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('313', '2626', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('313', '567', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('314', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('314', '712', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('314', '158', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('314', '1128', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('314', '2623', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('314', '2056', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('314', '421', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('314', '564', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('314', '2624', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('314', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('314', '1041', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('314', '2625', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('314', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('314', '2578', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('314', '2315', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('314', '2627', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('314', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('314', '2626', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('314', '567', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('314', '1099', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('315', '704', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('315', '318', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('315', '1034', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('315', '413', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('315', '1010', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('315', '2628', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('315', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('315', '564', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('315', '2629', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('315', '116', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('315', '21', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('315', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('315', '1423', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('315', '172', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('315', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('315', '2630', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('315', '2631', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('316', '158', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('316', '168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('316', '172', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('316', '32', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('317', '2614', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('317', '127', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('317', '81', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('317', '111', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('317', '996', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('317', '188', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('317', '1589', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('318', '850', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('319', '2632', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('319', '894', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('319', '1071', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('319', '2261', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('319', '2633', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '94', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '2634', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '2434', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '191', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '2535', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '193', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '563', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '896', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '679', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '1087', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '113', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '2635', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '2636', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '2637', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '2124', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '2638', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '2424', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '2639', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '927', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '2640', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '1646', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('320', '455', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('321', '2634', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('321', '651', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('321', '2641', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('321', '2642', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('321', '2549', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('321', '1296', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('321', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('321', '2601', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('321', '1045', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('322', '2634', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('322', '2109', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('322', '2643', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('322', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('322', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('322', '859', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('322', '979', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('322', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('323', '2634', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('323', '2109', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('323', '2643', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('323', '2644', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('323', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('323', '2645', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('323', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('323', '859', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('323', '2646', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('323', '979', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('323', '70', '0');
#
# TABLE: phpbb_sessions
#
DROP TABLE IF EXISTS phpbb_sessions;
CREATE TABLE phpbb_sessions(
	session_id char(32) NOT NULL,
	session_user_id mediumint(8) NOT NULL,
	session_start int(11) NOT NULL,
	session_time int(11) NOT NULL,
	session_ip char(8) NOT NULL,
	session_page int(11) NOT NULL,
	session_logged_in tinyint(1) NOT NULL,
	session_admin tinyint(2) NOT NULL, 
	PRIMARY KEY (session_id), 
	KEY session_user_id (session_user_id), 
	KEY session_id_ip_user_id (session_id, session_ip, session_user_id)
);

#
# Table Data for phpbb_sessions
#

INSERT INTO phpbb_sessions (session_id, session_user_id, session_start, session_time, session_ip, session_page, session_logged_in, session_admin) VALUES('664bf2e0cda59bbfbd0db456966359df', '2', '1180575722', '1180575722', '443ac980', '0', '1', '1');
INSERT INTO phpbb_sessions (session_id, session_user_id, session_start, session_time, session_ip, session_page, session_logged_in, session_admin) VALUES('0645d636e584a6b772ddf2f487c94aae', '-1', '1180572824', '1180572824', '48cf0e89', '-4', '0', '0');
INSERT INTO phpbb_sessions (session_id, session_user_id, session_start, session_time, session_ip, session_page, session_logged_in, session_admin) VALUES('61cb93107fd81d0a47f42260d9717c37', '3', '1180575553', '1180575553', '42d68ab1', '0', '1', '0');
INSERT INTO phpbb_sessions (session_id, session_user_id, session_start, session_time, session_ip, session_page, session_logged_in, session_admin) VALUES('4ae9c2447a4e406fe5c7c504d469c1ce', '-1', '1180575225', '1180575225', '42f9464b', '1', '0', '0');
#
# TABLE: phpbb_smilies
#
DROP TABLE IF EXISTS phpbb_smilies;
CREATE TABLE phpbb_smilies(
	smilies_id smallint(5) unsigned NOT NULL auto_increment,
	code varchar(50),
	smile_url varchar(100),
	emoticon varchar(75), 
	PRIMARY KEY (smilies_id)
);

#
# Table Data for phpbb_smilies
#

INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('1', ':D', 'icon_biggrin.gif', 'Very Happy');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('2', ':-D', 'icon_biggrin.gif', 'Very Happy');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('3', ':grin:', 'icon_biggrin.gif', 'Very Happy');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('4', ':)', 'icon_smile.gif', 'Smile');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('5', ':-)', 'icon_smile.gif', 'Smile');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('6', ':smile:', 'icon_smile.gif', 'Smile');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('7', ':(', 'icon_sad.gif', 'Sad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('8', ':-(', 'icon_sad.gif', 'Sad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('9', ':sad:', 'icon_sad.gif', 'Sad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('10', ':o', 'icon_surprised.gif', 'Surprised');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('11', ':-o', 'icon_surprised.gif', 'Surprised');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('12', ':eek:', 'icon_surprised.gif', 'Surprised');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('13', ':shock:', 'icon_eek.gif', 'Shocked');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('14', ':?', 'icon_confused.gif', 'Confused');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('15', ':-?', 'icon_confused.gif', 'Confused');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('16', ':???:', 'icon_confused.gif', 'Confused');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('17', '8)', 'icon_cool.gif', 'Cool');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('18', '8-)', 'icon_cool.gif', 'Cool');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('19', ':cool:', 'icon_cool.gif', 'Cool');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('20', ':lol:', 'icon_lol.gif', 'Laughing');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('21', ':x', 'icon_mad.gif', 'Mad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('22', ':-x', 'icon_mad.gif', 'Mad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('23', ':mad:', 'icon_mad.gif', 'Mad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('24', ':P', 'icon_razz.gif', 'Razz');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('25', ':-P', 'icon_razz.gif', 'Razz');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('26', ':razz:', 'icon_razz.gif', 'Razz');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('27', ':oops:', 'icon_redface.gif', 'Embarassed');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('28', ':cry:', 'icon_cry.gif', 'Crying or Very sad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('29', ':evil:', 'icon_evil.gif', 'Evil or Very Mad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('30', ':twisted:', 'icon_twisted.gif', 'Twisted Evil');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('31', ':roll:', 'icon_rolleyes.gif', 'Rolling Eyes');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('32', ':wink:', 'icon_wink.gif', 'Wink');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('33', ';)', 'icon_wink.gif', 'Wink');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('34', ';-)', 'icon_wink.gif', 'Wink');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('35', ':!:', 'icon_exclaim.gif', 'Exclamation');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('36', ':?:', 'icon_question.gif', 'Question');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('37', ':idea:', 'icon_idea.gif', 'Idea');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('38', ':arrow:', 'icon_arrow.gif', 'Arrow');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('39', ':|', 'icon_neutral.gif', 'Neutral');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('40', ':-|', 'icon_neutral.gif', 'Neutral');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('41', ':neutral:', 'icon_neutral.gif', 'Neutral');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('42', ':mrgreen:', 'icon_mrgreen.gif', 'Mr. Green');
#
# TABLE: phpbb_themes
#
DROP TABLE IF EXISTS phpbb_themes;
CREATE TABLE phpbb_themes(
	themes_id mediumint(8) unsigned NOT NULL auto_increment,
	template_name varchar(30) NOT NULL,
	style_name varchar(30) NOT NULL,
	head_stylesheet varchar(100),
	body_background varchar(100),
	body_bgcolor varchar(6),
	body_text varchar(6),
	body_link varchar(6),
	body_vlink varchar(6),
	body_alink varchar(6),
	body_hlink varchar(6),
	tr_color1 varchar(6),
	tr_color2 varchar(6),
	tr_color3 varchar(6),
	tr_class1 varchar(25),
	tr_class2 varchar(25),
	tr_class3 varchar(25),
	th_color1 varchar(6),
	th_color2 varchar(6),
	th_color3 varchar(6),
	th_class1 varchar(25),
	th_class2 varchar(25),
	th_class3 varchar(25),
	td_color1 varchar(6),
	td_color2 varchar(6),
	td_color3 varchar(6),
	td_class1 varchar(25),
	td_class2 varchar(25),
	td_class3 varchar(25),
	fontface1 varchar(50),
	fontface2 varchar(50),
	fontface3 varchar(50),
	fontsize1 tinyint(4),
	fontsize2 tinyint(4),
	fontsize3 tinyint(4),
	fontcolor1 varchar(6),
	fontcolor2 varchar(6),
	fontcolor3 varchar(6),
	span_class1 varchar(25),
	span_class2 varchar(25),
	span_class3 varchar(25),
	img_size_poll smallint(5) unsigned,
	img_size_privmsg smallint(5) unsigned, 
	PRIMARY KEY (themes_id)
);

#
# Table Data for phpbb_themes
#

INSERT INTO phpbb_themes (themes_id, template_name, style_name, head_stylesheet, body_background, body_bgcolor, body_text, body_link, body_vlink, body_alink, body_hlink, tr_color1, tr_color2, tr_color3, tr_class1, tr_class2, tr_class3, th_color1, th_color2, th_color3, th_class1, th_class2, th_class3, td_color1, td_color2, td_color3, td_class1, td_class2, td_class3, fontface1, fontface2, fontface3, fontsize1, fontsize2, fontsize3, fontcolor1, fontcolor2, fontcolor3, span_class1, span_class2, span_class3, img_size_poll, img_size_privmsg) VALUES('1', 'subSilver', 'subSilver', 'subSilver.css', '', 'E5E5E5', '000000', '006699', '5493B4', '', 'DD6900', 'EFEFEF', 'DEE3E7', 'D1D7DC', '', '', '', '98AAB1', '006699', 'FFFFFF', 'cellpic1.gif', 'cellpic3.gif', 'cellpic2.jpg', 'FAFAFA', 'FFFFFF', '', 'row1', 'row2', '', 'Verdana, Arial, Helvetica, sans-serif', 'Trebuchet MS', 'Courier, \'Courier New\', sans-serif', '10', '11', '12', '444444', '006600', 'FFA34F', '', '', '', NULL, NULL);
#
# TABLE: phpbb_themes_name
#
DROP TABLE IF EXISTS phpbb_themes_name;
CREATE TABLE phpbb_themes_name(
	themes_id smallint(5) unsigned NOT NULL,
	tr_color1_name char(50),
	tr_color2_name char(50),
	tr_color3_name char(50),
	tr_class1_name char(50),
	tr_class2_name char(50),
	tr_class3_name char(50),
	th_color1_name char(50),
	th_color2_name char(50),
	th_color3_name char(50),
	th_class1_name char(50),
	th_class2_name char(50),
	th_class3_name char(50),
	td_color1_name char(50),
	td_color2_name char(50),
	td_color3_name char(50),
	td_class1_name char(50),
	td_class2_name char(50),
	td_class3_name char(50),
	fontface1_name char(50),
	fontface2_name char(50),
	fontface3_name char(50),
	fontsize1_name char(50),
	fontsize2_name char(50),
	fontsize3_name char(50),
	fontcolor1_name char(50),
	fontcolor2_name char(50),
	fontcolor3_name char(50),
	span_class1_name char(50),
	span_class2_name char(50),
	span_class3_name char(50), 
	PRIMARY KEY (themes_id)
);

#
# Table Data for phpbb_themes_name
#

INSERT INTO phpbb_themes_name (themes_id, tr_color1_name, tr_color2_name, tr_color3_name, tr_class1_name, tr_class2_name, tr_class3_name, th_color1_name, th_color2_name, th_color3_name, th_class1_name, th_class2_name, th_class3_name, td_color1_name, td_color2_name, td_color3_name, td_class1_name, td_class2_name, td_class3_name, fontface1_name, fontface2_name, fontface3_name, fontsize1_name, fontsize2_name, fontsize3_name, fontcolor1_name, fontcolor2_name, fontcolor3_name, span_class1_name, span_class2_name, span_class3_name) VALUES('1', 'The lightest row colour', 'The medium row color', 'The darkest row colour', '', '', '', 'Border round the whole page', 'Outer table border', 'Inner table border', 'Silver gradient picture', 'Blue gradient picture', 'Fade-out gradient on index', 'Background for quote boxes', 'All white areas', '', 'Background for topic posts', '2nd background for topic posts', '', 'Main fonts', 'Additional topic title font', 'Form fonts', 'Smallest font size', 'Medium font size', 'Normal font size (post body etc)', 'Quote & copyright text', 'Code text colour', 'Main table header text colour', '', '', '');
#
# TABLE: phpbb_topics
#
DROP TABLE IF EXISTS phpbb_topics;
CREATE TABLE phpbb_topics(
	topic_id mediumint(8) unsigned NOT NULL auto_increment,
	forum_id smallint(8) unsigned NOT NULL,
	topic_title char(60) NOT NULL,
	topic_poster mediumint(8) NOT NULL,
	topic_time int(11) NOT NULL,
	topic_views mediumint(8) unsigned NOT NULL,
	topic_replies mediumint(8) unsigned NOT NULL,
	topic_status tinyint(3) NOT NULL,
	topic_vote tinyint(1) NOT NULL,
	topic_type tinyint(3) NOT NULL,
	topic_first_post_id mediumint(8) unsigned NOT NULL,
	topic_last_post_id mediumint(8) unsigned NOT NULL,
	topic_moved_id mediumint(8) unsigned NOT NULL, 
	PRIMARY KEY (topic_id), 
	KEY forum_id (forum_id), 
	KEY topic_moved_id (topic_moved_id), 
	KEY topic_status (topic_status), 
	KEY topic_type (topic_type)
);

#
# Table Data for phpbb_topics
#

INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('2', '1', 'Moo', '3', '1150301613', '204', '3', '0', '0', '0', '2', '5', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('60', '1', 'oh yeah my  case got thrown out', '6', '1172917933', '155', '2', '0', '0', '0', '267', '272', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('4', '1', 'asdasf', '6', '1150476862', '289', '5', '0', '0', '0', '7', '147', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('5', '1', 'activity', '5', '1151172279', '368', '6', '0', '0', '0', '11', '27', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('16', '1', 'SAS, WoW what server?', '17', '1157834949', '942', '32', '0', '0', '0', '50', '140', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('7', '1', 'WoW', '7', '1151275550', '306', '6', '0', '0', '0', '14', '26', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('62', '1', 'WOW anyone?', '6', '1175263724', '171', '6', '0', '0', '0', '273', '319', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('9', '1', 'WOW: Burning Crusade. Archimonde?', '6', '1152577884', '238', '3', '0', '0', '0', '28', '31', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('10', '1', 'Donovan', '5', '1153784519', '192', '1', '0', '0', '0', '32', '69', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('11', '1', 'DarkFall', '10', '1154580826', '146', '0', '0', '0', '0', '33', '33', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('12', '1', 'Memories....', '11', '1154906773', '268', '3', '0', '0', '0', '34', '38', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('13', '1', 'Wow this is completely fucked read guys.', '6', '1154999729', '749', '20', '0', '0', '0', '37', '114', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('22', '1', 'Rad is a little bitch.', '24', '1158978116', '494', '16', '0', '0', '0', '70', '170', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('25', '1', 'Props to the new Site Design', '24', '1159483287', '127', '2', '0', '0', '0', '91', '103', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('26', '1', 'Pictures wanted!', '2', '1159517331', '115', '1', '0', '0', '0', '96', '104', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('27', '1', 'southpark', '24', '1159653108', '157', '3', '0', '0', '0', '98', '101', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('28', '1', 'Oldies But Goodies', '27', '1160924799', '421', '15', '0', '0', '0', '109', '138', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('29', '1', 'Just moved my WOW char to Blackrock...', '30', '1161554213', '182', '6', '0', '0', '0', '130', '199', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('30', '1', 'Vent', '27', '1161954676', '278', '6', '0', '0', '0', '141', '153', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('31', '1', 'Rape charge dropped.... well reduced they reduced it', '6', '1162114378', '125', '2', '0', '0', '0', '143', '146', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('32', '1', 'Ultime On-Line', '5', '1162421818', '249', '9', '0', '0', '0', '150', '174', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('35', '1', 'What\'s everyone doing for Christmas?', '8', '1166159248', '141', '7', '0', '0', '0', '175', '187', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('37', '1', 'Good times ...', '4', '1167434714', '92', '1', '0', '0', '0', '188', '189', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('38', '1', 'Googled!', '39', '1168411414', '136', '5', '0', '0', '0', '190', '228', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('39', '1', 'hey fuckers', '40', '1168541389', '134', '2', '0', '0', '0', '193', '215', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('61', '1', 'i like men', '27', '1174684935', '101', '2', '0', '0', '0', '269', '271', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('41', '1', 'Hey guys check this out', '13', '1168668538', '184', '9', '0', '0', '0', '200', '234', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('42', '1', 'Anyone interested in planning a RL meeting somewhere fun?', '8', '1169302528', '490', '22', '0', '0', '0', '210', '317', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('44', '1', 'SAS vent', '13', '1169885820', '98', '3', '0', '0', '0', '224', '232', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('45', '1', 'hey bc', '9', '1172290645', '249', '14', '0', '0', '0', '240', '316', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('63', '1', 'Donovan is approaching Leo status.', '5', '1177114537', '63', '2', '0', '0', '0', '278', '284', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('64', '1', 'We\'ve been entered in Age of Conan and Warhammer Online..', '4', '1178065015', '76', '6', '0', '0', '0', '283', '310', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('65', '1', 'SAS Reunion on Ultima Online... a freeshard we can dominate.', '6', '1178915469', '127', '16', '0', '0', '0', '293', '323', '0');
#
# TABLE: phpbb_topics_watch
#
DROP TABLE IF EXISTS phpbb_topics_watch;
CREATE TABLE phpbb_topics_watch(
	topic_id mediumint(8) unsigned NOT NULL,
	user_id mediumint(8) NOT NULL,
	notify_status tinyint(1) NOT NULL, 
	KEY topic_id (topic_id), 
	KEY user_id (user_id), 
	KEY notify_status (notify_status)
);

#
# Table Data for phpbb_topics_watch
#

INSERT INTO phpbb_topics_watch (topic_id, user_id, notify_status) VALUES('29', '30', '1');
#
# TABLE: phpbb_user_group
#
DROP TABLE IF EXISTS phpbb_user_group;
CREATE TABLE phpbb_user_group(
	group_id mediumint(8) NOT NULL,
	user_id mediumint(8) NOT NULL,
	user_pending tinyint(1), 
	KEY group_id (group_id), 
	KEY user_id (user_id)
);

#
# Table Data for phpbb_user_group
#

INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('1', '-1', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('2', '2', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('3', '3', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('4', '4', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('5', '5', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('6', '6', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('7', '7', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('8', '8', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('9', '9', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('10', '10', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('11', '11', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('12', '12', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('14', '13', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('96', '45', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('72', '40', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('18', '17', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('35', '26', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('42', '28', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('44', '30', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('30', '24', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('28', '23', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('37', '27', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('103', '52', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('59', '34', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('54', '2', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('71', '39', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('94', '43', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('107', '56', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('58', '33', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('101', '50', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('105', '54', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('104', '53', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('93', '42', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('106', '55', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('95', '44', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('100', '49', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('102', '51', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('92', '41', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('97', '46', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('99', '48', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('98', '47', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('108', '57', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('109', '58', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('110', '59', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('111', '60', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('112', '61', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('113', '62', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('114', '63', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('115', '64', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('116', '65', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('117', '66', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('118', '67', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('119', '68', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('120', '69', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('121', '70', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('122', '71', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('123', '72', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('124', '73', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('125', '74', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('126', '75', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('127', '76', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('128', '77', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('129', '78', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('130', '79', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('131', '80', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('132', '81', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('133', '82', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('134', '83', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('135', '84', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('136', '85', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('137', '86', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('138', '87', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('139', '88', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('140', '89', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('141', '90', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('142', '91', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('143', '92', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('144', '93', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('145', '94', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('146', '95', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('147', '96', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('148', '97', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('149', '98', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('220', '169', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('151', '100', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('152', '101', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('153', '102', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('154', '103', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('155', '104', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('156', '105', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('157', '106', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('158', '107', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('159', '108', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('160', '109', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('161', '110', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('162', '111', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('163', '112', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('164', '113', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('165', '114', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('166', '115', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('167', '116', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('168', '117', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('169', '118', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('170', '119', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('171', '120', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('172', '121', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('173', '122', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('174', '123', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('175', '124', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('176', '125', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('177', '126', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('178', '127', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('179', '128', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('180', '129', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('181', '130', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('182', '131', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('183', '132', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('184', '133', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('185', '134', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('186', '135', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('187', '136', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('188', '137', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('189', '138', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('190', '139', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('191', '140', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('192', '141', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('193', '142', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('194', '143', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('195', '144', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('196', '145', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('197', '146', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('198', '147', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('199', '148', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('200', '149', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('201', '150', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('202', '151', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('203', '152', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('204', '153', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('205', '154', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('206', '155', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('207', '156', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('208', '157', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('209', '158', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('210', '159', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('211', '160', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('219', '168', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('213', '162', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('214', '163', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('215', '164', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('216', '165', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('217', '166', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('218', '167', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('221', '170', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('222', '171', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('223', '172', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('224', '173', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('225', '174', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('226', '175', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('227', '176', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('228', '177', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('229', '178', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('230', '179', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('231', '180', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('232', '181', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('233', '182', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('234', '183', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('235', '184', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('236', '185', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('237', '186', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('238', '163', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('239', '164', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('240', '165', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('241', '166', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('242', '167', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('243', '168', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('244', '169', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('245', '170', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('246', '171', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('247', '172', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('248', '173', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('249', '174', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('250', '175', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('251', '176', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('252', '177', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('253', '178', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('254', '179', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('255', '180', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('256', '181', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('257', '182', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('258', '183', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('259', '184', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('260', '185', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('261', '186', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('262', '187', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('263', '188', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('264', '189', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('265', '190', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('266', '191', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('267', '192', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('268', '193', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('269', '194', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('270', '195', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('271', '196', '0');
#
# TABLE: phpbb_users
#
DROP TABLE IF EXISTS phpbb_users;
CREATE TABLE phpbb_users(
	user_id mediumint(8) NOT NULL,
	user_active tinyint(1) DEFAULT '1',
	username varchar(25) NOT NULL,
	user_password varchar(32) NOT NULL,
	user_session_time int(11) NOT NULL,
	user_session_page smallint(5) NOT NULL,
	user_lastvisit int(11) NOT NULL,
	user_regdate int(11) NOT NULL,
	user_level tinyint(4),
	user_posts mediumint(8) unsigned NOT NULL,
	user_timezone decimal(5,2) DEFAULT '0.00' NOT NULL,
	user_style tinyint(4),
	user_lang varchar(255),
	user_dateformat varchar(14) DEFAULT 'd M Y H:i' NOT NULL,
	user_new_privmsg smallint(5) unsigned NOT NULL,
	user_unread_privmsg smallint(5) unsigned NOT NULL,
	user_last_privmsg int(11) NOT NULL,
	user_login_tries smallint(5) unsigned NOT NULL,
	user_last_login_try int(11) NOT NULL,
	user_emailtime int(11),
	user_viewemail tinyint(1),
	user_attachsig tinyint(1),
	user_allowhtml tinyint(1) DEFAULT '1',
	user_allowbbcode tinyint(1) DEFAULT '1',
	user_allowsmile tinyint(1) DEFAULT '1',
	user_allowavatar tinyint(1) DEFAULT '1' NOT NULL,
	user_allow_pm tinyint(1) DEFAULT '1' NOT NULL,
	user_allow_viewonline tinyint(1) DEFAULT '1' NOT NULL,
	user_notify tinyint(1) DEFAULT '1' NOT NULL,
	user_notify_pm tinyint(1) NOT NULL,
	user_popup_pm tinyint(1) NOT NULL,
	user_rank int(11),
	user_avatar varchar(100),
	user_avatar_type tinyint(4) NOT NULL,
	user_email varchar(255),
	user_icq varchar(15),
	user_website varchar(100),
	user_from varchar(100),
	user_sig text,
	user_sig_bbcode_uid varchar(10),
	user_aim varchar(255),
	user_yim varchar(255),
	user_msnm varchar(255),
	user_occ varchar(100),
	user_interests varchar(255),
	user_actkey varchar(32),
	user_newpasswd varchar(32), 
	PRIMARY KEY (user_id), 
	KEY user_session_time (user_session_time)
);

#
# Table Data for phpbb_users
#

INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('-1', '0', 'Anonymous', '', '0', '0', '0', '1150289148', '0', '0', '0.00', NULL, '', '', '0', '0', '0', '0', '0', NULL, '0', '0', '1', '1', '1', '1', '0', '1', '0', '1', '0', NULL, '', '0', '', '', '', '', '', NULL, '', '', '', '', '', '', '');
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('2', '1', 'Aries', '3c2c266a60d4982f5834d8010be5ebda', '1180575709', '0', '1180349607', '1150289148', '1', '28', '0.00', '1', 'english', 'd M Y h:i a', '0', '0', '1172701551', '0', '0', NULL, '1', '0', '0', '1', '1', '1', '1', '0', '0', '1', '1', '1', '367882059453290f6e09d5.jpg', '1', 'aries@sasguild.org', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('3', '1', 'Garen', 'a7fcf4273ef385171d3ef08ba32429a4', '1180575553', '0', '1180500828', '1150301577', '0', '9', '-8.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '1177308477', '0', '0', NULL, '1', '1', '0', '1', '1', '1', '1', '1', '0', '0', '1', '0', '', '0', 'meekrobe@gmail.com', '9114700', '', '', '', '', 'supergaren', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('4', '1', 'Bc', '37f8bf33853e0a8c55c5fd2a26f9ffc0', '1180412656', '0', '1180230630', '1150401111', '0', '52', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '3', '1180022724', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '4.jpg', '1', 'evan_si@hotmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('5', '1', 'Access', 'a9ff9abb75da969147c90018c936cf69', '1180409794', '0', '1180382267', '1150476697', '2', '23', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'dev.null@cox.net', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('6', '1', 'Lakkin', 'cb16cefd41d8c728b35361f776711ead', '1180301993', '-9', '1179846668', '1150476840', '0', '36', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'pjohn0101@gmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('7', '1', 'Turkel', 'b30bd351371c686298d32281b337e8e9', '1169018637', '1', '1153901581', '1151275494', '0', '3', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'simonturkel@gmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('8', '1', 'Nexus', '9b7d722b58370498cd39104b2d971978', '1176609827', '1', '1169995921', '1151495156', '1', '11', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'xerais@gmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('9', '1', 'DC', '62a2a7da6217f52c75c9f14abfb0d37f', '1180486653', '0', '1180414300', '1152682838', '0', '32', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'sirjamesht@yahoo.com', '8257591', '', '', '', '', 'Balanced+In+Fire', '', '', '', 'Rivan\'s Mom', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('34', '1', 'rivan', '216970b71c6c134b8748390066177d22', '1164249816', '0', '1164249816', '1164249682', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'arronalds@gmail.com', '', '', '', '', '', '', '', '', '', '', 'f8a70a55d65c2', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('10', '1', 'Justinsane', '2cac45258b90261b625d70949d7639ca', '1164866952', '0', '1164566344', '1154580715', '0', '3', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'shoobz@gmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('11', '1', 'Matt', 'ae76a058f15da8a9d4e87c0fecd746bf', '1154907064', '0', '1154906623', '1154906611', '0', '1', '-5.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '3', '1163780157', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'matt@deniedproject.net', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('12', '1', 'Geno', '9bb6920f7279b2600bc792ac89d43494', '1155986089', '0', '1155954418', '1155776471', '0', '2', '1.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'shadowlord@gbg.bonet.se', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('17', '1', 'Locke of SAS', 'da14a7168b547f35ea0c6fa9f50de63e', '1176863578', '1', '1174355741', '1157834407', '0', '15', '-8.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '1164812153', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'davgoff@pacbell.net', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('13', '1', 'Dakkon', '95e77c4b5dcd0b1fe51d3b6f66b01aaf', '1178835169', '2', '1171089574', '1157159218', '0', '8', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'blitz@rerolled.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('30', '1', 'Hercules', 'f3aca6389d9c503e0b0475b02e37200c', '1168625019', '1', '1168625017', '1161553471', '0', '3', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'shayaanf@yahoo.com', '', '', '', '', '', '', '', '', '', '', 'f5ff35a8e55df', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('28', '1', 'Grinch', '17179f18253ec0c7ef581a2faa8f8a9d', '1162159177', '1', '1162092405', '1161356525', '0', '3', '0.00', '1', 'english', 'D M d, Y g:i a', '1', '0', '1164812236', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'lanman@pldi.net', '13468807', '', '', '', '', '', '', 'lanman@pldi.net', '', '', 'ca5fbeb3b28ab', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('23', '1', 'rad', '6b519503a5a9fd7134a763ab5a985287', '1168657062', '0', '1163902393', '1158784619', '0', '7', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '1163293888', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'radzorus@hotmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('27', '1', 'Pagan', '8763d3f1e0eff898d33af9ac1bd6f27d', '1179930262', '0', '1178835827', '1160751097', '0', '18', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '1174684969', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '27.jpg', '1', 'pagan1530@hotmail.com', '', '', '', '', '', '', '', '', '', '', 'bfc6f0f2d6d9a', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('26', '1', 'RoSTraX', '5f29e63a3f26798930e5bf218445164f', '1179353915', '-9', '1173475524', '1159966529', '0', '10', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '1', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'rostrax@Hotmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('24', '1', '[SAS]Justin', '2cac45258b90261b625d70949d7639ca', '1164866980', '0', '1164566450', '1158978062', '0', '5', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '1159653075', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'jayemsee@hotmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('39', '1', 'arkaine', '97d954fc41ecc24a0972a0b0b9a18054', '1180567790', '1', '1178734217', '1168411205', '0', '8', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'arkaine00@gmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('40', '1', 'haties', 'f0af962ddbc82430e947390b2f3f6e49', '1180036365', '1', '1168624760', '1168541290', '0', '4', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'corylee@gmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('33', '1', 'TyraeL', '26c147f84d8724a89a16ab6b47258b93', '1164243556', '2', '1164228575', '1164228494', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'tyrael84@hotmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('163', '0', 'tomy-londoner', '1cfa3c90b83455429602c9d791967c7a', '0', '0', '0', '1179566193', '0', '0', '-12.00', '1', 'english', 'catetomy', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'testwpage@medics.nazwa.pl', '1564654564654', 'http://youriloan.info', 'UK', 'London', 'bb072a4216', 'cat', 'cat', 'cat', 'London', 'cars', '733967ffef945', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('164', '0', 'IrinaTocka', 'cbbbf375aef73fad38d36435cbe64de0', '0', '0', '0', '1179577817', '0', '0', '1.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '1', '1', '1', '0', '1', '0', '0', '', '0', 'irinatocka@gmail.com', '', 'http://detakeberani.info/74.html', 'Massachusetts', '', '', '', '', '', '', '', 'd814fbb15924e', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('166', '0', 'healthaaa', '86f84560e0dce51261205f9cde0950a4', '0', '0', '0', '1179644429', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'allcheap@med.com', '567876', 'http://medbestsellers.ovp.pl', 'USA', 'Cheap pharmacy', '8b320ca4c1', '', '', '', 'Cheap pharmacy', 'Trevel', '97f1c0e125570', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('167', '0', 'Appoine', 'acf8f5e198917fa8e6bba5137261e1b6', '0', '0', '0', '1179650229', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', '2122036@xsecurity.org', '832289200', 'http://kids-bedding.linen-bedding.info/kid-bedding-sale.html', 'US', '', '', '', '', '', 'Watch TV', 'Watch TV', 'f2c12f67c3cd1', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('168', '0', 'ArctDerti', '296d6535c700719c13d07969777ecb8f', '0', '0', '0', '1179655893', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'jertu@mail15.com', '3222567', 'http://clipsbest.info/', 'USA', 'Student', 'c249c75fd3', '', '', '', 'Student', 'criket', 'e6773361298a2', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('169', '0', 'IriKanska', 'cafbe2464ba379347d0818bce7dcfba7', '0', '0', '0', '1179677991', '0', '0', '1.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '1', '1', '1', '0', '1', '0', '0', '', '0', 'IriKanska@gmail.com', '', 'http://bogwankunhokzol.info/15.html', 'Tennessee', '', '', '', '', '', '', '', '979fe6cc7f356', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('170', '0', 'bargengaus', '2f25bcdd8b83c732922f4b720cd6b420', '0', '0', '0', '1179686172', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'bargengaus@ramireschat.com', '3785464', 'http://universityedu.info/alleybaggeteyeballs.html', 'usa', '', '', '', '', '', 'video', 'video', '744ca86bb4e5b', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('171', '0', 'Parisana', 'd866a3326bcab1a6797137206cad712e', '0', '0', '0', '1179732690', '0', '0', '1.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '1', '1', '1', '0', '1', '0', '0', '', '0', 'AtlantaParisN@yahoo.com', '', 'http://guwozotonano.info/79.html', 'Maine', '', '', '', '', '', '', '', '68591fa61affa', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('172', '0', 'sangoering', '42baa6991dee59efb581470f413b0cb6', '0', '0', '0', '1179735888', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'sangoering@mymail-in.net', '845763', '', 'usa', '', '', '', '', '', 'work', 'work', '52c483fa0c5ae', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('173', '0', 'Hellsivin', 'a3e4d3b874439f245fc065a852c2b489', '0', '0', '0', '1179758650', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'renn@mail15.com', '257670878', 'http://freemovieplus.info', 'USA', 'web', '6f36ac68e4', '', '', '', 'web', 'web', '44d1589c46674', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('174', '0', 'nikkiopyue', 'cbb2901c44507574bc81d33a8659b6de', '0', '0', '0', '1179766121', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'fenixxopere@mail.ru', '', '', '', '', '', '', '', '', '', '', '6bda0687efe8b', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('175', '0', 'VadimBoh', 'd866a3326bcab1a6797137206cad712e', '0', '0', '0', '1179790157', '0', '0', '1.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '1', '1', '1', '0', '1', '0', '0', '', '0', 'VadimBohusarov@yahoo.com', '', 'http://pakikico.info/80.html', 'Washington', '', '', '', '', '', '', '', 'adc7dac94f48c', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('176', '0', 'mobusparrcwq', '2ddff7a41702b221334732c049f61e06', '0', '0', '0', '1179819155', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'admin@0ann.info', '489134', 'http://generic-propecia.10susan.info', 'USA', 'music', '978214542f', '', '', '', 'music', 'music', 'a506a9ce00b7b', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('177', '0', 'p0prash', '23577383bd72d015c83365dea8515af0', '0', '0', '0', '1179865264', '0', '0', '1.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '1', '1', '1', '0', '1', '0', '0', '', '0', 'p0prash@yahoo.com', '', 'http://hitvozrurnezpoftid.info/74.html', 'Connecticut', '', '', '', '', '', '', '', 'd332089944a30', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('178', '0', 'Anedsterted', 'b9f29498c7c26f1df7f51ef24253f519', '0', '0', '0', '1179867366', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '1', '1', '1', '1', '1', '1', '0', '0', '0', '0', '', '0', 'Anedsterted@mailstaronline.com', '', '', '', '', '', '', '', '', '', '', 'f30be04979616', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('179', '0', 'ungersalogos', '61272cddd5045e8ac2c5735dd8952845', '0', '0', '0', '1179878786', '0', '0', '1.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '1', '1', '1', '0', '1', '0', '0', '', '0', 'unbersalogos@yahoo.com', '', 'http://kim-possible-sex.info/', 'Rhode Island', '', '', '', '', '', '', '', 'cd25b30d2d8da', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('180', '0', 'lilianna', '61272cddd5045e8ac2c5735dd8952845', '0', '0', '0', '1179926807', '0', '0', '1.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '1', '1', '1', '0', '1', '0', '0', '', '0', 'Lilianna@yahoo.com', '', 'http://behanohizuhu.info/20.html', 'Pennsylvania', '', '', '', '', '', '', '', '2dc017c1ddd2e', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('181', '0', 'dumshark', '64e259e3cc30fc966f819b95b019650e', '0', '0', '0', '1180006752', '0', '0', '1.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '1', '1', '1', '0', '1', '0', '0', '', '0', 'SharkDambuss@yahoo.com', '', 'http://zohuvubewida.info/63.html', 'Oklahoma', '', '', '', '', '', '', '', '611795f55f152', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('182', '0', 'Ipatiplakat', '88a0805966820957de38abf661db106b', '0', '0', '0', '1180023940', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'advert2007@tut.by', '345345', 'http://www.easyfreeforum.com/percocet/', 'USA', 'swing', '4ce5081977', '', '', '', 'swing', 'Many moooooore', '9d7c44244d713', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('183', '0', 'friendofshrek', '3761463c15032e4b2408338b14656c83', '0', '0', '0', '1180051006', '0', '0', '1.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '1', '1', '1', '0', '1', '0', '0', '', '0', 'ShrekFriend@yahoo.com', '', 'http://wuwuparuza.info/98.html', 'Nevada', '', '', '', '', '', '', '', '647e5786091ae', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('184', '0', 'myspace33', '9fe015166b885c0fa38d74aa5f7e18a4', '0', '0', '0', '1180112776', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'dfiudfhjjjak@mit.edu', '895247', 'http://clock-countdown-myspace.blogspot.com/', 'germany', 'circlejerk teen anime', '59b4fce398', '', '', '', 'hung shemale sex141', 'joker about  for a tna to the lungs.', '80a539311c24f', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('185', '0', 'sinderel', '0edc2027d45a257adf7eec78200d2a39', '0', '0', '0', '1180117430', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'sinderel@lvivs.com', '3856840076', 'http://universityedu.info/poppymorganfreeones.html', 'USA', '', '', '', '', '', 'rewq', 'ewqryt', '35500cb0e35de', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('186', '0', 'vavasysh', '8945b4cb1bfb8cb5c95c137fc60ed9a0', '0', '0', '0', '1180117922', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'yoyvasya@mail.ru', '12345432', 'http://rhetcomp.gsu.edu/~revweb/templates_c/ind25.html', 'dsdsd', 'sdsd', '52d00c40d4', '', '', '', 'sdsd', 'dsdsdsd', 'eb3f8e75c0887', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('187', '0', 'selinaporan', 'fbbf0df68a1929f5878b794bbc290f8e', '0', '0', '0', '1180232635', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'estercrenshaw@adwords4u.org', '546531321', 'http://www.pokerforum.kokoom.com', 'USA', 'GOOD LUCK', '248fc3109e', '', '', '', 'INTERNET MARKETING', 'ICQ', '8518cd2c7eaf7', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('188', '0', 'Moneygirl', 'c5fc32eea258063ffbd548ac5cd69411', '0', '0', '0', '1180259787', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'milayaskazka@inbox.ru', '27713245', 'http://playsms.ru/', 'USA', 'Finance', '4d6c48b9e2', '', '', '', 'Finance', 'Money', 'fed655289ad0c', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('189', '0', 'fulaconi', '3761463c15032e4b2408338b14656c83', '0', '0', '0', '1180265736', '0', '0', '1.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '1', '1', '1', '0', '1', '0', '0', '', '0', 'fulaconi_best@yahoo.com', '', 'http://buvtishagbil.info/37.html', 'New York', '', '', '', '', '', '', '', '402f22eda7193', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('190', '0', 'TarenaManovska', '1518a9dccaf6d082b0d6074e5f700463', '0', '0', '0', '1180340679', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'cddvvcvdddww@rupr.org', '384243902', 'http://britney-head-shave.kdiefvr.info', 'Argentina', '', '', 'best', 'best', 'best', 'bigtitpatrol', 'beach wedding', 'cdae24ebd4539', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('191', '0', 'HentBorb', '539222584929a55e93648d7875c78132', '0', '0', '0', '1180348552', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'gfdsa@mail333.com', '2555673', 'http://clipsbest.info/', 'USA', 'Driver', '3de9db33f5', '', '', '', 'Driver', 'golf', '9963addbd3bb0', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('192', '0', 'mobuspergbbowp', '2ddff7a41702b221334732c049f61e06', '0', '0', '0', '1180420629', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', '1@0ann.info', '489134', 'http://0patricia.info', 'USA', 'music', 'b983eac125', '', '', '', 'music', 'music', '0960d086ce96f', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('193', '0', 'WebCamMan', '48a2ebbe59a9639bfc75b8f920991b9c', '0', '0', '0', '1180430610', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'cameramans@gawab.com', '', 'http://www.google.com', 'Swiss', 'Marketing', '19845d1674', '', '', '', 'Marketing', 'Snowboarding', 'd046bffa006d1', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('194', '0', 'nemayka', '057ac20de60b1fdc18ed759aeaf46030', '0', '0', '0', '1180454449', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'nazim-samotoi@mail.ru', '545636212', 'http://www.car-dir.com', 'usa', 'bmw dealer', 'dec0a26ce9', '', '', '', 'bmw dealer', 'music, girls, voyaje', '57abd5564cc6b', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('195', '0', 'WervHosre', 'dc23d695ec42dfa14a842ce54e961206', '0', '0', '0', '1180561850', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'lopok@mail15.com', '567765', 'http://clipsbest.info/', 'USA', 'Student', '3a85bae4ec', '', '', '', 'Student', 'criket', '443603067c32a', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('196', '0', 'Rekartoon', '7ec005b5273988e002ba4d17857bbe32', '0', '0', '0', '1180572859', '0', '0', '-12.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'vwovwvvwvwwo@list.ru', '128290', 'http://basic.maldc.info', 'Ukraine', '', '', 'all', 'all', 'all', 'virgin mary', 'free site template web', 'ae07d8592abc1', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('162', '1', 'Brianne', '68bae29ed29094077dae9b3fd5798e10', '0', '0', '0', '1178571855', '0', '0', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '1', '1', '1', '0', '', '0', 'lil_gerber_baby@yahoo.com', '9689775', '', 'Spokane, WA', 'Brianne', 'cee55b33ec', '', '', '', 'Supervisor Insurance Billing', 'snowmobiling,boating....', 'ec42a9edd8f93', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('165', '0', 'BlondeLolita1982', '3b5770ee87a51c2402c7951c8e87ec93', '0', '0', '0', '1179615881', '0', '0', '1.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '0', '0', '0', '0', '1', '1', '1', '0', '1', '0', '0', '', '0', 'lolitablonde1982@gmail.com', '', 'http://delpuktepluk.info/90.html', 'Ohio', '', '', '', '', '', '', '', '0a983742b3839', NULL);
#
# TABLE: phpbb_vote_desc
#
DROP TABLE IF EXISTS phpbb_vote_desc;
CREATE TABLE phpbb_vote_desc(
	vote_id mediumint(8) unsigned NOT NULL auto_increment,
	topic_id mediumint(8) unsigned NOT NULL,
	vote_text text NOT NULL,
	vote_start int(11) NOT NULL,
	vote_length int(11) NOT NULL, 
	PRIMARY KEY (vote_id), 
	KEY topic_id (topic_id)
);
#
# TABLE: phpbb_vote_results
#
DROP TABLE IF EXISTS phpbb_vote_results;
CREATE TABLE phpbb_vote_results(
	vote_id mediumint(8) unsigned NOT NULL,
	vote_option_id tinyint(4) unsigned NOT NULL,
	vote_option_text varchar(255) NOT NULL,
	vote_result int(11) NOT NULL, 
	KEY vote_option_id (vote_option_id), 
	KEY vote_id (vote_id)
);
#
# TABLE: phpbb_vote_voters
#
DROP TABLE IF EXISTS phpbb_vote_voters;
CREATE TABLE phpbb_vote_voters(
	vote_id mediumint(8) unsigned NOT NULL,
	vote_user_id mediumint(8) NOT NULL,
	vote_user_ip char(8) NOT NULL, 
	KEY vote_id (vote_id), 
	KEY vote_user_id (vote_user_id), 
	KEY vote_user_ip (vote_user_ip)
);
#
# TABLE: phpbb_words
#
DROP TABLE IF EXISTS phpbb_words;
CREATE TABLE phpbb_words(
	word_id mediumint(8) unsigned NOT NULL auto_increment,
	word char(100) NOT NULL,
	replacement char(100) NOT NULL, 
	PRIMARY KEY (word_id)
);
#
# TABLE: phpbb_confirm
#
DROP TABLE IF EXISTS phpbb_confirm;
CREATE TABLE phpbb_confirm(
	confirm_id char(32) NOT NULL,
	session_id char(32) NOT NULL,
	code char(6) NOT NULL, 
	PRIMARY KEY (session_id, confirm_id)
);

#
# Table Data for phpbb_confirm
#

INSERT INTO phpbb_confirm (confirm_id, session_id, code) VALUES('946ef75b7adfa9f9d0f2106333c72b9b', '0645d636e584a6b772ddf2f487c94aae', '2AHWCQ');
#
# TABLE: phpbb_sessions_keys
#
DROP TABLE IF EXISTS phpbb_sessions_keys;
CREATE TABLE phpbb_sessions_keys(
	key_id varchar(32) NOT NULL,
	user_id mediumint(8) NOT NULL,
	last_ip varchar(8) NOT NULL,
	last_login int(11) NOT NULL, 
	PRIMARY KEY (key_id, user_id), 
	KEY last_login (last_login)
);

#
# Table Data for phpbb_sessions_keys
#

INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('e3417ecd6c9369ab7b0382e089213abd', '3', '43828187', '1150301603');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('9a62d9d668dcd7256cf59ceae311ea86', '4', '4711280d', '1156901261');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('734501873d9c29a4785ab9f100d47f86', '3', '43828187', '1150838850');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('656957044e3ff23e9a8d0f11f37128b0', '5', '1805c69a', '1150710562');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('27d879f1b3ebcea8e4ea41ea599b029d', '7', '1896838f', '1153901581');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('d0cbd110fb06306bd074e18de0b8d735', '8', '41bd1bfc', '1151529184');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('48c966457b9ae4fe6d58220ff534042e', '6', '4160fbd7', '1152577833');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('7f404897bced5998232e084b1d9d1386', '9', '18b0d8f7', '1156292391');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('3a51e52f8d3c74630435abe058c6735f', '12', '52b64596', '1155986089');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('3a36aefd8af89e63abbcd8c79e62b9da', '13', '467058cc', '1158005788');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('03fcb3852e3a12ab6394cba88c280b5e', '17', '45e1e60a', '1166467142');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('ed30f9725bfbe0fadb5c4e116f602b16', '4', '4711280d', '1163739696');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('4e19b83ed3c2a6347941f928ba5fc273', '9', '18b0d8f7', '1167003938');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('faea4f1b2455940aad675366c8ea1596', '5', '1805c589', '1159714583');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('274b89547eac41894a19a5c0b09d73e4', '3', '43828187', '1161813527');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('e5940d418db5418b0ca839844f48ec6b', '27', '40e9ac02', '1161007623');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('160ca31979d9dab6604ed7fc510b16a0', '27', '40e9ac02', '1161044527');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('db4021d9328f6645bb2cee17509574ef', '27', '40e9ac02', '1161121940');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('7bbd1813c2f8cd989e5caa9f47eda146', '27', '40e9ac26', '1161308876');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('f9800005c559c88e094f5b48ceb8432d', '27', '40e9ac25', '1161558397');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('ef9707bea94efa0e83a598cd4ee61d18', '30', '44c58d78', '1162144515');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('38c4c6c147e10b886dd6930f71804621', '27', '40e9ac25', '1161655091');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('1b4c4940b43a312cd9dba3de33575ec7', '27', '40e9ac25', '1161660631');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('2264a8e8c12ed8cb3944d8fdcb3ccd19', '27', '40e9ac25', '1162685868');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('ca158fa4f98ea7856570a9873f95029e', '5', '43b41cbe', '1165800326');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('37e37d5cccdbacb5be2838d6f2c9ebb8', '4', '4711280d', '1163967441');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('0912a9d5c4e7bc023eae9d9e79821ba8', '30', '44c58d78', '1164228569');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('858c50b96516b3e9270a3ba63e83e19f', '33', '459417ec', '1164228575');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('23946dc56cced394a1c8a0ac39417fc4', '33', '459417ec', '1164243209');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('da3a665fa2285df4bcd3eae657c4c28f', '4', '4711280d', '1166726295');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('0f838f52d1ced5a741b0de2c3a524084', '4', '4711280d', '1167271380');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('ee9e0cfc25c9b9b3b14b29bef6c2c273', '9', '42d6084c', '1176061788');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('e501ad058f8d37b08e8f0d93c9ae1d4f', '17', '45e1fb90', '1174355741');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('8b6b1e388c82c1037b730b55abc2dbe2', '4', '4711280d', '1167500735');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('3580376889b57a6f0f9bd8fd5834a53d', '4', '4711280d', '1175837716');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('08cc509012fc912f1dce20d81fed52ae', '3', '42d71208', '1169405742');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('8703d61e0ea899e82de42af9b48c7058', '27', '480ec211', '1168829573');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('2c27421cb22954df21f148f46435250e', '30', 'ced21b21', '1168625019');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('14d524d71001474d895451b3a0c8c74d', '13', '181b1056', '1169885725');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('b7b62475d5fb011c1ca2dc25c9385b82', '27', '40e9ac25', '1169591300');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('83e82e649e29018208e7d18e3e9f07b2', '6', '4160fbd7', '1175263679');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('b41da9859d306afcbdf8db4629ac0036', '27', '40e9ac25', '1175305801');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('92cad0d0ea620431658493e5d7f7f04f', '27', '40e9ac25', '1175562033');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('23ddb6ab25c28ba050248b8e27ab4097', '17', '45e9d074', '1176863506');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('99e9dbb7ce9830df57e12b4cb36651f0', '3', '42d68ab1', '1177308477');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('f719d8174bef078986068a9007779e24', '4', '4711280d', '1180412656');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('cba8c69b3699063bf4c02613d107dedd', '27', '42f95506', '1178311226');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('941d9af7b7d7286394afd035ec531567', '3', '42d68ab1', '1180575553');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('21c0e5eabc545ce693296bcfc84cf286', '9', '42d60378', '1180486653');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('c278596e46ec44b0c4d94f8578951dba', '5', '43b41cbe', '1180409794');
