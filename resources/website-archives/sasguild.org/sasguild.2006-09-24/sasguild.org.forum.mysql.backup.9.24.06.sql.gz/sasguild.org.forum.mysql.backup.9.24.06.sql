#
# phpBB Backup Script
# Dump of tables for sasguild_sasForum
#
# DATE : 24-09-2006 22:17:51 GMT
#
#
# TABLE: phpbb_auth_access
#
DROP TABLE IF EXISTS phpbb_auth_access;
CREATE TABLE phpbb_auth_access(
	group_id mediumint(8) NOT NULL,
	forum_id smallint(5) unsigned NOT NULL,
	auth_view tinyint(1) NOT NULL,
	auth_read tinyint(1) NOT NULL,
	auth_post tinyint(1) NOT NULL,
	auth_reply tinyint(1) NOT NULL,
	auth_edit tinyint(1) NOT NULL,
	auth_delete tinyint(1) NOT NULL,
	auth_sticky tinyint(1) NOT NULL,
	auth_announce tinyint(1) NOT NULL,
	auth_vote tinyint(1) NOT NULL,
	auth_pollcreate tinyint(1) NOT NULL,
	auth_attachments tinyint(1) NOT NULL,
	auth_mod tinyint(1) NOT NULL, 
	KEY group_id (group_id), 
	KEY forum_id (forum_id)
);
#
# TABLE: phpbb_banlist
#
DROP TABLE IF EXISTS phpbb_banlist;
CREATE TABLE phpbb_banlist(
	ban_id mediumint(8) unsigned NOT NULL auto_increment,
	ban_userid mediumint(8) NOT NULL,
	ban_ip varchar(8) NOT NULL,
	ban_email varchar(255), 
	PRIMARY KEY (ban_id), 
	KEY ban_ip_user_id (ban_ip, ban_userid)
);

#
# Table Data for phpbb_banlist
#

INSERT INTO phpbb_banlist (ban_id, ban_userid, ban_ip, ban_email) VALUES('10', '0', '40142258', NULL);
INSERT INTO phpbb_banlist (ban_id, ban_userid, ban_ip, ban_email) VALUES('4', '0', 'ca650655', NULL);
INSERT INTO phpbb_banlist (ban_id, ban_userid, ban_ip, ban_email) VALUES('8', '0', 'cb710dff', NULL);
INSERT INTO phpbb_banlist (ban_id, ban_userid, ban_ip, ban_email) VALUES('6', '0', '403269e3', NULL);
INSERT INTO phpbb_banlist (ban_id, ban_userid, ban_ip, ban_email) VALUES('9', '0', '4833260d', NULL);
INSERT INTO phpbb_banlist (ban_id, ban_userid, ban_ip, ban_email) VALUES('11', '0', '4350b135', NULL);
#
# TABLE: phpbb_categories
#
DROP TABLE IF EXISTS phpbb_categories;
CREATE TABLE phpbb_categories(
	cat_id mediumint(8) unsigned NOT NULL auto_increment,
	cat_title varchar(100),
	cat_order mediumint(8) unsigned NOT NULL, 
	PRIMARY KEY (cat_id), 
	KEY cat_order (cat_order)
);

#
# Table Data for phpbb_categories
#

INSERT INTO phpbb_categories (cat_id, cat_title, cat_order) VALUES('3', 'Sinners Among Saints', '10');
#
# TABLE: phpbb_config
#
DROP TABLE IF EXISTS phpbb_config;
CREATE TABLE phpbb_config(
	config_name varchar(255) NOT NULL,
	config_value varchar(255) NOT NULL, 
	PRIMARY KEY (config_name)
);

#
# Table Data for phpbb_config
#

INSERT INTO phpbb_config (config_name, config_value) VALUES('config_id', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('board_disable', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('sitename', 'The Sinners Among Saints');
INSERT INTO phpbb_config (config_name, config_value) VALUES('site_desc', 'SAS Forums');
INSERT INTO phpbb_config (config_name, config_value) VALUES('cookie_name', 'phpbb2mysql');
INSERT INTO phpbb_config (config_name, config_value) VALUES('cookie_path', '/');
INSERT INTO phpbb_config (config_name, config_value) VALUES('cookie_domain', '');
INSERT INTO phpbb_config (config_name, config_value) VALUES('cookie_secure', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('session_length', '3600');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_html', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_html_tags', 'b,i,u,pre');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_bbcode', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_smilies', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_sig', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_namechange', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_theme_create', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_avatar_local', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_avatar_remote', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_avatar_upload', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('enable_confirm', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('allow_autologin', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('max_autologin_time', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('override_user_style', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('posts_per_page', '15');
INSERT INTO phpbb_config (config_name, config_value) VALUES('topics_per_page', '50');
INSERT INTO phpbb_config (config_name, config_value) VALUES('hot_threshold', '25');
INSERT INTO phpbb_config (config_name, config_value) VALUES('max_poll_options', '10');
INSERT INTO phpbb_config (config_name, config_value) VALUES('max_sig_chars', '255');
INSERT INTO phpbb_config (config_name, config_value) VALUES('max_inbox_privmsgs', '50');
INSERT INTO phpbb_config (config_name, config_value) VALUES('max_sentbox_privmsgs', '25');
INSERT INTO phpbb_config (config_name, config_value) VALUES('max_savebox_privmsgs', '50');
INSERT INTO phpbb_config (config_name, config_value) VALUES('board_email_sig', 'Thanks, The Management');
INSERT INTO phpbb_config (config_name, config_value) VALUES('board_email', 'tgzalonis@hotmail.com');
INSERT INTO phpbb_config (config_name, config_value) VALUES('smtp_delivery', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('smtp_host', '');
INSERT INTO phpbb_config (config_name, config_value) VALUES('smtp_username', '');
INSERT INTO phpbb_config (config_name, config_value) VALUES('smtp_password', '');
INSERT INTO phpbb_config (config_name, config_value) VALUES('sendmail_fix', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('require_activation', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('flood_interval', '15');
INSERT INTO phpbb_config (config_name, config_value) VALUES('search_flood_interval', '15');
INSERT INTO phpbb_config (config_name, config_value) VALUES('search_min_chars', '3');
INSERT INTO phpbb_config (config_name, config_value) VALUES('max_login_attempts', '3');
INSERT INTO phpbb_config (config_name, config_value) VALUES('login_reset_time', '30');
INSERT INTO phpbb_config (config_name, config_value) VALUES('board_email_form', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('avatar_filesize', '6144');
INSERT INTO phpbb_config (config_name, config_value) VALUES('avatar_max_width', '80');
INSERT INTO phpbb_config (config_name, config_value) VALUES('avatar_max_height', '80');
INSERT INTO phpbb_config (config_name, config_value) VALUES('avatar_path', 'images/avatars');
INSERT INTO phpbb_config (config_name, config_value) VALUES('avatar_gallery_path', 'images/avatars/gallery');
INSERT INTO phpbb_config (config_name, config_value) VALUES('smilies_path', 'images/smiles');
INSERT INTO phpbb_config (config_name, config_value) VALUES('default_style', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('default_dateformat', 'D M d, Y g:i a');
INSERT INTO phpbb_config (config_name, config_value) VALUES('board_timezone', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('prune_enable', '1');
INSERT INTO phpbb_config (config_name, config_value) VALUES('privmsg_disable', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('gzip_compress', '0');
INSERT INTO phpbb_config (config_name, config_value) VALUES('coppa_fax', '');
INSERT INTO phpbb_config (config_name, config_value) VALUES('coppa_mail', '');
INSERT INTO phpbb_config (config_name, config_value) VALUES('record_online_users', '3');
INSERT INTO phpbb_config (config_name, config_value) VALUES('record_online_date', '1158385723');
INSERT INTO phpbb_config (config_name, config_value) VALUES('server_name', 'www.sasguild.org');
INSERT INTO phpbb_config (config_name, config_value) VALUES('server_port', '80');
INSERT INTO phpbb_config (config_name, config_value) VALUES('script_path', '/forum/');
INSERT INTO phpbb_config (config_name, config_value) VALUES('version', '.0.21');
INSERT INTO phpbb_config (config_name, config_value) VALUES('rand_seed', 'a79f9ff22a040de7bd4edc1348cd8142');
INSERT INTO phpbb_config (config_name, config_value) VALUES('board_startdate', '1150289148');
INSERT INTO phpbb_config (config_name, config_value) VALUES('default_lang', 'english');
#
# TABLE: phpbb_disallow
#
DROP TABLE IF EXISTS phpbb_disallow;
CREATE TABLE phpbb_disallow(
	disallow_id mediumint(8) unsigned NOT NULL auto_increment,
	disallow_username varchar(25) NOT NULL, 
	PRIMARY KEY (disallow_id)
);

#
# Table Data for phpbb_disallow
#

INSERT INTO phpbb_disallow (disallow_id, disallow_username) VALUES('1', '*poor*');
#
# TABLE: phpbb_forums
#
DROP TABLE IF EXISTS phpbb_forums;
CREATE TABLE phpbb_forums(
	forum_id smallint(5) unsigned NOT NULL,
	cat_id mediumint(8) unsigned NOT NULL,
	forum_name varchar(150),
	forum_desc text,
	forum_status tinyint(4) NOT NULL,
	forum_order mediumint(8) unsigned DEFAULT '1' NOT NULL,
	forum_posts mediumint(8) unsigned NOT NULL,
	forum_topics mediumint(8) unsigned NOT NULL,
	forum_last_post_id mediumint(8) unsigned NOT NULL,
	prune_next int(11),
	prune_enable tinyint(1) NOT NULL,
	auth_view tinyint(2) NOT NULL,
	auth_read tinyint(2) NOT NULL,
	auth_post tinyint(2) NOT NULL,
	auth_reply tinyint(2) NOT NULL,
	auth_edit tinyint(2) NOT NULL,
	auth_delete tinyint(2) NOT NULL,
	auth_sticky tinyint(2) NOT NULL,
	auth_announce tinyint(2) NOT NULL,
	auth_vote tinyint(2) NOT NULL,
	auth_pollcreate tinyint(2) NOT NULL,
	auth_attachments tinyint(2) NOT NULL, 
	PRIMARY KEY (forum_id), 
	KEY forums_order (forum_order), 
	KEY cat_id (cat_id), 
	KEY forum_last_post_id (forum_last_post_id)
);

#
# Table Data for phpbb_forums
#

INSERT INTO phpbb_forums (forum_id, cat_id, forum_name, forum_desc, forum_status, forum_order, forum_posts, forum_topics, forum_last_post_id, prune_next, prune_enable, auth_view, auth_read, auth_post, auth_reply, auth_edit, auth_delete, auth_sticky, auth_announce, auth_vote, auth_pollcreate, auth_attachments) VALUES('1', '3', 'General Discussion', 'No specific topic.', '0', '10', '66', '13', '77', NULL, '0', '0', '0', '1', '1', '1', '1', '3', '3', '1', '1', '0');
#
# TABLE: phpbb_forum_prune
#
DROP TABLE IF EXISTS phpbb_forum_prune;
CREATE TABLE phpbb_forum_prune(
	prune_id mediumint(8) unsigned NOT NULL auto_increment,
	forum_id smallint(5) unsigned NOT NULL,
	prune_days smallint(5) unsigned NOT NULL,
	prune_freq smallint(5) unsigned NOT NULL, 
	PRIMARY KEY (prune_id), 
	KEY forum_id (forum_id)
);
#
# TABLE: phpbb_groups
#
DROP TABLE IF EXISTS phpbb_groups;
CREATE TABLE phpbb_groups(
	group_id mediumint(8) NOT NULL auto_increment,
	group_type tinyint(4) DEFAULT '1' NOT NULL,
	group_name varchar(40) NOT NULL,
	group_description varchar(255) NOT NULL,
	group_moderator mediumint(8) NOT NULL,
	group_single_user tinyint(1) DEFAULT '1' NOT NULL, 
	PRIMARY KEY (group_id), 
	KEY group_single_user (group_single_user)
);

#
# Table Data for phpbb_groups
#

INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('1', '1', 'Anonymous', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('2', '1', 'Admin', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('3', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('4', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('5', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('6', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('7', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('8', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('9', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('10', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('11', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('12', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('14', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('18', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('30', '1', '', 'Personal User', '0', '1');
INSERT INTO phpbb_groups (group_id, group_type, group_name, group_description, group_moderator, group_single_user) VALUES('28', '1', '', 'Personal User', '0', '1');
#
# TABLE: phpbb_posts
#
DROP TABLE IF EXISTS phpbb_posts;
CREATE TABLE phpbb_posts(
	post_id mediumint(8) unsigned NOT NULL auto_increment,
	topic_id mediumint(8) unsigned NOT NULL,
	forum_id smallint(5) unsigned NOT NULL,
	poster_id mediumint(8) NOT NULL,
	post_time int(11) NOT NULL,
	poster_ip varchar(8) NOT NULL,
	post_username varchar(25),
	enable_bbcode tinyint(1) DEFAULT '1' NOT NULL,
	enable_html tinyint(1) NOT NULL,
	enable_smilies tinyint(1) DEFAULT '1' NOT NULL,
	enable_sig tinyint(1) DEFAULT '1' NOT NULL,
	post_edit_time int(11),
	post_edit_count smallint(5) unsigned NOT NULL, 
	PRIMARY KEY (post_id), 
	KEY forum_id (forum_id), 
	KEY topic_id (topic_id), 
	KEY poster_id (poster_id), 
	KEY post_time (post_time)
);

#
# Table Data for phpbb_posts
#

INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('2', '2', '1', '3', '1150301613', '43828187', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('3', '2', '1', '4', '1150401161', '8ea5ab5a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('4', '2', '1', '2', '1150406623', '47e2a70c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('5', '2', '1', '3', '1150408438', '43828187', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('6', '3', '1', '5', '1150476746', '1805c69a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('7', '4', '1', '6', '1150476862', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('8', '4', '1', '2', '1150477589', '47e2a70c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('9', '4', '1', '4', '1150494119', '8ea5ab5a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('10', '4', '1', '5', '1150494617', '1805c69a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('11', '5', '1', '5', '1151172279', '1805c69a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('46', '13', '1', '6', '1157066213', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('13', '5', '1', '7', '1151275517', '1896838f', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('14', '7', '1', '7', '1151275550', '1896838f', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('15', '7', '1', '2', '1151285348', '47e2a70c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('16', '5', '1', '2', '1151293798', '47e2a70c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('17', '5', '1', '6', '1151340514', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('18', '8', '1', '8', '1151495189', '41bd1bfc', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('19', '8', '1', '4', '1151533842', '8ea5ab5a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('20', '5', '1', '5', '1151781036', '1805c69a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('21', '7', '1', '5', '1151781068', '1805c69a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('22', '7', '1', '6', '1151788854', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('23', '7', '1', '2', '1151817851', '47e2a70c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('24', '5', '1', '2', '1151851958', '47e2a70c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('25', '7', '1', '6', '1151881638', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('26', '7', '1', '4', '1152493660', '8ea5ab5a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('27', '5', '1', '5', '1152552936', '1805c69a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('28', '9', '1', '6', '1152577884', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('29', '9', '1', '2', '1152760394', '47e2a70c', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('30', '9', '1', '6', '1153313985', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('31', '9', '1', '6', '1153314030', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('32', '10', '1', '5', '1153784519', '1805c69a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('33', '11', '1', '10', '1154580826', '18b43164', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('34', '12', '1', '11', '1154906773', '467d1013', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('35', '12', '1', '9', '1154939861', '18b0d8f7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('36', '12', '1', '4', '1154986519', '8ea5ab5a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('37', '13', '1', '6', '1154999729', '4160fbd7', '', '1', '0', '1', '0', '1156128243', '1');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('38', '12', '1', '6', '1154999836', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('39', '13', '1', '12', '1155777694', '52b64596', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('40', '13', '1', '6', '1155859426', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('41', '13', '1', '4', '1155946870', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('42', '13', '1', '12', '1155954418', '52b64596', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('43', '13', '1', '6', '1156128204', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('44', '13', '1', '4', '1156477520', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('47', '13', '1', '13', '1157159381', '467058cc', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('48', '13', '1', '6', '1157382371', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('50', '16', '1', '17', '1157834949', '45e1f397', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('51', '16', '1', '3', '1157878016', '43828187', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('52', '16', '1', '17', '1157933513', '45e1f397', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('53', '16', '1', '4', '1158017739', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('57', '16', '1', '17', '1158611443', '447fe574', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('58', '16', '1', '4', '1158619901', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('64', '13', '1', '23', '1158784707', '476d7c91', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('60', '16', '1', '9', '1158730162', '18b0d8f7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('61', '13', '1', '9', '1158730211', '18b0d8f7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('65', '13', '1', '5', '1158797803', '1805c589', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('63', '13', '1', '6', '1158764420', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('66', '13', '1', '9', '1158820847', '18b0d8f7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('67', '13', '1', '6', '1158858585', '4160fbd7', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('68', '13', '1', '4', '1158968035', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('69', '10', '1', '5', '1158976675', '1805c589', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('70', '22', '1', '24', '1158978116', '42d7a5b2', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('71', '16', '1', '17', '1158979182', '447fe574', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('73', '13', '1', '13', '1158999789', '181b117a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('74', '16', '1', '13', '1159000193', '181b117a', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('75', '16', '1', '4', '1159031758', '4711280d', '', '1', '0', '1', '0', NULL, '0');
INSERT INTO phpbb_posts (post_id, topic_id, forum_id, poster_id, post_time, poster_ip, post_username, enable_bbcode, enable_html, enable_smilies, enable_sig, post_edit_time, post_edit_count) VALUES('77', '22', '1', '23', '1159129379', '476d7c91', '', '1', '0', '1', '0', NULL, '0');
#
# TABLE: phpbb_posts_text
#
DROP TABLE IF EXISTS phpbb_posts_text;
CREATE TABLE phpbb_posts_text(
	post_id mediumint(8) unsigned NOT NULL,
	bbcode_uid varchar(10) NOT NULL,
	post_subject varchar(60),
	post_text text, 
	PRIMARY KEY (post_id)
);

#
# Table Data for phpbb_posts_text
#

INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('2', 'c0e80b3005', 'Moo', 'First.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('3', 'b2823c3877', '', 'Ahoy hoy.

You still play UO?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('4', 'f63e68fa23', '', 'UO? Oh, god.. Please say you don\'t Garen... it better not be an OSI server.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('5', '5eb2a8d6ae', '', 'I still have the Arion III account. Everyone is gone, I stopped playing just before the ML expansion. I have recently started to log on and look around at things.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('6', '12926aee22', 'Boom boom boom boom', 'i\'mma shoot ya right down!
___
DANCE DANCE DANCE DANCE TO THE RADIO.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('7', '7afceb4c43', 'asdasf', 'asfasf');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('8', 'a197058a71', '', 'I agree fully. nod.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('9', 'd62bed8331', '', 'fds fdsa sa dsaf?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('10', '863d1ed171', '', 'WHAT ARE YOU? SOME FUCKING KIDS?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('11', '4c2a920829', 'activity', 'Forum master!
-can we get a private forum where anyone of us whom registers a new account is within a 24hour period addmitted to the privvy place?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('46', '8e4cd5bf01', '', 'the best poart is the next few days i was completely embarassed that i even fooled around with her im glad that all that happend was  i touched her tits n she rubbed my dick thru the pants!

but then she goes n does somethin like this son the fuck');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('13', '5a862bf754', '', 'i agree.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('14', '026620e571', 'WoW', 'I\'m buying WoW time in the next couple of days since my exam\'s have finished. What server are you guys in?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('15', '25f6c64bbc', '', 'I didn\'t know Jews were allowed to play WoW. Hrm, learn something everyday! =]');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('16', '6d109390ae', '', 'You want what?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('17', '15aa6c9642', '', 'naked pics of rostrax');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('18', '3a61ed61cd', '.', '6ED2B79E3ACE9EFFC3B2972CC785A462');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('19', 'f46c2e5945', '', 'While you make a very valid arguement, I will have to disagree.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('20', 'b069582afe', '', 'a fookin private forum.  you know people read our thoughts... our ideas about.. globalization and religious domination.

NIGGA!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('21', 'b5ea9ac6bf', '', ':arrow:');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('22', 'b14779e262', '', 'bloodscalp alliance

msg treca or lakkin or mojen in game

treca = rostrax with 2 pigtails and a cute butt');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('23', 'fd38d37a4d', '', 'Cute butt?

It\'s a Gnome!  Do you think all 10 year olds have cute butts');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('24', '19599f9927', '', 'Why have a private forum? ..I mean, who the hell is going to read this? heh..');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('25', 'ff93f7d489', '', 'some i saw this 14 year old on myspace that made me cream myself omg her fucking tits were so voluptoous');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('26', 'ee8d83c31c', '', 'Link?

One time we were talking about how hot this one chick is we used to party with, and one of my buddies goes &quot;Ya ... she has an ass like a 10 year old boy.&quot;


Not really sure wtf he meant by that ... but we laughed.

So yes, some people do think 10 year old boys have nice bums.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('27', '65518edc3c', '', 'mother should i trust the government?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('28', '2df297d69f', 'WOW: Burning Crusade. Archimonde?', 'So whats up guys I was told to play wow on archimonde and that everyone will be reactivating! fuck yeah! letes play. why archimonde and not a new server like altar of storms? lets discuss!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('29', '33723f3a95', '', 'I think it would be a good idea to keep everyone on the same server. 

It would have been like us switching servers everytime we quit UO. How willing do you think people would have been to come back if they had to start over everytime? =) My point however is that if everyone sticks to one server then I think people will be more likely to not only play there too, but stay there as well.

This is why I never came to play with you guys. I didn\'t want to play for a
month or two and have you guys quit and change servers. (as was done several times heh)

-Aries');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('30', '6e867fa37a', '', 'Yeah me ros corn pops and 2 rl friends of mine already have 60s on bloodscalp and i actually play daily and have for a long time.


I dont know where everyone else is

send lakkin a tell ingame');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('31', 'c0de3a6159', '', 'the only other server id consider is altar of storms with everyone that server is hoppin me and endo got horde chars there');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('32', 'cef229d29d', 'Donovan', 'if you come across this post brian,sean, john smith whatever.  Drop me an email dev.null@cox.net i live up in the bay now.
-philip');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('33', '014aea9fee', 'DarkFall', 'www.Darkfallonline.com uo and beyond check it');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('34', '0d41b52f40', 'Memories....', '[img:0d41b52f40]http://deniedproject.net/images/wowmem.JPG[/img:0d41b52f40]

[url]http://deniedproject.net/images/wowmem.JPG[/url]');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('35', 'f25e099d04', 'wow...', 'And I thought WoW was gay before I saw what it looked like...');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('36', '3409806853', '', 'If we didnt switch shards every 10 days we\'d all probaby still be playing WoW.

IF you all sign a contract to stay on the same WoW server for over a year I will come play there :P');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('37', '1742718593', 'Wow this is completely fucked read guys.', 'Umm yeah me and laura broke up for like 2 weeks and i fooled around with this girl we didnt have sex nothing i touched her tits and she rubbed my dick i didnt even ejaculate cuz i freaked out and was like i still love laura blehblehbleh long story short

2 weeks later i get picked up by the cops on 2nd degree rape charges with a statement saying that i &quot;forced her to give me oral sex&quot;


THE FUCK NIGGA


got me damn good lawyer and hopefully ill be acquitted
theres 0 evidence in the case and its just this stupid bitch making an allegation.

After I win I\'m suing the shit out of her.

If not my home phone # is 508-771-6097 and ask my madukes where they got me at if u wanna get in touch with me fucking christ guys and me and laura got back together and i fucking proposed to her and then this shit happens.


Preliminary hearing is set for Aug 28th 8:30am

hopefully they dont Indict me and realize that this is abullshit case by some fucking psychotic bitch.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('38', '0854fbf224', '', 'if i wasn\'t facing 6-10 years for a crime i didn\'t commit i\'d still be on bloodscalp

instead im spendin time with my friends n family who are payin for my defense attorney');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('39', '5b14d631ae', '', 'Man, thats just so wrong Lakk.
Wish you luck!

Geno (Genosis)...');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('40', '34e441523a', '', 'SUP GENO hell yeah long time no see. Yeah the whole situation is fucked im lookin to serve a couple years in jail for somethin that neverh append but i got a fucking awesome defense attorney one of bostons top lawyers. My family shelled otu a hella amount of cash plus he gave us a discount cuz hes defended other familiy members of mine thruout the years. my grandmother on a suit after a scandal in the massachusetts dss and some shit tied into whitey bulgers shit i dont even know all the details i just kno someone tried framin my gma with soem shit and fired her and when my uncle got popped for flyin a plane from panama to kentucky with 410 keys of coke,, my uncle got 3 years instead of life cuz he managed to like surpress a buncha evidence and not link him to shit or something again im not even sure of the details..

worst comes to worst and the case looks bad im lookin to do like maybe a year in county and in even a worse situation im look at a max of like 3-5 maybe less. whatever life goeson kid this bitchis fucking crazy... worst part of all of this is im fucking engaged.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('41', '0dc4bfaf19', '', 'You are a hard ass thug.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('42', '2b44973f21', '', 'Been kinda hooked on WoW thanks to my brother, played a regular server for quite awhile..
Getting kinda semi bored with that right now thou');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('43', 'c2251375e3', '', 'not at all im fuckin pussy');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('44', '9d22c92bf0', '', 'I was just fucking with you bro, I hope all that shit clears up for you, woman can be quite the headache I think every guy will attest to that.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('47', 'a54b6e86f3', '', 'whats the moral of this story?

More games. less tits.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('48', '209c1c7014', '', '3 years atleast before eligilbilty for parole atleast from what i\'ve read and in that case id have to admit to something i never did... fuck it


i want a lie detector test but i read a buncha shitabout how evenppl tellin the truth fail em if they are anxious n shit');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('50', '451b0fad22', 'SAS, WoW what server?', 'So I am playing on WSG battlegrounds on WoW and this guy from frostmourne server has &lt;Sinners Among Saints&gt; tag I flip fucking out and whisper him like a 17 year old girl and a brand new cell phone.  I ask him some questions to see if he is old school or just wanna be.  He didn\'t know what UO Sonoma was so I assume he is just from WoW or ignorant of SAS History or just coincedence.

Oh yeah and hey.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('51', 'ad2185b01b', '', 'Dav shut up and come back to Sonoma.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('52', '7d58c43771', '', 'dude the new graphics of UO look acctually alright man

too bad no one plays anymore

except you Garen. lol');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('53', 'ded0081f57', '', 'I think that a few of them are playing WoW still ... as for server, well that changes every week.

Good to see you locke, good to know the only other member of FP is still alive :D');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('57', 'e0bf16e082', '', 'Dyn Mega is dead?

Dun of Rhuarc plays WoW on Blackrock with me.

Wasnt he one of your boys?

-Davin');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('58', '40ff28a7f6', '', 'Actually I think Dun was also an honorary FP member, Dyn really liked him.

No Dyn is still alive I just meant besides us :p  Blackrock eh? You guys still playing there?  It seems a lot of people from UO are playing WOW, I know a lot of the old M guys are, along with some of the OGD clownzors and BLD.

All on seperate servers though, way to many servers in that game.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('64', '6f5c19d9de', '', 'haha what....? oh wow... crrrazzyy bitch.

Lakkin you\'re a trip bro.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('65', '2256e95b1c', 'Hey', 'Jason!  What up!
miss you much,
Philip!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('66', '38b2d70696', '', 'Lakkin, get a good lawyer.

At the very least you shouldn\'t really get charged with rape, you should be able to get off fairly easily but eh  good luck and don\'t stress too much');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('67', '3919876663', '', 'its an obvious fucking lie

who the hell in their right mind says

&quot;no i dont care about you saying no&quot;

or &quot;i dont care&quot;
he said he didn\'t care

what the fuck?!@!?!?@!?@!? yo who the fuck would put themselvse in a position like that she makes me sound like the fuckin boston strangler');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('60', '081cc955f5', '', 'Hi Davin!');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('61', 'fdd5f55c28', '', '[quote:fdd5f55c28=\"Dakkon\"]whats the moral of this story?

More games. less tits.[/quote:fdd5f55c28]

Well said... kind of... i mean... tits are nice too...

PS fuck you dakk =)');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('68', 'aa53521776', '', 'If I was you i\'d just start having sex with men because you don\'t seem to have good luck with women.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('69', '4c09440802', '', 'fukin bitch, call me.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('70', '3d20a03e4f', 'Rad is a little bitch.', 'what?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('71', '63282a390f', '', 'Hey DC

Yeah the core of the guild on blackrock is UO sonoma guys.  Pretty much we have hit a brick wall and are waiting for the expansion.');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('63', 'f862325f8f', 'dude read this bullshit', 'Entire Statement Written on 12-18-06
	I WAS GOING OVER MY FRIEND PAT\'S HOUSE SOMETIME AFTER 1AM ON THURSDAY GOING INTO FRIDAY. WE WERE UPSTAIRS HANGING OUT WITH HIS TWO BROTHRES HIS TWO BROTHERS WERE FALLING ASLEEP ON THECOUCH IN HIS LIVING ROOM. SO WE DECIDED TO GO DOWNSTAIRS TO HIS ROOM IN THE BASEMENT. WE WERE SITTING NEXT TO EACH OTHER ON THE COUCHI N HIS ROOM. I WAS NOT MAKING ANY PHYSICAL CONTACT WITH HIM WHATSOEVER HE STARTED TO PULL DOWN THE TOP PART OF MY TANK TOP.I WAS JUST SITTING THERE. THEN HE STARTS TO TALKA BOUT HOWBIG HIS PENIS IS. HE TAKE MY HAND AND PUTS IT ON HIS CROTCH. MY HANDWERE AT MY SIDE WHEN HE UNZIPPED HIS PANTS. THEN HE STARTS TO FEEL ME UP AGAIN. THATS WHEN I SAID NO I DONT WANT TO DO ANYTHING HE SAID THAT HE DIDNT CARE. HE GRABBED THE TOP OF MY HAIR AND PULLEDM E REALLY HARD TO HIS PENIS AND FORCED MY MOUTH ON IT. WHEN I PULLED MYSELF AWAY I SAID NO I DONT WANT TO DO THIS I KNOW I SAID NO MORE THAN TWICE AFTER TAHT HAPPEND HE GRABBED ME BY MY HAIR EVEN HARDER AND FORCED MY MOUTH ON HIS PEINS AGAIN THEN H E SAID I DONT CARE ABOUT ME SAYING NO. I WAS PUSHING AWAY FROM HIM AND TRYING TOG ET HIM TO STOP. THATS WHENI THOUGHT HE WAS GOING TO KEEP RAPING ME SO ISTARTED TO CRY. HE STOPPED WHEN I STARTED TO CRY HE SAID SORRY AND HE THOUGHT I WAS SENDING THE WRONG SIGNALS TO HIM. THEN I SAID I DONT LIKE HIM LIKE THAT AFTER WE TALKED HE WAS STILL MAKING PHYSICAL CONTACT. I THINK HE WAS RUBBING MY BACK OR MY ARM THEN I LEFT HIS HOUSE A LITTLE BIT AFTER 2AM THE NEXT DAY MY CAR RAN OUT OF GAS ON THE TO WORK I COULDNT WALK TO WORK BECAUSE I WAS SO ACHY FROM PAT WHEN I FINALLY GOT THERE THE MANAGER OPF THE STORE SUSPENDED ME. THIS WHOLE EXPERIENCE AS EFFECTED MY JOB AND MY LIFE. NOW IM TRY TO PUT MY LIFE BACK TOGETHER AGAIN



what the fuck? does this make sense to anyone thats what this cihc wrote.

who the hells ays &quot;i dont care about you saying no&quot; lol??? i hope someone with half a brain is prosecuting this case and can just see thru the bullshit');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('73', '6100856ed6', '', 'NO F-U MAN!!@!@!~~

Anywho Lakkin rape is hard to prove, for you and her.  Get a damn good lawyer and make her fuck up IN COURT, dont fucking say a word to her dumb ass unless it is in front of 12 honest men :P');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('74', 'e076c34548', '', 'hey mother fuckers

Me and Mut were FP too, ask Dyn bitches');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('75', '43f7f2ebce', '', 'Thats true, and so was Palou.

Damn ... ok I guess there was a few more than I thought, we whored that guild out like Dyns asshole at a star trek convention ...

I\'ve been considering giveing wow try # 1232423112321323123121121231.

Jus wish it didn\'t take so much damn time to level is all ...  you guys horde or alliance?');
INSERT INTO phpbb_posts_text (post_id, bbcode_uid, post_subject, post_text) VALUES('77', 'ec7be0f42f', '', 'Now that\'s just mean.

 :D');
#
# TABLE: phpbb_privmsgs
#
DROP TABLE IF EXISTS phpbb_privmsgs;
CREATE TABLE phpbb_privmsgs(
	privmsgs_id mediumint(8) unsigned NOT NULL auto_increment,
	privmsgs_type tinyint(4) NOT NULL,
	privmsgs_subject varchar(255) NOT NULL,
	privmsgs_from_userid mediumint(8) NOT NULL,
	privmsgs_to_userid mediumint(8) NOT NULL,
	privmsgs_date int(11) NOT NULL,
	privmsgs_ip varchar(8) NOT NULL,
	privmsgs_enable_bbcode tinyint(1) DEFAULT '1' NOT NULL,
	privmsgs_enable_html tinyint(1) NOT NULL,
	privmsgs_enable_smilies tinyint(1) DEFAULT '1' NOT NULL,
	privmsgs_attach_sig tinyint(1) DEFAULT '1' NOT NULL, 
	PRIMARY KEY (privmsgs_id), 
	KEY privmsgs_from_userid (privmsgs_from_userid), 
	KEY privmsgs_to_userid (privmsgs_to_userid)
);
#
# TABLE: phpbb_privmsgs_text
#
DROP TABLE IF EXISTS phpbb_privmsgs_text;
CREATE TABLE phpbb_privmsgs_text(
	privmsgs_text_id mediumint(8) unsigned NOT NULL,
	privmsgs_bbcode_uid varchar(10) NOT NULL,
	privmsgs_text text, 
	PRIMARY KEY (privmsgs_text_id)
);
#
# TABLE: phpbb_ranks
#
DROP TABLE IF EXISTS phpbb_ranks;
CREATE TABLE phpbb_ranks(
	rank_id smallint(5) unsigned NOT NULL auto_increment,
	rank_title varchar(50) NOT NULL,
	rank_min mediumint(8) NOT NULL,
	rank_special tinyint(1),
	rank_image varchar(255), 
	PRIMARY KEY (rank_id)
);

#
# Table Data for phpbb_ranks
#

INSERT INTO phpbb_ranks (rank_id, rank_title, rank_min, rank_special, rank_image) VALUES('1', 'Site Admin', '-1', '1', NULL);
#
# TABLE: phpbb_search_results
#
DROP TABLE IF EXISTS phpbb_search_results;
CREATE TABLE phpbb_search_results(
	search_id int(11) unsigned NOT NULL,
	session_id varchar(32) NOT NULL,
	search_time int(11) NOT NULL,
	search_array text NOT NULL, 
	PRIMARY KEY (search_id), 
	KEY session_id (session_id)
);

#
# Table Data for phpbb_search_results
#

INSERT INTO phpbb_search_results (search_id, session_id, search_time, search_array) VALUES('1643995590', 'dea502a849e3229189a66a442d28ad19', '1159004748', 'a:7:{s:14:\"search_results\";s:13:\"3, 11, 22, 23\";s:17:\"total_match_count\";i:4;s:12:\"split_search\";N;s:7:\"sort_by\";i:0;s:8:\"sort_dir\";s:4:\"DESC\";s:12:\"show_results\";s:6:\"topics\";s:12:\"return_chars\";i:200;}');
#
# TABLE: phpbb_search_wordlist
#
DROP TABLE IF EXISTS phpbb_search_wordlist;
CREATE TABLE phpbb_search_wordlist(
	word_text varchar(50) NOT NULL,
	word_id mediumint(8) unsigned NOT NULL auto_increment,
	word_common tinyint(1) unsigned NOT NULL, 
	PRIMARY KEY (word_text), 
	KEY word_id (word_id)
);

#
# Table Data for phpbb_search_wordlist
#

INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('account', '23', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('server', '22', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('phpbb', '3', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('osi', '21', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('god', '20', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('garen', '19', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('still', '18', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('play', '17', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hoy', '16', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ahoy', '15', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('moo', '14', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('first', '13', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('arion', '24', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('expansion', '25', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('iii', '26', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('log', '27', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('playing', '28', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('recently', '29', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('started', '30', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stopped', '31', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('things', '32', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('boom', '33', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dance', '34', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('imma', '35', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('radio', '36', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('right', '37', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shoot', '38', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('asdasf', '39', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('asfasf', '40', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('agree', '41', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fully', '42', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nod', '43', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dsaf', '44', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fds', '45', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fdsa', '46', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fucking', '47', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kids', '48', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('24hour', '49', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('activity', '50', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('addmitted', '51', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('anyone', '52', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('forum', '53', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('master', '54', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('period', '55', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('place', '56', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('private', '57', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('privvy', '58', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('registers', '59', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('us', '60', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('few', '484', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('embarassed', '483', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('buying', '63', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('couple', '64', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('exams', '65', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('finished', '66', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('guys', '67', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('next', '68', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('since', '69', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wow', '70', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('allowed', '71', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('everyday', '72', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hrm', '73', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jews', '74', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('learn', '75', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('naked', '76', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pics', '77', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rostrax', '78', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('arguement', '79', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('disagree', '80', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('make', '81', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('valid', '82', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('while', '83', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('domination', '84', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fookin', '85', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('globalization', '86', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ideas', '87', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nigga', '88', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('people', '89', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('read', '90', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('religious', '91', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thoughts', '92', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('arrow', '93', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('alliance', '94', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bloodscalp', '95', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('butt', '96', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cute', '97', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('game', '98', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lakkin', '99', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mojen', '100', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('msg', '101', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pigtails', '102', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('treca', '103', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('butts', '104', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gnome', '105', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('olds', '106', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('think', '107', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('year', '108', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('heh', '109', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hell', '110', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mean', '111', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cream', '112', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('made', '113', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('myself', '114', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('myspace', '115', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('omg', '116', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tits', '117', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('voluptoous', '118', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('10', '119', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ass', '120', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('boy', '121', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('boys', '122', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('buddies', '123', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bums', '124', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('chick', '125', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('goes', '126', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hot', '127', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('laughed', '128', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('link', '129', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('meant', '130', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('nice', '131', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('one', '132', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('party', '133', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('quot', '134', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sure', '135', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('talking', '136', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('used', '137', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wtf', '138', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('government', '139', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mother', '140', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('trust', '141', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('altar', '142', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('archimonde', '143', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('burning', '144', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('crusade', '145', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('discuss', '146', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fuck', '147', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('letes', '148', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lets', '149', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('reactivating', '150', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('storms', '151', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('told', '152', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whats', '153', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('yeah', '154', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('aries', '155', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('back', '156', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('came', '157', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('change', '158', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('done', '159', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('everytime', '160', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('however', '161', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('idea', '162', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('keep', '163', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('likely', '164', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('month', '165', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('point', '166', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('quit', '167', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('same', '168', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('servers', '169', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('several', '170', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('start', '171', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stay', '172', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sticks', '173', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('switching', '174', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('two', '175', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('willing', '176', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('60s', '177', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('actually', '178', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('already', '179', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('corn', '180', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('daily', '181', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('friends', '182', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ingame', '183', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('long', '184', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mine', '185', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pops', '186', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rl', '187', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ros', '188', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('send', '189', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tell', '190', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('chars', '191', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('consider', '192', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('endo', '193', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hoppin', '194', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('horde', '195', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('across', '196', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bay', '197', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brian', '198', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cox', '199', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dev', '200', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('donovan', '201', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('drop', '202', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('email', '203', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('john', '204', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('live', '205', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('net', '206', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('null', '207', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('philip', '208', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('post', '209', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sean', '210', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('smith', '211', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whatever', '212', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('beyond', '213', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('check', '214', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('com', '215', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('darkfall', '216', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('darkfallonline', '217', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('memories', '219', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gay', '220', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thought', '221', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('contract', '222', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('probaby', '223', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shards', '224', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sign', '225', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('switch', '226', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wed', '227', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('win', '457', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('weeks', '456', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wanna', '455', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('umm', '454', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('u', '453', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('touched', '452', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('touch', '451', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('together', '450', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('suing', '449', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stupid', '448', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('story', '447', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('statement', '446', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('case', '240', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('short', '445', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sex', '444', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('set', '443', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('saying', '442', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cuz', '245', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rubbed', '441', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('realize', '440', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rape', '439', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('psychotic', '438', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('evidence', '250', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('proposed', '437', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('preliminary', '436', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('picked', '435', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fucked', '254', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('phone', '434', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('oral', '433', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('making', '432', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('madukes', '431', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('love', '430', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lawyer', '429', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('laura', '428', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('later', '427', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('indict', '426', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ill', '425', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hopefully', '424', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hearing', '423', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('happens', '422', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('give', '421', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('girl', '420', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('freaked', '419', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('forced', '418', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fooled', '417', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ejaculate', '416', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dick', '415', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('degree', '414', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('damn', '413', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cops', '412', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('completely', '411', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('christ', '410', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shit', '280', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('charges', '409', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('broke', '408', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('blehblehbleh', '407', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bitch', '406', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('aug', '405', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('and', '404', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('allegation', '403', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('acquitted', '402', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('abullshit', '401', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('5087716097', '400', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('30am', '399', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2nd', '398', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('28th', '397', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('610', '294', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('attorney', '295', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('commit', '296', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('crime', '297', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('defense', '298', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('facing', '299', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('family', '300', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('i', '301', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('instead', '302', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('payin', '303', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('spendin', '304', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wasnt', '305', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('years', '306', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('geno', '307', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('genosis', '308', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lakk', '309', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('luck', '310', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('man', '311', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wish', '312', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wrong', '313', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('410', '314', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('again', '315', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('amount', '316', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('append', '317', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('awesome', '318', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bitchis', '319', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bostons', '320', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bulgers', '321', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('buncha', '322', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cash', '323', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('coke', '324', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('comes', '325', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('county', '326', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('crazy', '327', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('defended', '328', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('details', '329', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('discount', '330', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dss', '331', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('engaged', '332', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('familiy', '333', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fired', '334', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('flyin', '335', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('framin', '336', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gave', '337', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gma', '338', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('goeson', '339', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('grandmother', '340', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hella', '341', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hes', '342', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('im', '343', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jail', '344', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kentucky', '345', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('keys', '346', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kid', '347', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kno', '348', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lawyers', '349', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('life', '350', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lookin', '351', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('looks', '352', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('managed', '353', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('massachusetts', '354', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('max', '355', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('members', '356', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('neverh', '357', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('otu', '358', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('panama', '359', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('part', '360', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('plane', '361', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('plus', '362', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('popped', '363', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('scandal', '364', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('serve', '365', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shelled', '366', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('situation', '367', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('soem', '368', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('someone', '369', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('somethin', '370', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('suit', '371', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sup', '372', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('surpress', '373', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thruout', '374', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tied', '375', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('top', '376', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tried', '377', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('uncle', '378', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whitey', '379', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whole', '380', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hard', '381', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thug', '382', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('awhile', '383', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bored', '384', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brother', '385', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('getting', '386', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hooked', '387', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kinda', '388', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('played', '389', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('quite', '390', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('regular', '391', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('semi', '392', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thanks', '393', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thou', '394', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fuckin', '395', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pussy', '396', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('attest', '458', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bro', '459', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('clears', '460', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('guy', '461', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('headache', '462', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hope', '463', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('woman', '464', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ive', '514', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lie', '515', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cocks', '468', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('parole', '516', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cumshots', '471', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shitabout', '517', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('moral', '493', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('giant', '474', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('games', '492', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thru', '491', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('that', '490', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('son', '489', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('poart', '488', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pants', '487', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('happend', '486', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('glad', '485', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fail', '513', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('evenppl', '512', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('eligilbilty', '511', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('detector', '510', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('atleast', '509', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('anxious', '508', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('admit', '507', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tellin', '518', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('test', '519', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('truth', '520', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('saints', '549', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ignorant', '548', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('history', '547', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hey', '546', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('he', '545', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('frostmourne', '544', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('flip', '543', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('coincedence', '542', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cell', '541', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brand', '540', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('battlegrounds', '539', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('assume', '538', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('among', '537', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('17', '536', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sas', '550', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('school', '551', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sinners', '552', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sonoma', '553', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tag', '554', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whisper', '555', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wsg', '556', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dav', '557', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shut', '558', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('acctually', '559', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('allright', '560', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('anymore', '561', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dude', '562', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('except', '563', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('graphics', '564', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('lol', '565', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('plays', '566', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('uo', '567', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('alive', '568', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('changes', '569', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fp', '570', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('locke', '571', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('member', '572', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('week', '573', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('guild', '819', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('blackrock', '649', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('davin', '650', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dead', '651', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dun', '652', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dyn', '653', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mega', '654', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rhuarc', '655', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('besides', '656', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bld', '657', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('clownzors', '658', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('honorary', '659', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ogd', '660', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('seems', '661', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('seperate', '662', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mind', '805', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('makes', '804', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('boston', '803', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stress', '802', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('shouldnt', '801', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('least', '800', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fairly', '799', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('easily', '798', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('charged', '797', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('able', '796', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('miss', '795', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jason', '794', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('trip', '793', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('haha', '792', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('crrrazzyy', '791', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dakk', '678', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('kind', '679', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('core', '818', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('auto', '681', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brick', '817', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('car', '683', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rad', '816', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fukin', '815', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('call', '814', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('women', '813', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('seem', '812', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('men', '811', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('info', '690', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('insurance', '691', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('themselvse', '810', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('strangler', '809', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sound', '808', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('position', '807', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('obvious', '806', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('121806', '697', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('1am', '698', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('2am', '699', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('achy', '700', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('anything', '701', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('arm', '702', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('asleep', '703', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('away', '704', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ays', '705', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('basement', '706', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bit', '707', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bout', '708', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brain', '709', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brothers', '710', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('brothres', '711', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bullshit', '712', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('care', '713', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cihc', '714', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('contact', '715', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('couchi', '716', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('crotch', '717', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('cry', '718', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('decided', '719', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('downstairs', '720', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('e', '721', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('effected', '722', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('entire', '723', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('experience', '724', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('falling', '725', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('feel', '726', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('finally', '727', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('friday', '728', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('friend', '729', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('gas', '730', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('grabbed', '731', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hair', '732', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('half', '733', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hand', '734', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('handwere', '735', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hanging', '736', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('harder', '737', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hells', '738', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('house', '739', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('howbig', '740', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('istarted', '741', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('job', '742', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('left', '743', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('like', '744', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('living', '745', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('manager', '746', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mouth', '747', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('opf', '748', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pat', '749', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pats', '750', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('peins', '751', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('penis', '752', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('physical', '753', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('prosecuting', '754', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pull', '755', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pulled', '756', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pulledm', '757', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pushing', '758', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('puts', '759', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('ran', '760', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('raping', '761', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('room', '762', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('rubbing', '763', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sending', '764', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sense', '765', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('side', '766', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('signals', '767', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sitting', '768', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('sorry', '769', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('starts', '770', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('stop', '771', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('store', '772', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('suspended', '773', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('taht', '774', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('talka', '775', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('talked', '776', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tank', '777', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thecouch', '778', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('thursday', '779', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('tog', '780', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('try', '781', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('trying', '782', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('twice', '783', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('unzipped', '784', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('upstairs', '785', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('walk', '786', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whatsoever', '787', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wheni', '788', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('work', '789', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('written', '790', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('hit', '820', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('pretty', '821', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('waiting', '822', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('wall', '823', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('links', '878', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('enter', '873', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('adult', '864', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('12', '839', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('anywho', '840', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('court', '841', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dumb', '842', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('front', '843', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fu', '844', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('honest', '845', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('prove', '846', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('unless', '847', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('word', '848', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('bitches', '849', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('fuckers', '850', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('mut', '851', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('asshole', '852', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('considering', '853', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('convention', '854', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('dyns', '855', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('giveing', '856', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('guess', '857', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('jus', '858', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('level', '859', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('palou', '860', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('star', '861', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('trek', '862', '0');
INSERT INTO phpbb_search_wordlist (word_text, word_id, word_common) VALUES('whored', '863', '0');
#
# TABLE: phpbb_search_wordmatch
#
DROP TABLE IF EXISTS phpbb_search_wordmatch;
CREATE TABLE phpbb_search_wordmatch(
	post_id mediumint(8) unsigned NOT NULL,
	word_id mediumint(8) unsigned NOT NULL,
	title_match tinyint(1) NOT NULL, 
	KEY post_id (post_id), 
	KEY word_id (word_id)
);

#
# Table Data for phpbb_search_wordmatch
#

INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '24', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('4', '19', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('4', '20', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('4', '21', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('4', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('3', '15', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('3', '16', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('3', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('3', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('2', '14', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('2', '13', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '25', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '26', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '27', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '29', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '30', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '31', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('5', '32', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('6', '34', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('6', '35', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('6', '36', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('6', '37', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('6', '38', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('6', '33', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('7', '40', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('7', '39', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('8', '41', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('8', '42', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('8', '43', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('9', '44', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('9', '45', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('9', '46', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('10', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('10', '48', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '23', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '49', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '51', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '52', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '53', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '54', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '55', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '56', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '57', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '58', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '59', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '60', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('11', '50', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '483', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '415', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '411', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('13', '41', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '63', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '64', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '65', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '66', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '69', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('14', '70', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('15', '71', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('15', '72', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('15', '73', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('15', '74', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('15', '75', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('15', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('15', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('17', '76', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('17', '77', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('17', '78', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '79', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '80', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '81', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '82', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('19', '83', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '53', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '57', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '84', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '85', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '86', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '87', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '88', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '91', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('20', '92', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('21', '93', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '78', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '94', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '95', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '96', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '97', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '99', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '100', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '101', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '102', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('22', '103', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '96', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '104', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '97', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '105', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '106', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('23', '108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('24', '53', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('24', '109', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('24', '110', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('24', '111', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('24', '57', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('24', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '112', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '113', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '114', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '115', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '116', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '118', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('25', '108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '119', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '121', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '122', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '123', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '124', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '125', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '126', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '127', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '128', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '129', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '130', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '131', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '133', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '135', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '136', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '137', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('26', '138', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('27', '139', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('27', '140', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('27', '141', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '142', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '143', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '146', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '148', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '149', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '150', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '151', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '152', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '153', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '143', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '144', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '145', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('28', '70', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '109', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '155', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '157', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '158', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '159', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '160', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '161', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '162', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '163', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '164', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '165', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '166', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '167', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '169', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '170', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '171', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '172', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '173', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '174', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '175', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('29', '176', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '177', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '178', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '179', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '95', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '180', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '181', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '183', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '99', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '184', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '185', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '186', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '187', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '188', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '189', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '190', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('30', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '142', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '191', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '192', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '193', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '194', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '195', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('31', '151', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '196', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '197', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '198', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '199', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '200', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '202', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '203', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '204', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '205', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '206', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '207', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '208', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '209', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '210', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '211', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '212', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('32', '201', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('33', '213', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('33', '214', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('33', '215', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('33', '217', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('33', '216', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('34', '219', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('35', '220', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('35', '221', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('35', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('35', '70', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '222', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '17', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '223', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '168', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '224', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '225', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '172', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '226', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '227', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('36', '108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '70', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '90', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '67', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '254', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '411', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '397', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '398', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '399', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '400', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '401', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '402', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '403', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '404', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '405', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '406', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '407', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '408', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '409', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '280', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '410', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '412', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '413', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '414', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '415', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '416', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '417', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '418', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '419', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '420', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '421', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '422', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '423', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '424', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '425', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '426', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '427', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '428', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '429', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '430', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '431', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '432', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '433', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '434', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '435', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '436', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '437', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '250', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '438', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '439', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '440', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '441', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '245', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '442', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '443', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '444', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '445', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '240', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '446', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '447', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '448', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '449', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '450', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '451', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '452', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '453', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '454', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '455', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '456', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '457', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '184', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '88', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('37', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '294', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '295', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '95', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '296', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '297', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '298', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '299', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '300', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '182', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '302', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '303', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '304', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '305', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('38', '306', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '307', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '308', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '309', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '310', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '311', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '312', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('39', '313', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '64', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '110', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '129', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '135', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '184', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '185', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '212', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '240', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '245', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '250', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '254', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '280', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '295', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '298', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '300', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '302', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '306', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '307', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '314', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '315', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '316', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '317', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '318', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '319', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '320', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '321', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '322', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '323', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '324', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '325', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '326', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '327', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '328', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '329', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '330', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '331', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '332', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '333', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '334', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '335', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '336', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '337', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '338', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '339', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '340', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '341', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '342', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '343', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '344', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '345', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '346', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '347', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '348', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '349', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '350', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '351', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '352', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '353', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '354', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '355', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '356', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '357', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '358', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '359', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '360', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '361', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '362', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '363', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '364', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '365', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '366', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '367', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '368', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '369', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '370', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '371', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '372', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '373', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '374', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '375', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '376', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '377', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '378', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '379', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('40', '380', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('41', '120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('41', '381', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('41', '382', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '383', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '384', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '385', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '386', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '387', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '388', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '389', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '390', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '391', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '37', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '392', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '393', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '394', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('42', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '395', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('43', '396', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '458', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '459', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '460', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '461', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '462', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '463', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '390', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '280', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('44', '464', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '520', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '519', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('47', '153', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('47', '117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('47', '447', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('47', '493', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('47', '492', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '452', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '491', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '490', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '489', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '370', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '441', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '488', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '487', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '486', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '126', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '485', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '417', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('46', '484', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '518', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '517', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '280', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '90', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '516', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '515', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '514', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '513', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '512', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '511', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '510', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '240', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '322', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '509', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '508', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '507', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('48', '306', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '551', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '550', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '549', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '434', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '548', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '547', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '546', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '545', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '461', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '420', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '544', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '543', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '542', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '541', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '540', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '539', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '538', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '537', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '536', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '552', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '553', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '554', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '455', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '555', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '556', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '108', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '550', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '22', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('50', '70', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('51', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('51', '557', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('51', '558', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('51', '553', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '559', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '560', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '561', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '562', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '563', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '19', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '564', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '565', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '311', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '566', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('52', '567', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '568', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '569', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '484', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '570', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '571', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '572', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '22', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '573', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('53', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '649', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '122', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '650', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '651', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '652', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '653', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '654', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '132', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '566', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '655', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '305', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('57', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '178', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '568', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '656', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '649', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '657', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '658', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '652', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '653', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '98', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '659', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '130', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '572', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '660', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '89', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '28', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '661', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '662', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '169', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('58', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '803', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '802', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '801', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '439', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '310', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '800', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '429', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '99', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '799', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '798', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '797', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('66', '796', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '546', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '208', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '795', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('65', '794', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '793', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '99', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '792', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '791', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '459', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('64', '406', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('60', '650', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '678', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '492', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '679', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '111', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '493', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '131', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '447', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '117', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('61', '153', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('68', '444', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('68', '812', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('68', '811', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('68', '310', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('68', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '810', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '809', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '808', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '442', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '37', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '807', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '806', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '805', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '804', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '515', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '110', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '395', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('67', '713', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '18', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '30', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '31', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '52', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '68', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '81', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '107', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '114', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '134', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '156', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '163', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '175', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '221', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '450', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '446', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '240', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '442', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '432', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '418', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '313', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '315', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '350', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '360', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '369', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '376', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '380', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '381', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '463', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '491', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '487', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '486', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '565', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '683', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '697', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '698', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '699', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '700', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '701', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '702', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '703', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '704', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '705', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '706', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '707', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '708', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '709', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '710', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '711', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '712', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '713', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '714', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '715', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '716', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '717', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '718', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '719', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '720', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '721', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '722', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '723', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '724', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '725', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '726', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '727', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '728', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '729', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '730', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '731', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '732', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '733', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '734', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '735', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '736', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '737', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '738', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '739', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '740', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '741', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '742', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '743', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '744', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '745', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '746', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '747', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '748', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '749', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '750', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '751', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '752', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '753', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '754', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '755', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '756', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '757', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '758', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '759', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '760', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '761', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '762', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '763', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '764', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '765', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '766', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '767', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '768', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '769', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '770', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '771', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '772', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '773', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '774', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '775', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '776', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '777', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '778', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '779', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '780', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '781', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '782', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '783', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '784', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '785', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '786', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '787', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '788', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '789', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '790', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '712', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '562', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('63', '90', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('68', '171', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('68', '813', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '406', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '814', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('69', '815', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '406', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('70', '816', '1');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '649', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '817', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '818', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '25', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '819', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '546', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '820', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '821', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '553', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '567', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '822', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '823', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('71', '154', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '839', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '840', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '120', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '841', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '413', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '842', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '843', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '844', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '147', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '47', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '381', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '845', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '99', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '429', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '81', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '311', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '811', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '846', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '439', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '847', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('73', '848', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '849', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '653', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '850', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '546', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '140', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('74', '851', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '94', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '852', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '853', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '854', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '413', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '855', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '484', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '856', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '857', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '819', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '67', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '195', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '301', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '514', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '858', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '859', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '860', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '861', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '221', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '862', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '781', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '863', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '312', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('75', '70', '0');
INSERT INTO phpbb_search_wordmatch (post_id, word_id, title_match) VALUES('77', '111', '0');
#
# TABLE: phpbb_sessions
#
DROP TABLE IF EXISTS phpbb_sessions;
CREATE TABLE phpbb_sessions(
	session_id char(32) NOT NULL,
	session_user_id mediumint(8) NOT NULL,
	session_start int(11) NOT NULL,
	session_time int(11) NOT NULL,
	session_ip char(8) NOT NULL,
	session_page int(11) NOT NULL,
	session_logged_in tinyint(1) NOT NULL,
	session_admin tinyint(2) NOT NULL, 
	PRIMARY KEY (session_id), 
	KEY session_user_id (session_user_id), 
	KEY session_id_ip_user_id (session_id, session_ip, session_user_id)
);

#
# Table Data for phpbb_sessions
#

INSERT INTO phpbb_sessions (session_id, session_user_id, session_start, session_time, session_ip, session_page, session_logged_in, session_admin) VALUES('ecaf87b5692c336132453f62d1cba2d8', '-1', '1159104204', '1159134550', '42f94854', '1', '0', '0');
INSERT INTO phpbb_sessions (session_id, session_user_id, session_start, session_time, session_ip, session_page, session_logged_in, session_admin) VALUES('5b39796a21908156f30a7e83258aa747', '-1', '1159134549', '1159134549', '42f94854', '-10', '0', '0');
INSERT INTO phpbb_sessions (session_id, session_user_id, session_start, session_time, session_ip, session_page, session_logged_in, session_admin) VALUES('7768e0cd06dd0322879a9b8e7149ab83', '2', '1159135896', '1159136227', '47e2a72c', '0', '1', '1');
#
# TABLE: phpbb_smilies
#
DROP TABLE IF EXISTS phpbb_smilies;
CREATE TABLE phpbb_smilies(
	smilies_id smallint(5) unsigned NOT NULL auto_increment,
	code varchar(50),
	smile_url varchar(100),
	emoticon varchar(75), 
	PRIMARY KEY (smilies_id)
);

#
# Table Data for phpbb_smilies
#

INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('1', ':D', 'icon_biggrin.gif', 'Very Happy');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('2', ':-D', 'icon_biggrin.gif', 'Very Happy');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('3', ':grin:', 'icon_biggrin.gif', 'Very Happy');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('4', ':)', 'icon_smile.gif', 'Smile');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('5', ':-)', 'icon_smile.gif', 'Smile');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('6', ':smile:', 'icon_smile.gif', 'Smile');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('7', ':(', 'icon_sad.gif', 'Sad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('8', ':-(', 'icon_sad.gif', 'Sad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('9', ':sad:', 'icon_sad.gif', 'Sad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('10', ':o', 'icon_surprised.gif', 'Surprised');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('11', ':-o', 'icon_surprised.gif', 'Surprised');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('12', ':eek:', 'icon_surprised.gif', 'Surprised');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('13', ':shock:', 'icon_eek.gif', 'Shocked');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('14', ':?', 'icon_confused.gif', 'Confused');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('15', ':-?', 'icon_confused.gif', 'Confused');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('16', ':???:', 'icon_confused.gif', 'Confused');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('17', '8)', 'icon_cool.gif', 'Cool');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('18', '8-)', 'icon_cool.gif', 'Cool');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('19', ':cool:', 'icon_cool.gif', 'Cool');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('20', ':lol:', 'icon_lol.gif', 'Laughing');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('21', ':x', 'icon_mad.gif', 'Mad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('22', ':-x', 'icon_mad.gif', 'Mad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('23', ':mad:', 'icon_mad.gif', 'Mad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('24', ':P', 'icon_razz.gif', 'Razz');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('25', ':-P', 'icon_razz.gif', 'Razz');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('26', ':razz:', 'icon_razz.gif', 'Razz');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('27', ':oops:', 'icon_redface.gif', 'Embarassed');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('28', ':cry:', 'icon_cry.gif', 'Crying or Very sad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('29', ':evil:', 'icon_evil.gif', 'Evil or Very Mad');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('30', ':twisted:', 'icon_twisted.gif', 'Twisted Evil');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('31', ':roll:', 'icon_rolleyes.gif', 'Rolling Eyes');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('32', ':wink:', 'icon_wink.gif', 'Wink');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('33', ';)', 'icon_wink.gif', 'Wink');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('34', ';-)', 'icon_wink.gif', 'Wink');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('35', ':!:', 'icon_exclaim.gif', 'Exclamation');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('36', ':?:', 'icon_question.gif', 'Question');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('37', ':idea:', 'icon_idea.gif', 'Idea');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('38', ':arrow:', 'icon_arrow.gif', 'Arrow');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('39', ':|', 'icon_neutral.gif', 'Neutral');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('40', ':-|', 'icon_neutral.gif', 'Neutral');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('41', ':neutral:', 'icon_neutral.gif', 'Neutral');
INSERT INTO phpbb_smilies (smilies_id, code, smile_url, emoticon) VALUES('42', ':mrgreen:', 'icon_mrgreen.gif', 'Mr. Green');
#
# TABLE: phpbb_themes
#
DROP TABLE IF EXISTS phpbb_themes;
CREATE TABLE phpbb_themes(
	themes_id mediumint(8) unsigned NOT NULL auto_increment,
	template_name varchar(30) NOT NULL,
	style_name varchar(30) NOT NULL,
	head_stylesheet varchar(100),
	body_background varchar(100),
	body_bgcolor varchar(6),
	body_text varchar(6),
	body_link varchar(6),
	body_vlink varchar(6),
	body_alink varchar(6),
	body_hlink varchar(6),
	tr_color1 varchar(6),
	tr_color2 varchar(6),
	tr_color3 varchar(6),
	tr_class1 varchar(25),
	tr_class2 varchar(25),
	tr_class3 varchar(25),
	th_color1 varchar(6),
	th_color2 varchar(6),
	th_color3 varchar(6),
	th_class1 varchar(25),
	th_class2 varchar(25),
	th_class3 varchar(25),
	td_color1 varchar(6),
	td_color2 varchar(6),
	td_color3 varchar(6),
	td_class1 varchar(25),
	td_class2 varchar(25),
	td_class3 varchar(25),
	fontface1 varchar(50),
	fontface2 varchar(50),
	fontface3 varchar(50),
	fontsize1 tinyint(4),
	fontsize2 tinyint(4),
	fontsize3 tinyint(4),
	fontcolor1 varchar(6),
	fontcolor2 varchar(6),
	fontcolor3 varchar(6),
	span_class1 varchar(25),
	span_class2 varchar(25),
	span_class3 varchar(25),
	img_size_poll smallint(5) unsigned,
	img_size_privmsg smallint(5) unsigned, 
	PRIMARY KEY (themes_id)
);

#
# Table Data for phpbb_themes
#

INSERT INTO phpbb_themes (themes_id, template_name, style_name, head_stylesheet, body_background, body_bgcolor, body_text, body_link, body_vlink, body_alink, body_hlink, tr_color1, tr_color2, tr_color3, tr_class1, tr_class2, tr_class3, th_color1, th_color2, th_color3, th_class1, th_class2, th_class3, td_color1, td_color2, td_color3, td_class1, td_class2, td_class3, fontface1, fontface2, fontface3, fontsize1, fontsize2, fontsize3, fontcolor1, fontcolor2, fontcolor3, span_class1, span_class2, span_class3, img_size_poll, img_size_privmsg) VALUES('1', 'subSilver', 'subSilver', 'subSilver.css', '', 'E5E5E5', '000000', '006699', '5493B4', '', 'DD6900', 'EFEFEF', 'DEE3E7', 'D1D7DC', '', '', '', '98AAB1', '006699', 'FFFFFF', 'cellpic1.gif', 'cellpic3.gif', 'cellpic2.jpg', 'FAFAFA', 'FFFFFF', '', 'row1', 'row2', '', 'Verdana, Arial, Helvetica, sans-serif', 'Trebuchet MS', 'Courier, \'Courier New\', sans-serif', '10', '11', '12', '444444', '006600', 'FFA34F', '', '', '', NULL, NULL);
#
# TABLE: phpbb_themes_name
#
DROP TABLE IF EXISTS phpbb_themes_name;
CREATE TABLE phpbb_themes_name(
	themes_id smallint(5) unsigned NOT NULL,
	tr_color1_name char(50),
	tr_color2_name char(50),
	tr_color3_name char(50),
	tr_class1_name char(50),
	tr_class2_name char(50),
	tr_class3_name char(50),
	th_color1_name char(50),
	th_color2_name char(50),
	th_color3_name char(50),
	th_class1_name char(50),
	th_class2_name char(50),
	th_class3_name char(50),
	td_color1_name char(50),
	td_color2_name char(50),
	td_color3_name char(50),
	td_class1_name char(50),
	td_class2_name char(50),
	td_class3_name char(50),
	fontface1_name char(50),
	fontface2_name char(50),
	fontface3_name char(50),
	fontsize1_name char(50),
	fontsize2_name char(50),
	fontsize3_name char(50),
	fontcolor1_name char(50),
	fontcolor2_name char(50),
	fontcolor3_name char(50),
	span_class1_name char(50),
	span_class2_name char(50),
	span_class3_name char(50), 
	PRIMARY KEY (themes_id)
);

#
# Table Data for phpbb_themes_name
#

INSERT INTO phpbb_themes_name (themes_id, tr_color1_name, tr_color2_name, tr_color3_name, tr_class1_name, tr_class2_name, tr_class3_name, th_color1_name, th_color2_name, th_color3_name, th_class1_name, th_class2_name, th_class3_name, td_color1_name, td_color2_name, td_color3_name, td_class1_name, td_class2_name, td_class3_name, fontface1_name, fontface2_name, fontface3_name, fontsize1_name, fontsize2_name, fontsize3_name, fontcolor1_name, fontcolor2_name, fontcolor3_name, span_class1_name, span_class2_name, span_class3_name) VALUES('1', 'The lightest row colour', 'The medium row color', 'The darkest row colour', '', '', '', 'Border round the whole page', 'Outer table border', 'Inner table border', 'Silver gradient picture', 'Blue gradient picture', 'Fade-out gradient on index', 'Background for quote boxes', 'All white areas', '', 'Background for topic posts', '2nd background for topic posts', '', 'Main fonts', 'Additional topic title font', 'Form fonts', 'Smallest font size', 'Medium font size', 'Normal font size (post body etc)', 'Quote & copyright text', 'Code text colour', 'Main table header text colour', '', '', '');
#
# TABLE: phpbb_topics
#
DROP TABLE IF EXISTS phpbb_topics;
CREATE TABLE phpbb_topics(
	topic_id mediumint(8) unsigned NOT NULL auto_increment,
	forum_id smallint(8) unsigned NOT NULL,
	topic_title char(60) NOT NULL,
	topic_poster mediumint(8) NOT NULL,
	topic_time int(11) NOT NULL,
	topic_views mediumint(8) unsigned NOT NULL,
	topic_replies mediumint(8) unsigned NOT NULL,
	topic_status tinyint(3) NOT NULL,
	topic_vote tinyint(1) NOT NULL,
	topic_type tinyint(3) NOT NULL,
	topic_first_post_id mediumint(8) unsigned NOT NULL,
	topic_last_post_id mediumint(8) unsigned NOT NULL,
	topic_moved_id mediumint(8) unsigned NOT NULL, 
	PRIMARY KEY (topic_id), 
	KEY forum_id (forum_id), 
	KEY topic_moved_id (topic_moved_id), 
	KEY topic_status (topic_status), 
	KEY topic_type (topic_type)
);

#
# Table Data for phpbb_topics
#

INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('2', '1', 'Moo', '3', '1150301613', '94', '3', '0', '0', '0', '2', '5', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('3', '1', 'Boom boom boom boom', '5', '1150476746', '54', '0', '0', '0', '0', '6', '6', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('4', '1', 'asdasf', '6', '1150476862', '92', '3', '0', '0', '0', '7', '10', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('5', '1', 'activity', '5', '1151172279', '163', '6', '0', '0', '0', '11', '27', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('16', '1', 'SAS, WoW what server?', '17', '1157834949', '94', '9', '0', '0', '0', '50', '75', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('7', '1', 'WoW', '7', '1151275550', '152', '6', '0', '0', '0', '14', '26', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('8', '1', '.', '8', '1151495189', '67', '1', '0', '0', '0', '18', '19', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('9', '1', 'WOW: Burning Crusade. Archimonde?', '6', '1152577884', '82', '3', '0', '0', '0', '28', '31', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('10', '1', 'Donovan', '5', '1153784519', '49', '1', '0', '0', '0', '32', '69', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('11', '1', 'DarkFall', '10', '1154580826', '32', '0', '0', '0', '0', '33', '33', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('12', '1', 'Memories....', '11', '1154906773', '80', '3', '0', '0', '0', '34', '38', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('13', '1', 'Wow this is completely fucked read guys.', '6', '1154999729', '204', '17', '0', '0', '0', '37', '73', '0');
INSERT INTO phpbb_topics (topic_id, forum_id, topic_title, topic_poster, topic_time, topic_views, topic_replies, topic_status, topic_vote, topic_type, topic_first_post_id, topic_last_post_id, topic_moved_id) VALUES('22', '1', 'Rad is a little bitch.', '24', '1158978116', '8', '1', '0', '0', '0', '70', '77', '0');
#
# TABLE: phpbb_topics_watch
#
DROP TABLE IF EXISTS phpbb_topics_watch;
CREATE TABLE phpbb_topics_watch(
	topic_id mediumint(8) unsigned NOT NULL,
	user_id mediumint(8) NOT NULL,
	notify_status tinyint(1) NOT NULL, 
	KEY topic_id (topic_id), 
	KEY user_id (user_id), 
	KEY notify_status (notify_status)
);
#
# TABLE: phpbb_user_group
#
DROP TABLE IF EXISTS phpbb_user_group;
CREATE TABLE phpbb_user_group(
	group_id mediumint(8) NOT NULL,
	user_id mediumint(8) NOT NULL,
	user_pending tinyint(1), 
	KEY group_id (group_id), 
	KEY user_id (user_id)
);

#
# Table Data for phpbb_user_group
#

INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('1', '-1', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('2', '2', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('3', '3', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('4', '4', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('5', '5', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('6', '6', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('7', '7', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('8', '8', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('9', '9', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('10', '10', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('11', '11', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('12', '12', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('14', '13', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('18', '17', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('30', '24', '0');
INSERT INTO phpbb_user_group (group_id, user_id, user_pending) VALUES('28', '23', '0');
#
# TABLE: phpbb_users
#
DROP TABLE IF EXISTS phpbb_users;
CREATE TABLE phpbb_users(
	user_id mediumint(8) NOT NULL,
	user_active tinyint(1) DEFAULT '1',
	username varchar(25) NOT NULL,
	user_password varchar(32) NOT NULL,
	user_session_time int(11) NOT NULL,
	user_session_page smallint(5) NOT NULL,
	user_lastvisit int(11) NOT NULL,
	user_regdate int(11) NOT NULL,
	user_level tinyint(4),
	user_posts mediumint(8) unsigned NOT NULL,
	user_timezone decimal(5,2) DEFAULT '0.00' NOT NULL,
	user_style tinyint(4),
	user_lang varchar(255),
	user_dateformat varchar(14) DEFAULT 'd M Y H:i' NOT NULL,
	user_new_privmsg smallint(5) unsigned NOT NULL,
	user_unread_privmsg smallint(5) unsigned NOT NULL,
	user_last_privmsg int(11) NOT NULL,
	user_login_tries smallint(5) unsigned NOT NULL,
	user_last_login_try int(11) NOT NULL,
	user_emailtime int(11),
	user_viewemail tinyint(1),
	user_attachsig tinyint(1),
	user_allowhtml tinyint(1) DEFAULT '1',
	user_allowbbcode tinyint(1) DEFAULT '1',
	user_allowsmile tinyint(1) DEFAULT '1',
	user_allowavatar tinyint(1) DEFAULT '1' NOT NULL,
	user_allow_pm tinyint(1) DEFAULT '1' NOT NULL,
	user_allow_viewonline tinyint(1) DEFAULT '1' NOT NULL,
	user_notify tinyint(1) DEFAULT '1' NOT NULL,
	user_notify_pm tinyint(1) NOT NULL,
	user_popup_pm tinyint(1) NOT NULL,
	user_rank int(11),
	user_avatar varchar(100),
	user_avatar_type tinyint(4) NOT NULL,
	user_email varchar(255),
	user_icq varchar(15),
	user_website varchar(100),
	user_from varchar(100),
	user_sig text,
	user_sig_bbcode_uid varchar(10),
	user_aim varchar(255),
	user_yim varchar(255),
	user_msnm varchar(255),
	user_occ varchar(100),
	user_interests varchar(255),
	user_actkey varchar(32),
	user_newpasswd varchar(32), 
	PRIMARY KEY (user_id), 
	KEY user_session_time (user_session_time)
);

#
# Table Data for phpbb_users
#

INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('-1', '0', 'Anonymous', '', '0', '0', '0', '1150289148', '0', '0', '0.00', NULL, '', '', '0', '0', '0', '0', '0', NULL, '0', '0', '1', '1', '1', '1', '0', '1', '0', '1', '0', NULL, '', '0', '', '', '', '', '', NULL, '', '', '', '', '', '', '');
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('2', '1', 'Aries', '3c2c266a60d4982f5834d8010be5ebda', '1159136227', '0', '1159070914', '1150289148', '1', '8', '0.00', '1', 'english', 'd M Y h:i a', '0', '0', '0', '0', '0', NULL, '1', '0', '0', '1', '1', '1', '1', '1', '0', '1', '1', '1', '', '0', 'tgzalonis@hotmail.com', '', '', '', '', NULL, '', '', '', '', '', '', '');
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('3', '1', 'Garen', 'a7fcf4273ef385171d3ef08ba32429a4', '1157878002', '0', '1150838850', '1150301577', '0', '3', '-8.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '1', '1', '0', '1', '1', '1', '1', '1', '0', '0', '1', '0', '', '0', 'meekrobe@gmail.com', '9114700', '', '', '', '', 'supergaren', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('4', '1', 'Bc', '37f8bf33853e0a8c55c5fd2a26f9ffc0', '1159031758', '-9', '1158968017', '1150401111', '0', '11', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'evan_si@hotmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('5', '1', 'Access', 'a9ff9abb75da969147c90018c936cf69', '1158996172', '0', '1158797790', '1150476697', '0', '10', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'dev.null@cox.net', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('6', '1', 'Lakkin', 'cb16cefd41d8c728b35361f776711ead', '1158858613', '1', '1158764420', '1150476840', '0', '15', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'pjohn0101@gmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('7', '1', 'Turkel', 'b30bd351371c686298d32281b337e8e9', '1153901581', '0', '1151275504', '1151275494', '0', '2', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'simonturkel@gmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('8', '1', 'Nexus', '9b7d722b58370498cd39104b2d971978', '1154431838', '0', '1151529352', '1151495156', '0', '1', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'xerais@gmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('9', '1', 'DC', '62a2a7da6217f52c75c9f14abfb0d37f', '1158820914', '1', '1158730152', '1152682838', '0', '4', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'sirjamesht@yahoo.com', '8257591', '', '', '', '', 'Balanced+In+Fire', '', '', '', 'Rivan\'s Mom', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('10', '1', 'Justinsane', '2cac45258b90261b625d70949d7639ca', '1154580792', '0', '1154580792', '1154580715', '0', '1', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'shoobz@gmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('11', '1', 'Matt', 'ae76a058f15da8a9d4e87c0fecd746bf', '1154907064', '0', '1154906623', '1154906611', '0', '1', '-5.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'matt@deniedproject.net', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('12', '1', 'Geno', '9bb6920f7279b2600bc792ac89d43494', '1155986089', '0', '1155954418', '1155776471', '0', '2', '1.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'shadowlord@gbg.bonet.se', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('17', '1', 'Locke of SAS', 'da14a7168b547f35ea0c6fa9f50de63e', '1158979247', '1', '1158611443', '1157834407', '0', '4', '-8.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'davgoff@pacbell.net', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('13', '1', 'Dakkon', '95e77c4b5dcd0b1fe51d3b6f66b01aaf', '1159001850', '1', '1158005788', '1157159218', '0', '3', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'blitz@rerolled.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('23', '1', 'rad', '6b519503a5a9fd7134a763ab5a985287', '1159129334', '0', '1158819254', '1158784619', '0', '2', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'radzorus@hotmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
INSERT INTO phpbb_users (user_id, user_active, username, user_password, user_session_time, user_session_page, user_lastvisit, user_regdate, user_level, user_posts, user_timezone, user_style, user_lang, user_dateformat, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_login_tries, user_last_login_try, user_emailtime, user_viewemail, user_attachsig, user_allowhtml, user_allowbbcode, user_allowsmile, user_allowavatar, user_allow_pm, user_allow_viewonline, user_notify, user_notify_pm, user_popup_pm, user_rank, user_avatar, user_avatar_type, user_email, user_icq, user_website, user_from, user_sig, user_sig_bbcode_uid, user_aim, user_yim, user_msnm, user_occ, user_interests, user_actkey, user_newpasswd) VALUES('24', '1', '[SAS]Justin', '2cac45258b90261b625d70949d7639ca', '1158978149', '1', '1158978088', '1158978062', '0', '1', '0.00', '1', 'english', 'D M d, Y g:i a', '0', '0', '0', '0', '0', NULL, '0', '1', '0', '1', '1', '1', '1', '1', '0', '1', '1', '0', '', '0', 'jayemsee@hotmail.com', '', '', '', '', '', '', '', '', '', '', '', NULL);
#
# TABLE: phpbb_vote_desc
#
DROP TABLE IF EXISTS phpbb_vote_desc;
CREATE TABLE phpbb_vote_desc(
	vote_id mediumint(8) unsigned NOT NULL auto_increment,
	topic_id mediumint(8) unsigned NOT NULL,
	vote_text text NOT NULL,
	vote_start int(11) NOT NULL,
	vote_length int(11) NOT NULL, 
	PRIMARY KEY (vote_id), 
	KEY topic_id (topic_id)
);
#
# TABLE: phpbb_vote_results
#
DROP TABLE IF EXISTS phpbb_vote_results;
CREATE TABLE phpbb_vote_results(
	vote_id mediumint(8) unsigned NOT NULL,
	vote_option_id tinyint(4) unsigned NOT NULL,
	vote_option_text varchar(255) NOT NULL,
	vote_result int(11) NOT NULL, 
	KEY vote_option_id (vote_option_id), 
	KEY vote_id (vote_id)
);
#
# TABLE: phpbb_vote_voters
#
DROP TABLE IF EXISTS phpbb_vote_voters;
CREATE TABLE phpbb_vote_voters(
	vote_id mediumint(8) unsigned NOT NULL,
	vote_user_id mediumint(8) NOT NULL,
	vote_user_ip char(8) NOT NULL, 
	KEY vote_id (vote_id), 
	KEY vote_user_id (vote_user_id), 
	KEY vote_user_ip (vote_user_ip)
);
#
# TABLE: phpbb_words
#
DROP TABLE IF EXISTS phpbb_words;
CREATE TABLE phpbb_words(
	word_id mediumint(8) unsigned NOT NULL auto_increment,
	word char(100) NOT NULL,
	replacement char(100) NOT NULL, 
	PRIMARY KEY (word_id)
);
#
# TABLE: phpbb_confirm
#
DROP TABLE IF EXISTS phpbb_confirm;
CREATE TABLE phpbb_confirm(
	confirm_id char(32) NOT NULL,
	session_id char(32) NOT NULL,
	code char(6) NOT NULL, 
	PRIMARY KEY (session_id, confirm_id)
);
#
# TABLE: phpbb_sessions_keys
#
DROP TABLE IF EXISTS phpbb_sessions_keys;
CREATE TABLE phpbb_sessions_keys(
	key_id varchar(32) NOT NULL,
	user_id mediumint(8) NOT NULL,
	last_ip varchar(8) NOT NULL,
	last_login int(11) NOT NULL, 
	PRIMARY KEY (key_id, user_id), 
	KEY last_login (last_login)
);

#
# Table Data for phpbb_sessions_keys
#

INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('e3417ecd6c9369ab7b0382e089213abd', '3', '43828187', '1150301603');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('9a62d9d668dcd7256cf59ceae311ea86', '4', '4711280d', '1156901261');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('734501873d9c29a4785ab9f100d47f86', '3', '43828187', '1150838850');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('656957044e3ff23e9a8d0f11f37128b0', '5', '1805c69a', '1150710562');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('27d879f1b3ebcea8e4ea41ea599b029d', '7', '1896838f', '1153901581');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('d0cbd110fb06306bd074e18de0b8d735', '8', '41bd1bfc', '1151529184');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('48c966457b9ae4fe6d58220ff534042e', '6', '4160fbd7', '1152577833');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('7f404897bced5998232e084b1d9d1386', '9', '18b0d8f7', '1156292391');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('3a51e52f8d3c74630435abe058c6735f', '12', '52b64596', '1155986089');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('3a36aefd8af89e63abbcd8c79e62b9da', '13', '467058cc', '1158005788');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('bbbf951b60aadd34deac809b3c725ff2', '17', '447fe574', '1158979111');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('53ab38d26c3cb6d6f4428177780c4157', '4', '4711280d', '1159031658');
INSERT INTO phpbb_sessions_keys (key_id, user_id, last_ip, last_login) VALUES('4d36d81cf5cb82b94e7dea45bcdce0ef', '9', '18b0d8f7', '1158820646');
